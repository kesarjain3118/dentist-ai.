<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Dental image inference goes only through `analyzeImage` in src/lib/analysis/service.ts, which first runs the INT8 SigLIP ONNX model in the browser via onnxruntime-web (src/lib/analysis/browser-model.ts, weights fetched from Hugging Face), then the optional external model server and falls back to a labelled sample when unreachable, so the UI never contains model logic.
- Ask Dentist AI streams from /api/chat and is grounded only on the saved structured analysis result, never the raw image, so the assistant cannot independently diagnose.
- Patient-facing condition copy lives in src/lib/conditions.ts keyed by model label, so new model classes only need a new entry.
- Veltris appears as a restrained technology credit, while Dentist AI remains the patient-facing product brand.
- The model server (backend/main.py, deployed as app.py) runs the classifier as ONNX via onnxruntime, not PyTorch, so it fits a 512 MB free host.
- X-ray scans run a separate in-browser YOLOv8 INT8 detector (src/lib/analysis/xray-model.ts, weights in the public `models` storage bucket); photos keep the SigLIP classifier, so each modality uses a model trained for it.
- Report uncertainty guidance is selected by modality and status in the browser-safe report-warning module; low confidence must not be treated as proof of poor image quality.
