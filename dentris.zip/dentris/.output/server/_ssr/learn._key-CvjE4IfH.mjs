import { a as require_jsx_runtime } from "../_libs/@ai-sdk/react+[...].mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { J as ArrowLeft } from "../_libs/lucide-react.mjs";
import { t as CONDITIONS } from "./conditions-2iG2DNG0.mjs";
import { t as Disclaimer } from "./brand-DxDeCF_T.mjs";
import { t as Route } from "./learn._key-BrNnS7iV.mjs";
import { n as StageStrip } from "./dental-visuals-nx5cLIxZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/learn._key-CvjE4IfH.js
var import_jsx_runtime = require_jsx_runtime();
function Block({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "text-xl font-semibold",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-3 leading-relaxed text-muted-foreground",
		children
	})] });
}
var L = ({ items }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
	className: "list-disc space-y-1 pl-5",
	children: items.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: i }, i))
});
function LearnTopic() {
	const { key } = Route.useLoaderData();
	const c = CONDITIONS[key];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-3xl space-y-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/learn",
					className: "mb-4 flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), " Learn"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-brand",
					children: c.plain
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-4xl font-bold sm:text-5xl",
					children: c.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-lg text-muted-foreground",
					children: c.whatIsIt
				})
			] }),
			c.stages && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StageStrip, { stages: c.stages }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "Why can this happen?",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(L, { items: c.causes })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "What symptoms can occur?",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(L, { items: c.symptoms })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "What happens if it is ignored?",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: c.ifIgnored })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "What can a dentist do?",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(L, { items: c.dentistCan })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "What can I do now?",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(L, { items: c.doNow })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "When should I see a dentist?",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: c.whenToSee })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "Questions to ask your dentist",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(L, { items: c.questions })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Disclaimer, {})
		]
	});
}
//#endregion
export { LearnTopic as component };
