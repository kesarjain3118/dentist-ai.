import { a as require_jsx_runtime } from "../_libs/@ai-sdk/react+[...].mjs";
import { t as getLocation } from "./locations-CUJ9MYA2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dental-visuals-nx5cLIxZ.js
var import_jsx_runtime = require_jsx_runtime();
/** Simple, elegant tooth glyph with optional decay stage (0 healthy → 3 advanced). */
function ToothGlyph({ stage = 0, className = "h-24 w-20" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 80 96",
		className,
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
				id: `tg${stage}`,
				x1: "0",
				y1: "0",
				x2: "0",
				y2: "1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
					offset: "0",
					stopColor: "oklch(0.995 0.005 90)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
					offset: "1",
					stopColor: "oklch(0.93 0.02 80)"
				})]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M20 6c-9 0-14 7-14 17 0 10 3 18 6 28 2 8 4 39 11 39 6 0 6-24 10-24h14c4 0 4 24 10 24 7 0 9-31 11-39 3-10 6-18 6-28 0-10-5-17-14-17-7 0-10 4-20 4S27 6 20 6Z",
				fill: `url(#tg${stage})`,
				stroke: "oklch(0.85 0.02 80)",
				strokeWidth: "1.2"
			}),
			stage >= 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "46",
				cy: "22",
				rx: stage === 1 ? 6 : 8,
				ry: stage === 1 ? 4 : 6,
				fill: stage === 1 ? "oklch(0.97 0.01 90)" : "oklch(0.55 0.08 55)",
				stroke: "oklch(0.8 0.03 70)",
				strokeWidth: "0.8"
			}),
			stage >= 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "46",
				cy: "23",
				rx: "4",
				ry: "3.5",
				fill: "oklch(0.3 0.05 40)"
			}),
			stage >= 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M40 22c-2 10 2 22 0 34",
				stroke: "oklch(0.35 0.06 40)",
				strokeWidth: "3",
				fill: "none",
				strokeLinecap: "round"
			})
		]
	});
}
function StageStrip({ stages }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex items-end justify-between gap-2 rounded-3xl bg-attention-soft/60 px-4 py-6 sm:px-8",
		children: stages.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 items-end",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-1 flex-col items-center text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToothGlyph, {
						stage: i,
						className: "h-16 w-14 sm:h-24 sm:w-20"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs font-semibold text-foreground sm:text-sm",
						children: s.label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] text-muted-foreground sm:text-xs",
						children: s.sub
					})
				]
			}), i < stages.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mb-14 text-attention",
				children: "→"
			})]
		}, s.label))
	});
}
/** Top-down dental arch with highlighted estimated locations. */
function DentalArch({ locations, active }) {
	const teeth = 14;
	const point = (arch, t) => {
		const angle = Math.PI * (1 - t);
		const cx = 100, rx = 70, ry = arch === "upper" ? 78 : 70;
		const cy = arch === "upper" ? 112 : 128;
		return arch === "upper" ? {
			x: cx + rx * Math.cos(angle),
			y: cy - ry * Math.sin(angle)
		} : {
			x: cx + rx * Math.cos(angle),
			y: cy + ry * Math.sin(angle)
		};
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 200 240",
		className: "h-auto w-full max-w-[240px]",
		role: "img",
		"aria-label": "Dental arch showing estimated locations",
		children: [
			["upper", "lower"].map((arch) => Array.from({ length: teeth }).map((_, i) => {
				const t = i / 13;
				const p = point(arch, t);
				const size = Math.abs(t - .5) > .3 ? 9 : 7;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: p.x,
					cy: p.y,
					r: size,
					fill: "oklch(0.985 0.006 85)",
					stroke: "oklch(0.86 0.02 80)",
					strokeWidth: "1"
				}, arch + i);
			})),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "100",
				y: "58",
				textAnchor: "middle",
				className: "fill-muted-foreground text-[8px]",
				children: "Upper"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "100",
				y: "188",
				textAnchor: "middle",
				className: "fill-muted-foreground text-[8px]",
				children: "Lower"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "14",
				y: "122",
				className: "fill-muted-foreground text-[7px]",
				children: "R"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "182",
				y: "122",
				className: "fill-muted-foreground text-[7px]",
				children: "L"
			}),
			locations.map((code) => {
				const loc = getLocation(code);
				const p = point(loc.arch, loc.t);
				const on = !active || active === code;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
					opacity: on ? 1 : .35,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: p.x,
						cy: p.y,
						r: "16",
						fill: "oklch(0.6 0.19 22 / 0.18)",
						className: on ? "animate-breathe" : "",
						style: { transformOrigin: `${p.x}px ${p.y}px` }
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: p.x,
						cy: p.y,
						r: "9",
						fill: "oklch(0.6 0.19 22 / 0.85)"
					})]
				}, code);
			})
		]
	});
}
//#endregion
export { StageStrip as n, DentalArch as t };
