import { a as require_jsx_runtime } from "../_libs/@ai-sdk/react+[...].mjs";
import { r as useAuth } from "./auth-DeMeG-kQ.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { U as Camera, h as ScanLine, q as ArrowRight, y as MessageCircle } from "../_libs/lucide-react.mjs";
import { c as LanguageSelect, l as Logo } from "./brand-DxDeCF_T.mjs";
import { t as tooth_hero_default } from "./tooth-hero-CKojipPX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DoSLafr0.js
var import_jsx_runtime = require_jsx_runtime();
function Landing() {
	const { session } = useAuth();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background bg-wash",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mx-auto flex max-w-7xl items-center justify-between px-6 py-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LanguageSelect, {}), session ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/ask",
						className: "rounded-full bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground",
						children: "Open app"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/auth",
						className: "rounded-full px-4 py-2.5 text-sm font-semibold text-foreground hover:bg-secondary",
						children: "Sign in"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto grid max-w-7xl items-center gap-10 px-6 pb-20 pt-8 lg:grid-cols-2 lg:pt-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "animate-rise",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-5xl font-bold leading-[1.03] text-foreground text-balance-pro sm:text-7xl",
							children: "Understand your dental health with AI."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-lg text-lg text-muted-foreground",
							children: "Upload a dental photo or X-ray and get simple, AI-assisted insights about what may be visible."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-9 flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: session ? "/analyze" : "/auth",
								className: "inline-flex items-center gap-2 rounded-full bg-primary px-7 py-4 font-semibold text-primary-foreground shadow-float transition hover:-translate-y-0.5",
								children: ["Analyze an Image ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#how",
								className: "rounded-full px-6 py-4 font-semibold text-foreground hover:bg-secondary",
								children: "How It Works"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-8 text-xs text-muted-foreground",
							children: "AI-assisted analysis, not a diagnosis. Always confirm with a dentist."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative mx-auto aspect-[4/5] w-full max-w-md overflow-hidden rounded-4xl shadow-float",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: tooth_hero_default,
						alt: "A translucent tooth beside a green leaf",
						width: 1024,
						height: 1280,
						className: "h-full w-full object-cover"
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "how",
				className: "mx-auto max-w-7xl px-6 pb-28",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-3xl font-bold sm:text-4xl",
					children: "How it works"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 grid gap-10 sm:grid-cols-3",
					children: [
						{
							icon: Camera,
							t: "Upload",
							d: "A clear photo of your teeth, or a dental X-ray from your clinic."
						},
						{
							icon: ScanLine,
							t: "Analyze",
							d: "A specialised model looks for possible findings and where they appear."
						},
						{
							icon: MessageCircle,
							t: "Understand",
							d: "Plain-language explanations, next steps, and answers to your questions."
						}
					].map(({ icon: Icon, t, d }, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-sm font-semibold text-brand",
							children: ["0", i + 1]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: "mt-4 h-6 w-6 text-foreground",
							strokeWidth: 1.6
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-4 text-xl font-semibold",
							children: t
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-muted-foreground",
							children: d
						})
					] }, t))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "border-t border-border py-8 text-center text-xs text-muted-foreground",
				children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" Dentist AI · Educational information only, not medical advice."
				]
			})
		]
	});
}
//#endregion
export { Landing as component };
