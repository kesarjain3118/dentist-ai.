import { a as require_jsx_runtime } from "../_libs/@ai-sdk/react+[...].mjs";
import { b as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Route } from "./ask-CoA4CNmx.mjs";
import { n as useReports } from "./report-list-CuQpbBwM.mjs";
import { t as AskChat } from "./ask-chat-QWC0ZXDf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ask-BQD8HfM4.js
var import_jsx_runtime = require_jsx_runtime();
function Ask() {
	const { report } = Route.useSearch();
	const navigate = useNavigate();
	const { data } = useReports();
	const current = report ? data?.find((r) => r.id === report) : void 0;
	const picker = data?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center justify-center gap-2 text-xs",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted-foreground",
				children: "Context:"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				value: report ?? "",
				onChange: (e) => navigate({
					to: "/ask",
					search: e.target.value ? { report: e.target.value } : {}
				}),
				className: "rounded-lg border border-border bg-card px-2 py-1",
				"aria-label": "Choose a report",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: "",
					children: "General questions"
				}), data.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
					value: r.id,
					children: [
						new Date(r.created_at).toLocaleDateString(void 0, { dateStyle: "medium" }),
						" · ",
						r.image_type === "xray" ? "X-ray" : "Photo"
					]
				}, r.id))]
			}),
			current && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/reports/$id",
				params: { id: current.id },
				className: "font-semibold text-primary",
				children: "Open report"
			})
		]
	}) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "-mx-4 -mb-28 -mt-8 h-[calc(100dvh-3.5rem-5rem)] sm:-mx-8 lg:-mb-10 lg:-ml-[1rem] lg:-mr-10 lg:h-[calc(100dvh-3.5rem)]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AskChat, {
			analysisId: current?.id,
			header: picker
		})
	});
}
//#endregion
export { Ask as component };
