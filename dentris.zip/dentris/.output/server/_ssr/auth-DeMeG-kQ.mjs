import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-DHTyM8tX.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/@ai-sdk/react+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-DeMeG-kQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var AuthContext = (0, import_react.createContext)({
	session: null,
	user: null,
	loading: true
});
function AuthProvider({ children }) {
	const [state, setState] = (0, import_react.useState)({
		session: null,
		user: null,
		loading: true
	});
	(0, import_react.useEffect)(() => {
		const { data } = supabase.auth.onAuthStateChange((_e, session) => {
			setState({
				session,
				user: session?.user ?? null,
				loading: false
			});
		});
		supabase.auth.getSession().then(({ data: { session } }) => {
			setState({
				session,
				user: session?.user ?? null,
				loading: false
			});
		});
		return () => data.subscription.unsubscribe();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthContext.Provider, {
		value: state,
		children
	});
}
var useAuth = () => (0, import_react.useContext)(AuthContext);
function displayName(user) {
	if (!user) return "";
	const m = user.user_metadata ?? {};
	return m["full_name"] || m["name"] || user.email?.split("@")[0] || "there";
}
//#endregion
export { displayName as n, useAuth as r, AuthProvider as t };
