import { _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as objectType, r as stringType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ask-CoA4CNmx.js
var $$splitComponentImporter = () => import("./ask-BQD8HfM4.mjs");
var Route = createFileRoute("/_authenticated/ask")({
	validateSearch: objectType({ report: stringType().optional() }),
	head: () => ({ meta: [
		{ title: "Chat & Scan — Dentist AI" },
		{
			name: "description",
			content: "Ask dental questions in plain language or scan a tooth photo or X-ray."
		},
		{
			property: "og:title",
			content: "Chat & Scan — Dentist AI"
		},
		{
			property: "og:description",
			content: "Ask dental questions or scan a tooth photo or X-ray."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
