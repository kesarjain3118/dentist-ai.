import { a as require_jsx_runtime } from "../_libs/@ai-sdk/react+[...].mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { B as ChevronRight, M as FileText } from "../_libs/lucide-react.mjs";
import { n as getCondition } from "./conditions-2iG2DNG0.mjs";
import { i as statusLabel, n as reportsQuery, r as signedUrls } from "./reports-Cvt1IHHS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/report-list-CuQpbBwM.js
var import_jsx_runtime = require_jsx_runtime();
function useReports() {
	return useQuery(reportsQuery);
}
function useThumbs(reports) {
	const paths = (reports ?? []).map((r) => r.image_path);
	return useQuery({
		queryKey: ["thumbs", paths],
		queryFn: () => signedUrls(paths),
		enabled: paths.length > 0,
		staleTime: 18e5
	});
}
function ReportList({ limit }) {
	const { data, isLoading, error } = useReports();
	const items = limit ? data?.slice(0, limit) : data;
	const thumbs = useThumbs(items);
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-3",
		children: [
			0,
			1,
			2
		].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-20 animate-pulse rounded-2xl bg-secondary" }, i))
	});
	if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-attention",
		children: "We couldn't load your reports. Please refresh."
	});
	if (!items?.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-3xl border border-dashed border-border p-10 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, {
				className: "mx-auto h-8 w-8 text-muted-foreground",
				strokeWidth: 1.5
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 font-semibold",
				children: "No reports yet"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Your analyses will appear here once you upload an image."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/analyze",
				className: "mt-5 inline-flex rounded-full bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground",
				children: "Analyze an Image"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "divide-y divide-border overflow-hidden rounded-3xl border border-border bg-card",
		children: items.map((r) => {
			const date = new Date(r.created_at);
			const names = r.result.findings.map((f) => getCondition(f.name).plain);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/reports/$id",
				params: { id: r.id },
				className: "flex items-center gap-4 p-4 transition hover:bg-secondary/60",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-14 w-14 shrink-0 overflow-hidden rounded-xl bg-secondary",
						children: thumbs.data?.[r.image_path] && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: thumbs.data[r.image_path],
							alt: "",
							className: "h-full w-full object-cover",
							loading: "lazy"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate font-semibold",
							children: names.length ? names.join(", ") : statusLabel[r.status] ?? r.status
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted-foreground",
							children: [
								r.image_type === "xray" ? "X-ray" : "Photo",
								" · ",
								date.toLocaleDateString(void 0, { dateStyle: "medium" })
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `hidden rounded-full px-3 py-1 text-xs font-semibold sm:inline ${r.status === "complete" ? "bg-moderate-soft text-moderate" : r.status === "no_findings" ? "bg-calm-soft text-calm" : "bg-secondary text-muted-foreground"}`,
						children: statusLabel[r.status] ?? r.status
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4 text-muted-foreground" })
				]
			}) }, r.id);
		})
	});
}
//#endregion
export { useReports as n, ReportList as t };
