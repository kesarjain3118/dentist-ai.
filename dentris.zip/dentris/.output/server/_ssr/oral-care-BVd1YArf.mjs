import { i as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/@ai-sdk/react+[...].mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { p as Search, q as ArrowRight } from "../_libs/lucide-react.mjs";
import { t as CONDITIONS } from "./conditions-2iG2DNG0.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as TIPS } from "./tips-3V987a7z.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/oral-care-BVd1YArf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-base shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
		ref,
		...props
	});
});
Input.displayName = "Input";
var TABS = [
	"All",
	...[...new Set(TIPS.map((t) => t.group))],
	"Conditions"
];
function OralCare() {
	const [tab, setTab] = (0, import_react.useState)("All");
	const [q, setQ] = (0, import_react.useState)("");
	const term = q.trim().toLowerCase();
	const tips = (0, import_react.useMemo)(() => TIPS.filter((t) => (tab === "All" || t.group === tab) && (!term || `${t.title} ${t.body}`.toLowerCase().includes(term))), [tab, term]);
	const conditions = Object.values(CONDITIONS).filter((c) => !term || `${c.title} ${c.plain} ${c.summary}`.toLowerCase().includes(term));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "border-b border-border pb-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-semibold tracking-tight",
					children: "Care & learn"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Evidence-based habits and plain-language guidance."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sticky top-14 z-10 -mx-4 flex flex-col gap-3 bg-background/90 px-4 py-4 backdrop-blur sm:mx-0 sm:flex-row sm:items-center sm:justify-between sm:px-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "-mx-1 flex gap-1 overflow-x-auto px-1",
					role: "tablist",
					children: TABS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						role: "tab",
						"aria-selected": tab === t,
						onClick: () => setTab(t),
						className: `shrink-0 rounded-md px-3 py-1.5 text-sm transition-colors ${tab === t ? "bg-foreground text-background" : "text-muted-foreground hover:bg-secondary hover:text-foreground"}`,
						children: t
					}, t))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative sm:w-56",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: q,
						onChange: (e) => setQ(e.target.value),
						placeholder: "Search",
						className: "h-9 pl-9",
						"aria-label": "Search guidance"
					})]
				})]
			}),
			tab === "Conditions" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "divide-y divide-border rounded-xl border border-border bg-card",
				children: [conditions.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/learn/$key",
					params: { key: c.key },
					className: "flex items-center justify-between gap-4 px-5 py-4 transition-colors hover:bg-secondary/50",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: c.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-0.5 line-clamp-1 text-sm text-muted-foreground",
							children: c.summary
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4 shrink-0 text-muted-foreground" })]
				}) }, c.key)), !conditions.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "divide-y divide-border rounded-xl border border-border bg-card",
				children: [tips.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "grid gap-1 px-5 py-4 sm:grid-cols-[9rem_1fr] sm:gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-medium uppercase tracking-wide text-muted-foreground sm:pt-0.5",
						children: t.group
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: t.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-0.5 text-sm leading-relaxed text-muted-foreground",
						children: t.body
					})] })]
				}, t.title)), !tips.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {})]
			})
		]
	});
}
function Empty() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
		className: "px-5 py-10 text-center text-sm text-muted-foreground",
		children: "No matches."
	});
}
//#endregion
export { OralCare as component };
