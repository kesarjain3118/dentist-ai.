import { i as __toESM } from "../_runtime.mjs";
import { t as createClient } from "../_libs/supabase__supabase-js.mjs";
import { t as supabase } from "./client-DHTyM8tX.mjs";
import { a as require_jsx_runtime, i as streamText, o as require_react, r as convertToModelMessages } from "../_libs/@ai-sdk/react+[...].mjs";
import { t as AuthProvider } from "./auth-DeMeG-kQ.mjs";
import { G as redirect, _ as createFileRoute, d as Scripts, f as HeadContent, g as lazyRouteComponent, h as Outlet, m as createRouter, v as createRootRouteWithContext, x as useRouter, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { r as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as Route$11 } from "./ask-CoA4CNmx.mjs";
import { t as CONDITIONS } from "./conditions-2iG2DNG0.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { t as Route$12 } from "./auth-BmxD1dwF.mjs";
import { t as Route$13 } from "./learn._key-BrNnS7iV.mjs";
import { t as getLocation } from "./locations-CUJ9MYA2.mjs";
import { t as Route$14 } from "./reports._id-DRmyEp-7.mjs";
import { t as createGroq } from "../_libs/@ai-sdk/groq+[...].mjs";
import processModule from "node:process";
//#region node_modules/.nitro/vite/services/ssr/assets/router-Dt6G3MH_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-CVNT77pb.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message,
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
var KEY = "chunk-reload-at";
var WINDOW_MS = 15e3;
function isStaleChunkError(error) {
	const msg = String(error?.message ?? error ?? "");
	return msg.includes("dynamically imported module") || msg.includes("Importing a module script failed") || msg.includes("Unable to preload CSS") || msg.includes("Failed to load module script") || /reading '(component|errorComponent|pendingComponent|notFoundComponent)'/.test(msg);
}
/** Reloads with a cache-busting param. Returns false if we already tried recently. */
function reloadForFreshBuild() {
	if (typeof window === "undefined") return false;
	const last = Number(sessionStorage.getItem(KEY) ?? 0);
	if (Date.now() - last < WINDOW_MS) return false;
	sessionStorage.setItem(KEY, String(Date.now()));
	const url = new URL(window.location.href);
	url.searchParams.set("v", String(Date.now()));
	window.location.replace(url.toString());
	return true;
}
function installChunkReloadGuard() {
	if (typeof window === "undefined") return;
	window.addEventListener("vite:preloadError", (event) => {
		event.preventDefault();
		reloadForFreshBuild();
	});
	window.addEventListener("unhandledrejection", (event) => {
		if (isStaleChunkError(event.reason) && reloadForFreshBuild()) event.preventDefault();
	});
	const url = new URL(window.location.href);
	if (url.searchParams.has("v")) {
		url.searchParams.delete("v");
		window.history.replaceState(window.history.state, "", url.toString());
	}
}
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	});
};
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-full bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	const router = useRouter();
	const isStaleChunk = isStaleChunkError(error);
	(0, import_react.useEffect)(() => {
		if (isStaleChunk) {
			reloadForFreshBuild();
			return;
		}
		console.error(error);
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error, isStaleChunk]);
	if (isStaleChunk) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "Dentist AI was updated"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Loading the latest version…"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => window.location.reload(),
					className: "mt-6 inline-flex items-center justify-center rounded-full bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground hover:bg-primary/90",
					children: "Refresh now"
				})
			]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-full bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-full border border-input bg-background px-5 py-2.5 text-sm font-medium text-foreground hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$10 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Dentist AI — Understand your dental health with AI" },
			{
				name: "description",
				content: "Upload a dental photo or X-ray and get simple, AI-assisted insights about what may be visible."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				href: "/favicon.png",
				type: "image/png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&display=swap"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$10.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, { position: "top-center" })] })
	});
}
var $$splitComponentImporter$8 = () => import("./routes-DoSLafr0.mjs");
var Route$9 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "AI Dental Image Insights — Dentist AI" },
		{
			name: "description",
			content: "Upload a dental photo or X-ray and get simple, AI-assisted insights about what may be visible."
		},
		{
			property: "og:title",
			content: "Dentist AI — Understand your dental health with AI"
		},
		{
			property: "og:description",
			content: "A clearer way to understand your smile."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./route-CGRg20Ld.mjs");
var Route$8 = createFileRoute("/_authenticated")({
	ssr: false,
	beforeLoad: async ({ location }) => {
		const { data } = await supabase.auth.getSession();
		if (!data.session) throw redirect({
			to: "/auth",
			search: { redirect: location.href }
		});
	},
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./reset-password-DnCzOIaS.mjs");
var Route$7 = createFileRoute("/reset-password")({
	head: () => ({ meta: [
		{ title: "Set a new password — Dentist AI" },
		{
			name: "description",
			content: "Choose a new password for your Dentist AI account."
		},
		{
			property: "og:title",
			content: "Set a new password — Dentist AI"
		},
		{
			property: "og:description",
			content: "Choose a new password for your Dentist AI account."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./analyze-CTUtDcFM.mjs");
var Route$6 = createFileRoute("/_authenticated/analyze")({
	head: () => ({ meta: [
		{ title: "New analysis — Dentist AI" },
		{
			name: "description",
			content: "Upload a dental photo or X-ray for an AI-assisted analysis."
		},
		{
			property: "og:title",
			content: "New analysis — Dentist AI"
		},
		{
			property: "og:description",
			content: "Upload a dental photo or X-ray for an AI-assisted analysis."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./home-BHAucOLW.mjs");
var Route$5 = createFileRoute("/_authenticated/home")({
	head: () => ({ meta: [
		{ title: "Home — Dentist AI" },
		{
			name: "description",
			content: "Your dental health at a glance: recent analyses, guidance and oral-care tips."
		},
		{
			property: "og:title",
			content: "Home — Dentist AI"
		},
		{
			property: "og:description",
			content: "Your dental health at a glance."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./oral-care-BVd1YArf.mjs");
var Route$4 = createFileRoute("/_authenticated/oral-care")({
	head: () => ({ meta: [
		{ title: "Care & Learn — Dentist AI" },
		{
			name: "description",
			content: "Daily oral-care guidance and plain-language condition library."
		},
		{
			property: "og:title",
			content: "Care & Learn — Dentist AI"
		},
		{
			property: "og:description",
			content: "Daily oral-care guidance and plain-language condition library."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./settings-IGYLN8BF.mjs");
var Route$3 = createFileRoute("/_authenticated/settings")({
	head: () => ({ meta: [
		{ title: "Settings — Dentist AI" },
		{
			name: "description",
			content: "Manage your profile, privacy and data."
		},
		{
			property: "og:title",
			content: "Settings — Dentist AI"
		},
		{
			property: "og:description",
			content: "Manage your profile, privacy and data."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var GROQ_MODEL = "openai/gpt-oss-120b";
function json(status, error) {
	return new Response(JSON.stringify({ error }), {
		status,
		headers: { "Content-Type": "application/json" }
	});
}
function userClient(token) {
	const url = processModule.env["SUPABASE_URL"];
	const key = processModule.env["SUPABASE_PUBLISHABLE_KEY"];
	return createClient(url, key, {
		auth: {
			persistSession: false,
			autoRefreshToken: false
		},
		global: { fetch: (input, init) => {
			const h = new Headers(init?.headers);
			h.set("apikey", key);
			h.set("Authorization", `Bearer ${token}`);
			return fetch(input, {
				...init,
				headers: h
			});
		} }
	});
}
function systemPrompt(result, createdAt) {
	const findings = result.findings.map((f) => {
		const c = CONDITIONS[f.name];
		return `- ${c?.title ?? f.name} (${c?.plain ?? ""}) — model confidence ${Math.round(f.confidence * 100)}% — estimated location: ${getLocation(f.location).label}`;
	});
	return `You are Dentist AI, a calm, warm assistant that helps everyday people understand an AI dental image analysis.

STRICT RULES
- You did NOT see the image. You only know the structured output of a specialised dental vision model shown below. Never claim to see or re-analyse the image, and never add findings that are not listed.
- Never diagnose. Use "possible", "may", "could be consistent with". Never say "you have X".
- Model confidence is not medical certainty. A qualified dentist must confirm any condition.
- Be reassuring and non-alarming. Prefer "needs attention" or "consider professional evaluation" over scary wording.
- If the user describes severe pain, facial swelling, fever, trouble swallowing or breathing, or trauma, advise contacting a dentist or emergency services promptly.
- Give general, safe oral-care guidance only. Do not prescribe medication doses.
- Keep answers short (under ~180 words), use simple language and short bullet lists where helpful. International audience: no country-specific assumptions.

STRUCTURED MODEL OUTPUT (analysis from ${createdAt})
Image type: ${result.imageType === "xray" ? "Dental X-ray" : "Dental photo"}
Status: ${result.status}
Findings:
${findings.length ? findings.join("\n") : "- None above the confidence threshold"}
Pipeline summary: ${result.explanation}
${result.model.isMock ? "Note: this result came from a sample model used for demonstration; mention this if the user asks about accuracy." : ""}`;
}
var GENERAL_PROMPT = `You are Dentist AI, a calm, warm assistant that answers general dental and oral-health questions for everyday people.
- You have not seen any image. If the user wants an image reviewed, tell them to use "Add image" to run a scan.
- Never diagnose. Use "possible", "may", "could". A qualified dentist must confirm any condition.
- If the user describes severe pain, facial swelling, fever, trouble swallowing or breathing, or trauma, advise contacting a dentist or emergency services promptly.
- Do not prescribe medication doses. Keep answers short (under ~180 words), simple, with short bullet lists where helpful. International audience.`;
async function handleChat(request) {
	const auth = request.headers.get("authorization");
	const token = auth?.startsWith("Bearer ") ? auth.slice(7) : null;
	if (!token) return json(401, "Please sign in again.");
	let body;
	try {
		body = await request.json();
	} catch {
		return json(400, "Invalid request.");
	}
	const { messages, analysisId } = body;
	if (!Array.isArray(messages) || !messages.length || analysisId !== void 0 && typeof analysisId !== "string") return json(400, "Invalid request.");
	const supabase = userClient(token);
	const { data: userData, error: userErr } = await supabase.auth.getUser(token);
	if (userErr || !userData.user) return json(401, "Please sign in again.");
	let analysis = null;
	if (analysisId) {
		const { data } = await supabase.from("analyses").select("id,result,created_at").eq("id", analysisId).maybeSingle();
		if (!data) return json(404, "Report not found.");
		analysis = data;
	}
	const last = messages[messages.length - 1];
	const lastText = last?.parts?.map((p) => p.type === "text" ? p.text : "").join("") ?? "";
	if (analysisId && last?.role === "user" && lastText.trim()) {
		const { error } = await supabase.from("chat_messages").insert({
			analysis_id: analysisId,
			role: "user",
			content: lastText.slice(0, 4e3)
		});
		if (error) console.error("save user message failed", error);
	}
	const groqKey = processModule.env["GROQ_API_KEY"];
	if (!groqKey) return json(500, "AI is not configured.");
	const model = createGroq({ apiKey: groqKey })(GROQ_MODEL);
	return streamText({
		model,
		system: analysis ? systemPrompt(analysis.result, new Date(analysis.created_at).toDateString()) : GENERAL_PROMPT,
		messages: await convertToModelMessages(messages.slice(-20)),
		abortSignal: request.signal
	}).toUIMessageStreamResponse({
		originalMessages: messages,
		onFinish: async ({ responseMessage }) => {
			const text = responseMessage.parts.map((p) => p.type === "text" ? p.text : "").join("");
			if (!text.trim() || !analysisId) return;
			const { error } = await supabase.from("chat_messages").insert({
				analysis_id: analysisId,
				role: "assistant",
				content: text
			});
			if (error) console.error("save assistant message failed", error);
		},
		onError: (err) => {
			console.error("chat stream error", err);
			const status = err?.statusCode;
			if (status === 429) return "Dentist AI is busy right now. Please try again in a moment.";
			if (status === 402) return "AI credits have run out for this workspace.";
			return "Something went wrong while answering. Please try again.";
		}
	});
}
var Route$2 = createFileRoute("/api/chat")({ server: { handlers: { POST: ({ request }) => handleChat(request) } } });
var $$splitComponentImporter$1 = () => import("./learn.index-BoR_tY2_.mjs");
var Route$1 = createFileRoute("/_authenticated/learn/")({
	head: () => ({ meta: [
		{ title: "Learn — Dentist AI" },
		{
			name: "description",
			content: "Simple, trustworthy explanations of common dental conditions."
		},
		{
			property: "og:title",
			content: "Learn — Dentist AI"
		},
		{
			property: "og:description",
			content: "Simple explanations of common dental conditions."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./reports.index-bKOdadiz.mjs");
var Route = createFileRoute("/_authenticated/reports/")({
	head: () => ({ meta: [
		{ title: "My Reports — Dentist AI" },
		{
			name: "description",
			content: "All your saved dental analyses in one place."
		},
		{
			property: "og:title",
			content: "My Reports — Dentist AI"
		},
		{
			property: "og:description",
			content: "All your saved dental analyses in one place."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var IndexRoute = Route$9.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$10
});
var AuthenticatedRouteRoute = Route$8.update({
	id: "/_authenticated",
	getParentRoute: () => Route$10
});
var AuthRoute = Route$12.update({
	id: "/auth",
	path: "/auth",
	getParentRoute: () => Route$10
});
var ResetPasswordRoute = Route$7.update({
	id: "/reset-password",
	path: "/reset-password",
	getParentRoute: () => Route$10
});
var AuthenticatedAnalyzeRoute = Route$6.update({
	id: "/analyze",
	path: "/analyze",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedAskRoute = Route$11.update({
	id: "/ask",
	path: "/ask",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedHomeRoute = Route$5.update({
	id: "/home",
	path: "/home",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedOralCareRoute = Route$4.update({
	id: "/oral-care",
	path: "/oral-care",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedSettingsRoute = Route$3.update({
	id: "/settings",
	path: "/settings",
	getParentRoute: () => AuthenticatedRouteRoute
});
var ApiChatRoute = Route$2.update({
	id: "/api/chat",
	path: "/api/chat",
	getParentRoute: () => Route$10
});
var AuthenticatedLearnIndexRoute = Route$1.update({
	id: "/learn/",
	path: "/learn/",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedLearnKeyRoute = Route$13.update({
	id: "/learn/$key",
	path: "/learn/$key",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedReportsIndexRoute = Route.update({
	id: "/reports/",
	path: "/reports/",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedRouteRouteChildren = {
	AuthenticatedAnalyzeRoute,
	AuthenticatedAskRoute,
	AuthenticatedHomeRoute,
	AuthenticatedOralCareRoute,
	AuthenticatedSettingsRoute,
	AuthenticatedLearnKeyRoute,
	AuthenticatedReportsIdRoute: Route$14.update({
		id: "/reports/$id",
		path: "/reports/$id",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedLearnIndexRoute,
	AuthenticatedReportsIndexRoute
};
var rootRouteChildren = {
	IndexRoute,
	AuthenticatedRouteRoute: AuthenticatedRouteRoute._addFileChildren(AuthenticatedRouteRouteChildren),
	AuthRoute,
	ResetPasswordRoute,
	ApiChatRoute
};
var routeTree = Route$10._addFileChildren(rootRouteChildren)._addFileTypes();
installChunkReloadGuard();
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
