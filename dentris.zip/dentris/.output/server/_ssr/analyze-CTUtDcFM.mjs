import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-DHTyM8tX.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/@ai-sdk/react+[...].mjs";
import { r as useAuth } from "./auth-DeMeG-kQ.mjs";
import { n as analyzeImage, r as validateFile, t as AnalysisError } from "./service-D4-qO_vv.mjs";
import { b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { H as Check, J as ArrowLeft, O as ImageUp, U as Camera, h as ScanLine, z as CircleAlert } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/analyze-CTUtDcFM.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STEPS = [
	"Checking image quality",
	"Analyzing dental patterns",
	"Looking for possible findings",
	"Preparing your results"
];
function Analyze() {
	const [phase, setPhase] = (0, import_react.useState)("choose");
	const [type, setType] = (0, import_react.useState)("photo");
	const [file, setFile] = (0, import_react.useState)(null);
	const [preview, setPreview] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const [step, setStep] = (0, import_react.useState)(0);
	const [drag, setDrag] = (0, import_react.useState)(false);
	const input = (0, import_react.useRef)(null);
	const cameraInput = (0, import_react.useRef)(null);
	const { user } = useAuth();
	const navigate = useNavigate();
	const qc = useQueryClient();
	(0, import_react.useEffect)(() => () => {
		if (preview) URL.revokeObjectURL(preview);
	}, [preview]);
	const [modelProgress, setModelProgress] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		let off;
		import("./browser-model-B_fBxVkG.mjs").then(async (m) => {
			const unsub = m.onModelProgress(setModelProgress);
			off = () => {
				unsub();
			};
			if (type === "xray") (await import("./xray-model-CaNySZ4Q.mjs")).preloadXrayModel().catch(() => {});
			else m.preloadModel().catch(() => {});
		});
		return () => off?.();
	}, [type]);
	const modelReady = modelProgress >= 1;
	function pick(f) {
		if (!f) return;
		try {
			validateFile(f);
			setFile(f);
			setPreview(URL.createObjectURL(f));
			setError(null);
		} catch (e) {
			setError(e instanceof Error ? e.message : "Unsupported file.");
		}
	}
	function onDrop(e) {
		e.preventDefault();
		setDrag(false);
		pick(e.dataTransfer.files?.[0]);
	}
	async function run() {
		if (!file || !user) return;
		setPhase("processing");
		setStep(0);
		const timer = setInterval(() => setStep((s) => Math.min(s + 1, STEPS.length - 1)), 900);
		try {
			const ext = file.name.split(".").pop() || "jpg";
			const path = `${user.id}/${crypto.randomUUID()}.${ext}`;
			const upload = supabase.storage.from("dental-images").upload(path, file, { contentType: file.type });
			const [up, result] = await Promise.all([upload, analyzeImage(file, type)]);
			if (up.error) throw new AnalysisError("upload_failed", "Your image couldn't be uploaded. Please try again.");
			const { data, error: dbErr } = await supabase.from("analyses").insert({
				image_type: type,
				image_path: path,
				status: result.status,
				result: JSON.parse(JSON.stringify(result))
			}).select("id").single();
			if (dbErr) throw new AnalysisError("api_error", "We couldn't save your report. Please try again.");
			clearInterval(timer);
			setStep(STEPS.length);
			await qc.invalidateQueries({ queryKey: ["reports"] });
			setTimeout(() => navigate({
				to: "/reports/$id",
				params: { id: data.id }
			}), 400);
		} catch (e) {
			clearInterval(timer);
			setError(e instanceof Error ? e.message : "Something went wrong.");
			setPhase("error");
		}
	}
	if (phase === "processing") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl py-10 text-center animate-rise",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto aspect-square w-64 overflow-hidden rounded-4xl bg-foreground/90 shadow-float",
				children: [preview && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: preview,
					alt: "",
					className: "h-full w-full object-cover opacity-80"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-0 h-1/3 animate-scan bg-gradient-to-b from-transparent via-brand/30 to-transparent" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-10 text-3xl font-bold",
				children: "Analyzing your image"
			}),
			!modelReady && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto mt-4 max-w-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground",
					children: [
						"Preparing the AI engine (first time only) · ",
						Math.round(modelProgress * 100),
						"%"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 h-1.5 overflow-hidden rounded-full bg-secondary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full bg-brand transition-all",
						style: { width: `${Math.round(modelProgress * 100)}%` }
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mx-auto mt-8 max-w-xs space-y-4 text-left",
				children: STEPS.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: `flex items-center gap-3 transition-opacity ${i <= step ? "opacity-100" : "opacity-35"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `flex h-6 w-6 items-center justify-center rounded-full ${i < step ? "bg-calm text-primary-foreground" : i === step ? "border-2 border-brand" : "border border-border"}`,
						children: i < step ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3.5 w-3.5" }) : i === step ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2 w-2 animate-pulse rounded-full bg-brand" }) : null
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[15px] text-foreground",
						children: s
					})]
				}, s))
			}),
			modelReady && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-8 flex items-center justify-center gap-2 text-sm text-muted-foreground animate-pulse",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-1.5 animate-ping rounded-full bg-brand" }), "Almost there — uploading your image and saving the report"]
			})
		]
	});
	if (phase === "error") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-md py-16 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "mx-auto h-10 w-10 text-attention" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-5 text-2xl font-bold",
				children: "We couldn't finish the analysis"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted-foreground",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex justify-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: run,
					className: "rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground",
					children: "Try again"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => {
						setPhase("upload");
						setError(null);
					},
					className: "rounded-full px-6 py-3 font-semibold hover:bg-secondary",
					children: "Choose another image"
				})]
			})
		]
	});
	if (phase === "choose") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl py-6 animate-rise",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-bold sm:text-5xl",
				children: "What would you like to analyze?"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-base text-muted-foreground sm:text-lg",
				children: "Different images are analyzed by different specialised models."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 grid gap-5 sm:grid-cols-2",
				children: [{
					t: "photo",
					icon: Camera,
					title: "Dental Photo",
					d: "Upload a clear photo of your teeth or gums."
				}, {
					t: "xray",
					icon: ScanLine,
					title: "Dental X-Ray",
					d: "Upload a supported panoramic or dental X-ray."
				}].map(({ t, icon: Icon, title, d }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => {
						setType(t);
						setPhase("upload");
					},
					className: "surface group p-8 text-left transition hover:-translate-y-1 hover:shadow-float",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-soft text-brand",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-6 w-6" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-8 text-2xl font-semibold",
							children: title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-muted-foreground",
							children: d
						})
					]
				}, t))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 flex justify-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EngineStatus, {
					ready: modelReady,
					progress: modelProgress
				})
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl py-6 animate-rise",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => {
					setPhase("choose");
					setFile(null);
					setPreview(null);
				},
				className: "mb-6 flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), " Back"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "text-2xl font-bold sm:text-4xl",
				children: ["Upload ", type === "photo" ? "a dental photo" : "a dental X-ray"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EngineStatus, {
					ready: modelReady,
					progress: modelProgress
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				onDragOver: (e) => {
					e.preventDefault();
					setDrag(true);
				},
				onDragLeave: () => setDrag(false),
				onDrop,
				onClick: () => input.current?.click(),
				role: "button",
				tabIndex: 0,
				onKeyDown: (e) => e.key === "Enter" && input.current?.click(),
				className: `mt-8 flex min-h-72 cursor-pointer flex-col items-center justify-center rounded-4xl border-2 border-dashed p-8 text-center transition ${drag ? "border-brand bg-brand-soft" : "border-border bg-card hover:border-brand/50"}`,
				children: [preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: preview,
					alt: "Selected image preview",
					className: "max-h-80 rounded-2xl object-contain"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageUp, {
						className: "h-10 w-10 text-brand",
						strokeWidth: 1.5
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 text-lg font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden sm:inline",
							children: "Drag and drop your image"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "sm:hidden",
							children: "Tap to choose an image"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden sm:inline",
							children: "or click to choose a file · "
						}), "JPG, PNG or WebP up to 15 MB"]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: input,
					type: "file",
					accept: "image/jpeg,image/png,image/webp",
					className: "hidden",
					onChange: (e) => pick(e.target.files?.[0])
				})]
			}),
			type === "photo" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => cameraInput.current?.click(),
				className: "mt-3 flex w-full items-center justify-center gap-2 rounded-2xl border border-border bg-card py-3.5 text-sm font-semibold text-foreground transition hover:bg-secondary sm:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "h-4 w-4 text-brand" }), " Take a photo with your camera"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: cameraInput,
				type: "file",
				accept: "image/*",
				capture: "environment",
				className: "hidden",
				onChange: (e) => pick(e.target.files?.[0])
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 flex items-center gap-2 text-sm text-attention",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "h-4 w-4" }),
					" ",
					error
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 grid gap-6 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold",
					children: "For best results"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 space-y-1.5 text-sm text-muted-foreground",
					children: (type === "photo" ? [
						"Use bright, even light",
						"Keep the camera steady and in focus",
						"Show the area close-up and straight on",
						"Gently pull lips back"
					] : [
						"Use the original digital file if possible",
						"Avoid photos of a screen with glare",
						"Include the whole X-ray",
						"Panoramic and bitewing X-rays work best"
					]).map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 h-4 w-4 shrink-0 text-calm" }), t]
					}, t))
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-end justify-end gap-3",
					children: [file && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							setFile(null);
							setPreview(null);
						},
						className: "rounded-full px-5 py-3 font-semibold hover:bg-secondary",
						children: "Remove"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						disabled: !file,
						onClick: run,
						className: "rounded-full bg-primary px-7 py-3.5 font-semibold text-primary-foreground shadow-float disabled:opacity-40",
						children: "Analyze image"
					})]
				})]
			})
		]
	});
}
function EngineStatus({ ready, progress }) {
	if (ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "flex items-center gap-2 text-sm text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4 text-calm" }), " AI engine ready on this device"]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-xs",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-sm text-muted-foreground",
			children: [
				"Getting the AI engine ready (first time only) · ",
				Math.round(progress * 100),
				"%"
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 h-1.5 overflow-hidden rounded-full bg-secondary",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-full bg-brand transition-all",
				style: { width: `${Math.max(4, Math.round(progress * 100))}%` }
			})
		})]
	});
}
//#endregion
export { Analyze as component };
