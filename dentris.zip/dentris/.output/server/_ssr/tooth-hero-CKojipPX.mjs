//#region node_modules/.nitro/vite/services/ssr/assets/tooth-hero-CKojipPX.js
var tooth_hero_default = "/assets/tooth-hero-R2iYMrzu.jpg";
//#endregion
export { tooth_hero_default as t };
