import { _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as objectType, r as stringType, t as enumType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-BmxD1dwF.js
var $$splitComponentImporter = () => import("./auth-CuG9FtDq.mjs");
var search = objectType({
	redirect: stringType().optional(),
	mode: enumType(["signin", "signup"]).optional()
});
var Route = createFileRoute("/auth")({
	validateSearch: search,
	head: () => ({ meta: [
		{ title: "Sign in — Dentist AI" },
		{
			name: "description",
			content: "Sign in to Dentist AI to analyze dental photos and X-rays and view your saved reports."
		},
		{
			property: "og:title",
			content: "Sign in — Dentist AI"
		},
		{
			property: "og:description",
			content: "Understand your dental health with AI."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
