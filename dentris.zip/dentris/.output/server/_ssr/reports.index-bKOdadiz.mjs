import { i as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/@ai-sdk/react+[...].mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { _ as Plus, a as TrendingDown, i as TrendingUp, v as Minus } from "../_libs/lucide-react.mjs";
import { n as getCondition, r as pct } from "./conditions-2iG2DNG0.mjs";
import { n as reportsQuery, r as signedUrls } from "./reports-Cvt1IHHS.mjs";
import { t as ReportList } from "./report-list-CuQpbBwM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reports.index-bKOdadiz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function topFinding(r) {
	const fs = r.result.findings ?? [];
	return fs.length ? fs.reduce((a, b) => b.confidence > a.confidence ? b : a) : void 0;
}
/** Chronological scan history with per-condition confidence trends. */
function ScanTimeline() {
	const { data: reports } = useQuery(reportsQuery);
	const [thumbs, setThumbs] = (0, import_react.useState)({});
	const ordered = (0, import_react.useMemo)(() => [...reports ?? []].sort((a, b) => a.created_at.localeCompare(b.created_at)), [reports]);
	(0, import_react.useEffect)(() => {
		const paths = ordered.map((r) => r.image_path);
		if (!paths.length) return;
		let on = true;
		signedUrls(paths).then((m) => {
			if (on) setThumbs(m);
		});
		return () => {
			on = false;
		};
	}, [ordered]);
	const trends = (0, import_react.useMemo)(() => {
		const lastSeen = {};
		const map = {};
		for (const r of ordered) {
			const top = topFinding(r);
			if (!top) continue;
			const prev = lastSeen[top.name];
			map[r.id] = prev === void 0 ? void 0 : top.confidence > prev + .02 ? "up" : top.confidence < prev - .02 ? "down" : "same";
			lastSeen[top.name] = top.confidence;
		}
		return map;
	}, [ordered]);
	if (!ordered.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "surface p-5 sm:p-6",
		"aria-labelledby": "scan-timeline",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				id: "scan-timeline",
				className: "text-xl font-bold",
				children: "Scan timeline"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Your scans over time. Arrows show how the same finding's confidence changed since the previous matching scan."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 flex gap-4 overflow-x-auto pb-2",
				children: ordered.map((r) => {
					const top = topFinding(r);
					const c = top ? getCondition(top.name) : void 0;
					const trend = trends[r.id];
					const date = new Date(r.created_at);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/reports/$id",
						params: { id: r.id },
						className: "group w-36 shrink-0 rounded-2xl border border-border bg-card p-2.5 transition hover:border-primary/40",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-24 overflow-hidden rounded-xl bg-secondary",
								children: thumbs[r.image_path] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: thumbs[r.image_path],
									alt: "",
									className: "h-full w-full object-cover transition group-hover:scale-105"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex h-full items-center justify-center text-xs text-muted-foreground",
									children: "…"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs font-medium text-muted-foreground",
								children: date.toLocaleDateString(void 0, {
									month: "short",
									day: "numeric"
								})
							}),
							top && c ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-0.5 flex items-center gap-1 text-sm font-semibold text-foreground",
								children: [c.plain, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "ml-auto flex items-center gap-0.5 text-xs font-medium text-muted-foreground",
									children: [
										trend === "up" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "h-3.5 w-3.5 text-attention" }),
										trend === "down" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingDown, { className: "h-3.5 w-3.5 text-calm" }),
										trend === "same" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "h-3.5 w-3.5" }),
										pct(top.confidence)
									]
								})]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-0.5 text-sm text-muted-foreground",
								children: "No clear finding"
							})
						]
					}, r.id);
				})
			})
		]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
	className: "mx-auto max-w-4xl space-y-8",
	children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-4xl font-bold",
				children: "My Reports"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted-foreground",
				children: "Every analysis you've run, saved privately to your account."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/analyze",
				className: "flex items-center gap-2 rounded-full bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " New Analysis"]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanTimeline, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportList, {})
	]
});
//#endregion
export { SplitComponent as component };
