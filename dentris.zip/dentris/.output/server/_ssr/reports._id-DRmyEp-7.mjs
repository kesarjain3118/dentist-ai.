import { _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reports._id-DRmyEp-7.js
var $$splitComponentImporter = () => import("./reports._id-CNvI-L_x.mjs");
var Route = createFileRoute("/_authenticated/reports/$id")({
	head: () => ({ meta: [
		{ title: "Your analysis — Dentist AI" },
		{
			name: "description",
			content: "AI-assisted dental analysis results with explanations and next steps."
		},
		{
			property: "og:title",
			content: "Your analysis — Dentist AI"
		},
		{
			property: "og:description",
			content: "AI-assisted dental analysis results."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
