//#region node_modules/.nitro/vite/services/ssr/assets/service-D4-qO_vv.js
/**
* Realistic SAMPLE responses used until a real model endpoint is configured.
* Numbers here are illustrative only — they are not model metrics.
* The scenario is chosen deterministically from the file so results are repeatable.
*/
function hash(input) {
	let h = 0;
	for (let i = 0; i < input.length; i++) h = h * 31 + input.charCodeAt(i) | 0;
	return Math.abs(h);
}
async function mockAnalyze(file, imageType) {
	const started = Date.now();
	await new Promise((r) => setTimeout(r, 900));
	const scenario = hash(`${file.name}:${file.size}`) % 10;
	const base = {
		imageType,
		supported: true,
		model: {
			id: imageType === "xray" ? "dental-xray-mock" : "dental-photo-mock",
			version: "0.0-sample",
			isMock: true
		},
		durationMs: 0
	};
	if (scenario === 7) return {
		...base,
		status: "no_findings",
		findings: [],
		explanation: "No notable areas were found in this image. That is a good sign, but an image cannot show everything.",
		recommendations: ["Keep up regular brushing and cleaning between teeth.", "Continue routine dental check-ups."],
		durationMs: Date.now() - started
	};
	if (scenario === 8) return {
		...base,
		status: "low_confidence",
		findings: [],
		explanation: "We couldn't confidently analyze this image. Lighting, angle or focus may have affected the result.",
		recommendations: ["Try a sharper, well-lit image taken straight on.", "A dentist can examine areas a photo cannot show."],
		durationMs: Date.now() - started
	};
	const findings = imageType === "xray" ? [
		{
			name: "impacted_tooth",
			confidence: .86,
			location: "lower_right_wisdom",
			bbox: {
				x: .74,
				y: .52,
				w: .14,
				h: .26
			}
		},
		{
			name: "caries",
			confidence: .73,
			location: "upper_left_molar",
			bbox: {
				x: .22,
				y: .3,
				w: .1,
				h: .16
			}
		},
		...scenario % 2 === 0 ? [{
			name: "bone_loss",
			confidence: .61,
			location: "lower_front",
			bbox: {
				x: .44,
				y: .6,
				w: .14,
				h: .14
			}
		}] : []
	] : [
		{
			name: "caries",
			confidence: .92,
			location: "upper_left_molar",
			bbox: {
				x: .24,
				y: .22,
				w: .2,
				h: .36
			}
		},
		{
			name: "calculus",
			confidence: .78,
			location: "lower_left_molar",
			bbox: {
				x: .58,
				y: .42,
				w: .15,
				h: .34
			}
		},
		...scenario !== 9 ? [{
			name: "gingivitis",
			confidence: .71,
			location: "lower_front",
			bbox: {
				x: .42,
				y: .68,
				w: .12,
				h: .2
			}
		}] : []
	];
	return {
		...base,
		status: "complete",
		findings,
		explanation: "The image contains visual features that may be consistent with the possible findings listed. A dental professional should confirm them.",
		recommendations: [
			"Book a dental check-up to confirm these possible findings.",
			"Brush twice a day with fluoride toothpaste and clean between your teeth daily.",
			"Limit sugary snacks and drinks between meals."
		],
		durationMs: Date.now() - started
	};
}
var AnalysisError = class extends Error {
	code;
	constructor(code, message) {
		super(message);
		this.code = code;
	}
};
/** Findings below this are hidden and the result is treated as uncertain. */
var CONFIDENCE_FLOOR = .5;
/**
* Single entry point for dental image inference.
*
* Defaults to the user's ConvNeXt-Tiny server on Render. Override per image
* type with VITE_DENTAL_PHOTO_MODEL_URL / VITE_DENTAL_XRAY_MODEL_URL.
* Each endpoint receives multipart form-data { image, imageType } and must
* return JSON matching `AnalysisResult` (see ./types.ts). If the server can't
* be reached, a clearly labelled sample result is used so the app keeps working.
*/
var DEFAULT_MODEL_URL = "https://dentist-ai-server.onrender.com/predict";
var ENDPOINTS = {
	photo: {
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": true,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/",
		"VITE_SUPABASE_PROJECT_ID": "aivxdcvrjysrcdputmag",
		"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_rgE6Q7LOgOyiqfdPut9ouQ_arEtYfjW",
		"VITE_SUPABASE_URL": "https://aivxdcvrjysrcdputmag.supabase.co"
	}["VITE_DENTAL_PHOTO_MODEL_URL"] || DEFAULT_MODEL_URL,
	xray: {
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": true,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/",
		"VITE_SUPABASE_PROJECT_ID": "aivxdcvrjysrcdputmag",
		"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_rgE6Q7LOgOyiqfdPut9ouQ_arEtYfjW",
		"VITE_SUPABASE_URL": "https://aivxdcvrjysrcdputmag.supabase.co"
	}["VITE_DENTAL_XRAY_MODEL_URL"] || DEFAULT_MODEL_URL
};
/** Free Render servers sleep and take ~1 minute to wake up. */
var TIMEOUT_MS = 9e4;
var ACCEPTED_TYPES = [
	"image/jpeg",
	"image/png",
	"image/webp"
];
function validateFile(file) {
	if (!ACCEPTED_TYPES.includes(file.type)) throw new AnalysisError("invalid_file", "Please upload a JPG, PNG or WebP image.");
	if (file.size > 15728640) throw new AnalysisError("invalid_file", "This image is larger than 15 MB. Please choose a smaller file.");
}
function normalise(result) {
	const visible = (result.findings ?? []).filter((f) => f.confidence >= CONFIDENCE_FLOOR).sort((a, b) => b.confidence - a.confidence);
	if (result.status === "complete" && visible.length === 0) return {
		...result,
		status: "low_confidence",
		findings: []
	};
	return {
		...result,
		findings: visible
	};
}
async function analyzeImage(file, imageType) {
	validateFile(file);
	try {
		if (imageType === "xray") {
			const { detectXray } = await import("./xray-model-CaNySZ4Q.mjs");
			return normalise(await detectXray(file));
		}
		const { classifyInBrowser } = await import("./browser-model-B_fBxVkG.mjs");
		return normalise(await classifyInBrowser(file, imageType));
	} catch (e) {
		console.warn("In-browser model failed, trying model server:", e);
	}
	const body = new FormData();
	body.append("image", file);
	body.append("imageType", imageType);
	try {
		const res = await fetch(ENDPOINTS[imageType], {
			method: "POST",
			body,
			signal: AbortSignal.timeout(TIMEOUT_MS)
		});
		if (!res.ok) throw new Error(`status ${res.status}`);
		const json = await res.json();
		if (!json || !Array.isArray(json.findings) || !json.model) throw new Error("bad shape");
		return normalise({
			...json,
			imageType
		});
	} catch (e) {
		console.warn("Real model unavailable, using labelled sample result:", e);
		return normalise(await mockAnalyze(file, imageType));
	}
}
//#endregion
export { analyzeImage as n, validateFile as r, AnalysisError as t };
