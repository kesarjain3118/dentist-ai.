//#region node_modules/.nitro/vite/services/ssr/assets/tips-3V987a7z.js
var TIPS = [
	{
		title: "Two minutes, twice a day",
		body: "Brush for a full two minutes with fluoride toothpaste, morning and night.",
		group: "Daily routine"
	},
	{
		title: "Spit, don't rinse",
		body: "After brushing, spit out the toothpaste but avoid rinsing so fluoride keeps working.",
		group: "Daily routine"
	},
	{
		title: "Clean between your teeth",
		body: "Floss or interdental brushes reach the surfaces a toothbrush can't — once a day is enough.",
		group: "Daily routine"
	},
	{
		title: "Angle toward the gums",
		body: "Hold the brush at about 45° to the gumline and use gentle circles rather than hard scrubbing.",
		group: "Technique"
	},
	{
		title: "Replace your brush",
		body: "Change your toothbrush or brush head every three months, or sooner if bristles splay.",
		group: "Technique"
	},
	{
		title: "Mind the snacking",
		body: "How often you have sugar matters more than how much. Keep sweet foods to mealtimes.",
		group: "Diet"
	},
	{
		title: "Water is your friend",
		body: "Drinking water after meals helps wash away food and neutralise acids.",
		group: "Diet"
	},
	{
		title: "Wait after acidic drinks",
		body: "After citrus, soda or wine, wait about 30 minutes before brushing to protect softened enamel.",
		group: "Diet"
	},
	{
		title: "Regular check-ups",
		body: "Routine dental visits catch small issues early, often before you notice symptoms.",
		group: "Professional care"
	},
	{
		title: "Bleeding gums aren't normal",
		body: "If gums bleed when brushing for more than two weeks, mention it to your dentist.",
		group: "Professional care"
	}
];
//#endregion
export { TIPS as t };
