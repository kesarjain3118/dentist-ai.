import { a as require_jsx_runtime } from "../_libs/@ai-sdk/react+[...].mjs";
import { n as displayName, r as useAuth } from "./auth-DeMeG-kQ.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { M as FileText, W as CalendarCheck, _ as Plus, q as ArrowRight, u as ShieldCheck } from "../_libs/lucide-react.mjs";
import { n as useReports, t as ReportList } from "./report-list-CuQpbBwM.mjs";
import { t as TIPS } from "./tips-3V987a7z.mjs";
import { t as Button } from "./button-BkEeRci-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/home-BHAucOLW.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const { user } = useAuth();
	const { data } = useReports();
	const total = data?.length ?? 0;
	const withFindings = data?.filter((r) => r.result.findings.length).length ?? 0;
	const last = data?.[0];
	const tip = TIPS[(/* @__PURE__ */ new Date()).getDate() % TIPS.length];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-10 animate-rise",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-8 border-b border-border pb-9 md:grid-cols-[minmax(0,1fr)_auto] md:items-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm font-medium text-muted-foreground",
							children: ["Welcome back, ", displayName(user)]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-2 max-w-2xl text-2xl font-semibold tracking-tight sm:text-3xl",
							children: "Your dental health, clearly organized."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-xl text-base leading-relaxed text-muted-foreground",
							children: "Review previous results or start a new AI-assisted image analysis."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					size: "lg",
					className: "w-full rounded-full px-6 md:w-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/analyze",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " New analysis"]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid divide-y divide-border border-y border-border sm:grid-cols-3 sm:divide-x sm:divide-y-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						icon: FileText,
						value: total,
						label: "Saved analyses"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						icon: ShieldCheck,
						value: withFindings,
						label: "With areas to review"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						icon: CalendarCheck,
						value: last ? new Date(last.created_at).toLocaleDateString(void 0, {
							month: "short",
							day: "numeric"
						}) : "—",
						label: "Last analysis"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-10 lg:grid-cols-[1.6fr_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-5 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: "Recent analyses"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/reports",
						className: "text-sm font-semibold text-brand",
						children: "View all"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportList, { limit: 3 })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-5 text-lg font-semibold",
						children: "Daily care"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-l-2 border-calm pl-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold uppercase text-calm",
								children: "Today"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-semibold text-foreground",
								children: tip.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: tip.body
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "ghost",
						className: "mt-5 px-0 text-brand hover:bg-transparent",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/oral-care",
							children: ["View oral care guidance ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
						})
					})
				] })]
			})
		]
	});
}
function Metric({ icon: Icon, value, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-4 px-1 py-5 sm:px-6 sm:first:pl-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			className: "h-5 w-5 shrink-0 text-muted-foreground",
			strokeWidth: 1.7
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xl font-bold tabular-nums",
			children: value
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: label
		})] })]
	});
}
//#endregion
export { Home as component };
