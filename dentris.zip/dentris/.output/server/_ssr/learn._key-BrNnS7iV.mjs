import { J as notFound, _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as CONDITIONS } from "./conditions-2iG2DNG0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/learn._key-BrNnS7iV.js
var $$splitComponentImporter = () => import("./learn._key-CvjE4IfH.mjs");
var $$splitNotFoundComponentImporter = () => import("./learn._key-DGWG73rf.mjs");
var Route = createFileRoute("/_authenticated/learn/$key")({
	loader: ({ params }) => {
		const c = CONDITIONS[params.key];
		if (!c) throw notFound();
		return { key: c.key };
	},
	head: ({ params }) => {
		const c = CONDITIONS[params.key];
		const t = c ? `${c.title} (${c.plain}) — Dentist AI` : "Learn — Dentist AI";
		return { meta: [
			{ title: t },
			{
				name: "description",
				content: c?.summary ?? "Dental education"
			},
			{
				property: "og:title",
				content: t
			},
			{
				property: "og:description",
				content: c?.summary ?? "Dental education"
			},
			{
				property: "og:type",
				content: "article"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		] };
	},
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent"),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
