import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-DHTyM8tX.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/@ai-sdk/react+[...].mjs";
import { r as useAuth } from "./auth-DeMeG-kQ.mjs";
import { b as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as Mail, E as LoaderCircle, N as Eye, P as EyeOff, T as Lock, l as Sparkles, n as User, q as ArrowRight, u as ShieldCheck } from "../_libs/lucide-react.mjs";
import { c as LanguageSelect, l as Logo } from "./brand-DxDeCF_T.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Route } from "./auth-BmxD1dwF.mjs";
import { t as tooth_hero_default } from "./tooth-hero-CKojipPX.mjs";
import { t as createLovableAuth } from "../_libs/lovable.dev__cloud-auth-js.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-CuG9FtDq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var lovableAuth = createLovableAuth();
var lovable = { auth: { signInWithOAuth: async (provider, opts) => {
	const result = await lovableAuth.signInWithOAuth(provider, {
		...opts,
		extraParams: { ...opts?.extraParams }
	});
	if (result.redirected) return result;
	if (result.error) return result;
	try {
		await supabase.auth.setSession(result.tokens);
	} catch (e) {
		return { error: e instanceof Error ? e : new Error(String(e)) };
	}
	return result;
} } };
function safeRedirect(r) {
	if (!r) return "/ask";
	try {
		const u = new URL(r, window.location.origin);
		if (u.origin !== window.location.origin || u.pathname.startsWith("/auth")) return "/ask";
		return u.pathname + u.search;
	} catch {
		return "/ask";
	}
}
function AuthPage() {
	const { redirect, mode: initial } = Route.useSearch();
	const navigate = useNavigate();
	const { session } = useAuth();
	const [mode, setMode] = (0, import_react.useState)(initial ?? "signin");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("");
	const [show, setShow] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(null);
	const [sent, setSent] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (session) navigate({
			href: safeRedirect(redirect),
			replace: true
		});
	}, [
		session,
		redirect,
		navigate
	]);
	async function social(provider) {
		setBusy(provider);
		if ((await lovable.auth.signInWithOAuth(provider, { redirect_uri: window.location.origin + "/auth" })).error) {
			toast.error("Sign-in didn't complete. Please try again.");
			setBusy(null);
		}
	}
	async function submit(e) {
		e.preventDefault();
		setBusy("form");
		try {
			if (mode === "signin") {
				const { error } = await supabase.auth.signInWithPassword({
					email,
					password
				});
				if (error) throw error;
			} else if (mode === "signup") {
				if (password.length < 8) throw new Error("Use at least 8 characters for your password.");
				const { data, error } = await supabase.auth.signUp({
					email,
					password,
					options: {
						emailRedirectTo: window.location.origin + "/ask",
						data: { full_name: name }
					}
				});
				if (error) throw error;
				if (!data.session) setSent("Check your inbox to confirm your email, then sign in.");
			} else {
				const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: window.location.origin + "/reset-password" });
				if (error) throw error;
				setSent("If an account exists for that email, we've sent a reset link.");
			}
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Something went wrong.");
		} finally {
			setBusy(null);
		}
	}
	const title = mode === "signin" ? "Welcome back" : mode === "signup" ? "Create your account" : "Reset your password";
	const sub = mode === "signin" ? "Sign in to continue." : mode === "signup" ? "It takes less than a minute." : "We'll email you a secure link.";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid min-h-screen bg-background lg:grid-cols-[1.1fr_1fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative hidden overflow-hidden bg-wash lg:block",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: tooth_hero_default,
					alt: "",
					width: 1024,
					height: 1280,
					className: "absolute inset-0 h-full w-full object-cover opacity-90"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-r from-background/90 via-background/40 to-transparent" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex h-full flex-col justify-between p-12",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "max-w-md animate-rise",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-6xl font-bold leading-[1.02] text-foreground",
								children: "A healthier, happier smile starts here."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 text-lg text-muted-foreground",
								children: "Understand your dental health with AI."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid max-w-lg grid-cols-3 gap-6 text-sm",
							children: [
								["AI-assisted insights", "What may be visible"],
								["Simple guidance", "Clear next steps"],
								["Track over time", "All your reports"]
							].map(([t, s]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold text-foreground",
								children: t
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-muted-foreground",
								children: s
							})] }, t))
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "flex flex-col px-6 py-6 sm:px-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "lg:hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "ml-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LanguageSelect, {})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex w-full max-w-md flex-1 flex-col justify-center py-10 animate-rise",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-6 hidden text-center text-sm text-muted-foreground lg:block",
							children: "Dentist AI"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-center text-4xl font-bold text-foreground",
							children: title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-center text-muted-foreground",
							children: sub
						}),
						sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-10 rounded-2xl bg-brand-soft p-6 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "mx-auto h-6 w-6 text-brand" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 font-medium text-foreground",
									children: sent
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => {
										setSent(null);
										setMode("signin");
									},
									className: "mt-4 text-sm font-semibold text-brand",
									children: "Back to sign in"
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							mode !== "forgot" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-10 space-y-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => social("apple"),
									disabled: !!busy,
									className: "flex w-full items-center justify-center gap-3 rounded-2xl border border-border bg-card py-3.5 font-semibold text-foreground shadow-soft transition hover:bg-secondary disabled:opacity-60",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
										viewBox: "0 0 24 24",
										className: "h-5 w-5 fill-current",
										"aria-hidden": true,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M16.37 12.6c-.02-2.2 1.8-3.26 1.88-3.31-1.03-1.5-2.62-1.7-3.18-1.73-1.35-.14-2.64.8-3.33.8-.69 0-1.74-.78-2.86-.76-1.47.02-2.83.86-3.59 2.17-1.53 2.65-.39 6.58 1.1 8.73.73 1.05 1.6 2.23 2.73 2.19 1.1-.04 1.51-.71 2.84-.71 1.32 0 1.7.71 2.86.69 1.18-.02 1.93-1.07 2.65-2.13.84-1.22 1.18-2.4 1.2-2.46-.03-.01-2.28-.88-2.3-3.48ZM14.2 6.13c.6-.74 1.01-1.75.9-2.77-.87.04-1.93.58-2.55 1.31-.56.65-1.05 1.69-.92 2.68.97.08 1.97-.49 2.57-1.22Z" })
									}), busy === "apple" ? "Opening Apple…" : "Continue with Apple"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => social("google"),
									disabled: !!busy,
									className: "flex w-full items-center justify-center gap-3 rounded-2xl border border-border bg-card py-3.5 font-semibold text-foreground shadow-soft transition hover:bg-secondary disabled:opacity-60",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
										viewBox: "0 0 24 24",
										className: "h-5 w-5",
										"aria-hidden": true,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
												fill: "#4285F4",
												d: "M22.5 12.27c0-.79-.07-1.54-.19-2.27H12v4.3h5.9a5.05 5.05 0 0 1-2.19 3.31v2.75h3.54c2.07-1.9 3.25-4.71 3.25-8.09Z"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
												fill: "#34A853",
												d: "M12 23c2.97 0 5.46-.98 7.28-2.66l-3.54-2.75c-.98.66-2.24 1.05-3.74 1.05-2.87 0-5.3-1.94-6.17-4.55H2.18v2.84A11 11 0 0 0 12 23Z"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
												fill: "#FBBC05",
												d: "M5.83 14.09a6.6 6.6 0 0 1 0-4.18V7.07H2.18a11 11 0 0 0 0 9.86l3.65-2.84Z"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
												fill: "#EA4335",
												d: "M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15A10.96 10.96 0 0 0 12 1 11 11 0 0 0 2.18 7.07l3.65 2.84C6.7 7.3 9.13 5.38 12 5.38Z"
											})
										]
									}), busy === "google" ? "Opening Google…" : "Continue with Google"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "my-7 flex items-center gap-4 text-sm text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-border" }),
									" or ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-border" })
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								onSubmit: submit,
								className: `space-y-4 ${mode === "forgot" ? "mt-10" : ""}`,
								children: [
									mode === "signup" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										icon: User,
										label: "Your name",
										value: name,
										onChange: setName,
										placeholder: "Alex Morgan",
										autoComplete: "name"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										icon: Mail,
										label: "Email address",
										type: "email",
										value: email,
										onChange: setEmail,
										placeholder: "you@example.com",
										autoComplete: "email",
										required: true
									}),
									mode !== "forgot" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										icon: Lock,
										label: "Password",
										type: show ? "text" : "password",
										value: password,
										onChange: setPassword,
										placeholder: mode === "signup" ? "At least 8 characters" : "Enter your password",
										autoComplete: mode === "signup" ? "new-password" : "current-password",
										required: true,
										trailing: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setShow(!show),
											className: "text-muted-foreground",
											"aria-label": show ? "Hide password" : "Show password",
											children: show ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "h-4 w-4" })
										})
									}), mode === "signin" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-2 text-right",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setMode("forgot"),
											className: "text-sm font-semibold text-brand",
											children: "Forgot password?"
										})
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "submit",
										disabled: !!busy,
										className: "flex w-full items-center justify-center gap-2 rounded-2xl bg-primary py-4 font-semibold text-primary-foreground shadow-float transition hover:bg-primary/90 disabled:opacity-60",
										children: [
											busy === "form" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : null,
											mode === "signin" ? "Sign in" : mode === "signup" ? "Create account" : "Send reset link",
											busy !== "form" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-7 text-center text-sm text-muted-foreground",
								children: mode === "signin" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Don't have an account? ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setMode("signup"),
									className: "font-semibold text-brand",
									children: "Create one"
								})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Already have an account? ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setMode("signin"),
									className: "font-semibold text-brand",
									children: "Sign in"
								})] })
							})
						] })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-md pb-2 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold text-foreground",
							children: "Your privacy matters."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 flex items-center justify-center gap-3 text-xs text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-3.5 w-3.5" }),
								" Secure • Private • AI-assisted insights ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-3.5 w-3.5" })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "mt-3 inline-block text-xs text-muted-foreground underline-offset-4 hover:underline",
							children: "Learn about Dentist AI"
						})
					]
				})
			]
		})]
	});
}
function Field({ icon: Icon, label, value, onChange, trailing, ...rest }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-2 block text-sm font-medium text-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex items-center gap-3 rounded-2xl border border-input bg-card px-4 py-3.5 transition focus-within:border-brand focus-within:ring-4 focus-within:ring-brand/10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4 text-muted-foreground" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					...rest,
					value,
					onChange: (e) => onChange(e.target.value),
					className: "min-w-0 flex-1 bg-transparent text-foreground outline-none placeholder:text-muted-foreground/70"
				}),
				trailing
			]
		})]
	});
}
//#endregion
export { AuthPage as component };
