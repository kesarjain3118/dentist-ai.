import { a as require_jsx_runtime } from "../_libs/@ai-sdk/react+[...].mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/learn._key-DGWG73rf.js
var import_jsx_runtime = require_jsx_runtime();
var SplitNotFoundComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
	className: "py-20 text-center text-muted-foreground",
	children: ["Topic not found. ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/learn",
		className: "text-brand",
		children: "Back to Learn"
	})]
});
//#endregion
export { SplitNotFoundComponent as notFoundComponent };
