import { t as supabase } from "./client-DHTyM8tX.mjs";
import { t as queryOptions } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reports-Cvt1IHHS.js
var reportsQuery = queryOptions({
	queryKey: ["reports"],
	queryFn: async () => {
		const { data, error } = await supabase.from("analyses").select("id,image_type,image_path,status,result,created_at").order("created_at", { ascending: false });
		if (error) throw error;
		return data ?? [];
	}
});
var reportQuery = (id) => queryOptions({
	queryKey: ["report", id],
	queryFn: async () => {
		const { data, error } = await supabase.from("analyses").select("id,image_type,image_path,status,result,created_at").eq("id", id).maybeSingle();
		if (error) throw error;
		if (!data) return null;
		const report = data;
		const { data: signed } = await supabase.storage.from("dental-images").createSignedUrl(report.image_path, 3600);
		return {
			...report,
			imageUrl: signed?.signedUrl ?? null
		};
	}
});
async function signedUrls(paths) {
	if (!paths.length) return {};
	const { data } = await supabase.storage.from("dental-images").createSignedUrls(paths, 3600);
	const out = {};
	data?.forEach((d) => {
		if (d.path && d.signedUrl) out[d.path] = d.signedUrl;
	});
	return out;
}
var statusLabel = {
	complete: "Possible findings",
	no_findings: "Nothing notable",
	low_confidence: "Uncertain",
	unsupported: "Unsupported image",
	poor_quality: "Poor image quality"
};
//#endregion
export { statusLabel as i, reportsQuery as n, signedUrls as r, reportQuery as t };
