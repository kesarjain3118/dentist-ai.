import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-DHTyM8tX.mjs";
import { a as require_jsx_runtime, n as DefaultChatTransport, o as require_react, t as useChat } from "../_libs/@ai-sdk/react+[...].mjs";
import { n as analyzeImage } from "./service-D4-qO_vv.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { E as LoaderCircle, K as ArrowUp, U as Camera, c as Square, h as ScanLine, k as ImagePlus, s as Stethoscope, t as X } from "../_libs/lucide-react.mjs";
import { i as toneClasses, n as getCondition, r as pct } from "./conditions-2iG2DNG0.mjs";
import { u as LogoMark } from "./brand-DxDeCF_T.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Markdown } from "../_libs/react-markdown+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ask-chat-QWC0ZXDf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var GENERAL = [
	"Why do my gums bleed when I brush?",
	"Is a root canal painful?",
	"Explain how to read a panoramic X-ray",
	"How often should I replace my toothbrush?"
];
var REPORT = [
	"Is this serious?",
	"Can this get worse?",
	"How can I prevent this?",
	"What should I ask my dentist?"
];
function useHistory(analysisId) {
	return useQuery({
		queryKey: ["chat", analysisId ?? "general"],
		enabled: !!analysisId,
		queryFn: async () => {
			const { data, error } = await supabase.from("chat_messages").select("id,role,content").eq("analysis_id", analysisId).order("created_at");
			if (error) throw error;
			return (data ?? []).map((m) => ({
				id: m.id,
				role: m.role,
				parts: [{
					type: "text",
					text: m.content
				}]
			}));
		},
		staleTime: Infinity
	});
}
function AskChat({ analysisId, header }) {
	const history = useHistory(analysisId);
	if (analysisId && history.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "m-auto h-10 w-10 animate-pulse rounded-full bg-accent" });
	if (history.error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "m-auto text-sm text-attention",
		children: "Couldn't load your conversation. Please refresh."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatWindow, {
		analysisId,
		initial: history.data ?? [],
		header
	}, analysisId ?? "general");
}
function ChatWindow({ analysisId, initial, header }) {
	const [input, setInput] = (0, import_react.useState)("");
	const [scan, setScan] = (0, import_react.useState)();
	const [scanning, setScanning] = (0, import_react.useState)(false);
	const camera = (0, import_react.useRef)(null);
	const area = (0, import_react.useRef)(null);
	const scroller = (0, import_react.useRef)(null);
	async function scanPhoto(file) {
		setScanning(true);
		try {
			const result = await analyzeImage(file, "photo");
			setScan({
				result,
				preview: URL.createObjectURL(file)
			});
		} catch (e) {
			toast.error(e instanceof Error ? e.message : "Couldn't scan that photo. Please try another one.");
		} finally {
			setScanning(false);
			if (camera.current) camera.current.value = "";
		}
	}
	const transport = (0, import_react.useMemo)(() => new DefaultChatTransport({
		api: "/api/chat",
		body: analysisId ? { analysisId } : {},
		headers: async () => {
			const { data } = await supabase.auth.getSession();
			return data.session ? { Authorization: `Bearer ${data.session.access_token}` } : {};
		}
	}), [analysisId]);
	const { messages, sendMessage, status, stop } = useChat({
		id: analysisId ?? "general",
		messages: initial,
		transport,
		onError: (e) => toast.error(e.message?.includes("{") ? "Dentist AI couldn't answer right now. Please try again." : e.message)
	});
	const busy = status === "submitted" || status === "streaming";
	(0, import_react.useEffect)(() => {
		scroller.current?.scrollTo({
			top: scroller.current.scrollHeight,
			behavior: "smooth"
		});
	}, [messages, status]);
	(0, import_react.useEffect)(() => {
		if (!busy) area.current?.focus({ preventScroll: true });
	}, [busy]);
	function send(text) {
		const t = text.trim();
		if (!t || busy) return;
		sendMessage({ text: t });
		setInput("");
	}
	function onSubmit(e) {
		e.preventDefault();
		send(input);
	}
	const suggestions = analysisId ? REPORT : GENERAL;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: scroller,
			className: "min-h-0 flex-1 overflow-y-auto px-4 sm:px-8",
			children: messages.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex min-h-full max-w-2xl flex-col items-center justify-center py-10 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stethoscope, { className: "h-7 w-7" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-5 text-3xl font-bold tracking-tight",
						children: "How can I help today?"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-muted-foreground",
						children: analysisId ? "Ask anything about this report — answers use its results only." : "Ask me anything — or upload a tooth photo or X-ray to scan it."
					}),
					header && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4",
						children: header
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 grid w-full gap-3 sm:grid-cols-2",
						children: suggestions.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => send(s),
							className: "rounded-xl border border-border bg-card px-4 py-3 text-left text-sm transition-colors hover:border-primary/40 hover:bg-accent",
							children: s
						}, s))
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-3xl space-y-6 py-8",
				children: [
					header,
					messages.map((m) => m.role === "user" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex justify-end",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "max-w-[85%] rounded-2xl rounded-br-md bg-primary px-4 py-2.5 text-[15px] text-primary-foreground",
							children: m.parts.map((p) => p.type === "text" ? p.text : "").join("")
						})
					}, m.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, { className: "mt-0.5 h-6 w-6 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "min-w-0 flex-1 text-[15px] leading-relaxed [&_li]:ml-4 [&_li]:list-disc [&_p]:my-2 [&_strong]:font-semibold [&_ul]:my-2",
							children: m.parts.map((p, i) => p.type === "text" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Markdown, { children: p.text }, i) : null)
						})]
					}, m.id)),
					status === "submitted" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, { className: "h-6 w-6" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex gap-1",
							children: [
								0,
								1,
								2
							].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "h-1.5 w-1.5 animate-pulse rounded-full bg-primary",
								style: { animationDelay: `${i * 150}ms` }
							}, i))
						})]
					})
				]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-t border-border/60 px-4 pb-3 pt-4 sm:px-8",
			children: [
				(scan || scanning) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto mb-3 max-w-3xl",
					children: scanning ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 rounded-2xl border border-border bg-card p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-5 w-5 animate-spin text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "Scanning your photo with the dental model…"
						})]
					}) : scan ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanCard, {
						scan,
						onClose: () => setScan(void 0),
						onAsk: (q) => send(q)
					}) : null
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit,
					className: "mx-auto max-w-3xl rounded-2xl border border-input bg-card p-3 shadow-soft focus-within:border-primary",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						ref: area,
						value: input,
						onChange: (e) => setInput(e.target.value),
						onKeyDown: (e) => {
							if (e.key === "Enter" && !e.shiftKey) {
								e.preventDefault();
								send(input);
							}
						},
						rows: 2,
						placeholder: "Ask anything, or attach a dental photo / X-ray…",
						className: "w-full resize-none bg-transparent px-1 text-[15px] outline-none placeholder:text-muted-foreground",
						"aria-label": "Message Dentist AI"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex items-center gap-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								ref: camera,
								type: "file",
								accept: "image/jpeg,image/png,image/webp",
								capture: "environment",
								className: "hidden",
								onChange: (e) => {
									const f = e.target.files?.[0];
									if (f) scanPhoto(f);
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => camera.current?.click(),
								disabled: scanning,
								className: "flex items-center gap-1.5 rounded-lg px-2 py-1.5 text-sm text-muted-foreground hover:bg-secondary hover:text-foreground disabled:opacity-40",
								"aria-label": "Scan a photo now",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "h-4 w-4" }), " Scan now"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/analyze",
								className: "flex items-center gap-1.5 rounded-lg px-2 py-1.5 text-sm text-muted-foreground hover:bg-secondary hover:text-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "h-4 w-4" }), " Add image"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/analyze",
								className: "flex items-center gap-1.5 rounded-lg px-2 py-1.5 text-sm text-primary hover:bg-accent",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanLine, { className: "h-4 w-4" }), " Scan & save"]
							}),
							busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: stop,
								className: "ml-auto flex h-9 w-9 items-center justify-center rounded-xl bg-secondary",
								"aria-label": "Stop",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "h-4 w-4" })
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								disabled: !input.trim(),
								className: "ml-auto flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-primary-foreground disabled:opacity-40",
								"aria-label": "Send",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "h-4 w-4" })
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-center text-[11px] text-muted-foreground",
					children: "AI-assisted screening, not a diagnosis. Review results with a qualified dental professional."
				})
			]
		})]
	});
}
function ScanCard({ scan, onClose, onAsk }) {
	const r = scan.result;
	const top = r.findings.length ? r.findings.reduce((a, b) => b.confidence > a.confidence ? b : a) : void 0;
	const c = top ? getCondition(top.name) : void 0;
	const t = c ? toneClasses[c.tone] : void 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex gap-4 rounded-2xl border border-border bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: scan.preview,
				alt: "Scanned photo",
				className: "h-20 w-20 shrink-0 rounded-xl object-cover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [
					top && c && t ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex flex-wrap items-center gap-2 text-sm font-semibold",
						children: [
							"Possible ",
							c.title,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `rounded-full ${t.soft} ${t.text} px-2 py-0.5 text-[11px] font-semibold`,
								children: c.urgency
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "ml-auto text-xs font-medium text-muted-foreground",
								children: [pct(top.confidence), " confidence"]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 line-clamp-2 text-sm text-muted-foreground",
						children: r.explanation
					})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: r.explanation
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex flex-wrap items-center gap-2",
						children: [top && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onAsk(`I just scanned a photo and the model reported possible ${c?.title ?? top.name} at ${pct(top.confidence)} confidence. What does that mean for me?`),
							className: "rounded-full bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground",
							children: "Ask about this result"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/analyze",
							className: "rounded-full border border-border px-3 py-1.5 text-xs font-semibold hover:bg-secondary",
							children: "Save as full report"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-[11px] text-muted-foreground",
						children: "AI-assisted screening, not a diagnosis."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onClose,
				className: "self-start rounded-full p-1 text-muted-foreground hover:bg-secondary",
				"aria-label": "Dismiss scan result",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
			})
		]
	});
}
//#endregion
export { AskChat as t };
