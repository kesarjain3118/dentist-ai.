import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-DHTyM8tX.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/@ai-sdk/react+[...].mjs";
import { r as useAuth } from "./auth-DeMeG-kQ.mjs";
import { b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as AlertDialogDescription, c as AlertDialogTitle, i as AlertDialogContent, l as AlertDialogTrigger, n as AlertDialogAction, o as AlertDialogFooter, r as AlertDialogCancel, s as AlertDialogHeader, t as AlertDialog } from "./alert-dialog-CmIv1W53.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-IGYLN8BF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Settings() {
	const { user } = useAuth();
	const [name, setName] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	const qc = useQueryClient();
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		if (!user) return;
		supabase.from("profiles").select("display_name").eq("id", user.id).maybeSingle().then(({ data }) => setName(data?.display_name ?? ""));
	}, [user]);
	async function save() {
		if (!user) return;
		setSaving(true);
		const { error } = await supabase.from("profiles").upsert({
			id: user.id,
			display_name: name
		});
		await supabase.auth.updateUser({ data: { full_name: name } });
		setSaving(false);
		error ? toast.error("Couldn't save.") : toast.success("Profile updated.");
	}
	async function deleteAll() {
		if (!user) return;
		const { data: list } = await supabase.storage.from("dental-images").list(user.id, { limit: 1e3 });
		if (list?.length) await supabase.storage.from("dental-images").remove(list.map((f) => `${user.id}/${f.name}`));
		const { error } = await supabase.from("analyses").delete().eq("user_id", user.id);
		if (error) {
			toast.error("Couldn't delete your data.");
			return;
		}
		await qc.invalidateQueries();
		toast.success("All reports and images deleted.");
	}
	async function signOut() {
		await qc.cancelQueries();
		qc.clear();
		await supabase.auth.signOut();
		navigate({
			to: "/auth",
			replace: true
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-2xl space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-4xl font-bold",
				children: "Settings"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "surface p-6 sm:p-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: "Profile"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "mt-5 block text-sm font-medium",
						children: "Name"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: name,
						onChange: (e) => setName(e.target.value),
						className: "mt-2 w-full rounded-2xl border border-input bg-card px-4 py-3 outline-none focus:border-brand"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 text-sm text-muted-foreground",
						children: ["Email: ", user?.email]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: save,
						disabled: saving,
						className: "mt-5 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground disabled:opacity-60",
						children: saving ? "Saving…" : "Save changes"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "surface p-6 sm:p-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: "Privacy & data"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-4 space-y-2 text-sm text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Your images and reports are stored privately and are visible only to your account." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Ask Dentist AI uses your analysis results to answer questions; images aren't shared with the assistant." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "You can delete any report, or all your data, at any time." })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialog, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTrigger, {
						className: "mt-6 rounded-full border border-attention/40 px-5 py-2.5 text-sm font-semibold text-attention hover:bg-attention-soft",
						children: "Delete all my reports"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: "Delete all reports?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: "All your images, results and conversations will be permanently removed." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: "Cancel" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
						onClick: deleteAll,
						children: "Delete everything"
					})] })] })] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: signOut,
				className: "rounded-full px-5 py-3 text-sm font-semibold hover:bg-secondary",
				children: "Sign out"
			})
		]
	});
}
//#endregion
export { Settings as component };
