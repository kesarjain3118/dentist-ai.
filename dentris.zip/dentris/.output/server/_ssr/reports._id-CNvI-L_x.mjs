import { i as __toESM } from "../_runtime.mjs";
import { d as DialogClose, f as DialogContent$1, g as DialogTitle$1, h as DialogPortal$1, m as DialogOverlay$1, p as DialogDescription$1, u as Dialog$1 } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as supabase } from "./client-DHTyM8tX.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/@ai-sdk/react+[...].mjs";
import { n as displayName, r as useAuth } from "./auth-DeMeG-kQ.mjs";
import { b as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useQueryClient, n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { A as HeartPulse, B as ChevronRight, F as Clock, J as ArrowLeft, L as CircleQuestionMark, R as CircleCheck, S as MapPin, V as ChevronLeft, Y as Activity, _ as Plus, d as Share2, g as Printer, i as TrendingUp, k as ImagePlus, l as Sparkles, m as SearchX, o as Trash2, r as TriangleAlert, s as Stethoscope, t as X, v as Minus, x as Maximize2, z as CircleAlert } from "../_libs/lucide-react.mjs";
import { i as toneClasses, n as getCondition, r as pct } from "./conditions-2iG2DNG0.mjs";
import { n as reportsQuery, r as signedUrls, t as reportQuery } from "./reports-Cvt1IHHS.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { d as VeltrisCredit, t as Disclaimer, u as LogoMark } from "./brand-DxDeCF_T.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as AskChat } from "./ask-chat-QWC0ZXDf.mjs";
import { t as Button } from "./button-BkEeRci-.mjs";
import { t as getLocation } from "./locations-CUJ9MYA2.mjs";
import { n as StageStrip, t as DentalArch } from "./dental-visuals-nx5cLIxZ.mjs";
import { t as Route } from "./reports._id-DRmyEp-7.mjs";
import { a as AlertDialogDescription, c as AlertDialogTitle, i as AlertDialogContent, l as AlertDialogTrigger, n as AlertDialogAction, o as AlertDialogFooter, r as AlertDialogCancel, s as AlertDialogHeader, t as AlertDialog } from "./alert-dialog-CmIv1W53.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reports._id-CNvI-L_x.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
var DialogHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className),
	...props
});
DialogHeader.displayName = "DialogHeader";
var DialogFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
DialogFooter.displayName = "DialogFooter";
var DialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("text-lg font-semibold leading-none tracking-tight", className),
	...props
}));
DialogTitle.displayName = DialogTitle$1.displayName;
var DialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
DialogDescription.displayName = DialogDescription$1.displayName;
function findingKey(f, index) {
	return f.id ?? `${f.name}-${f.location}-${index}`;
}
function Overlay({ findings, mode, active, onSelect }) {
	if (mode === "original") return null;
	const masked = findings.filter((f) => f.mask && f.mask.points.length >= 3);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [mode === "annotated" && masked.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		className: "pointer-events-none absolute inset-0 h-full w-full",
		viewBox: "0 0 1 1",
		preserveAspectRatio: "none",
		"aria-hidden": "true",
		children: findings.map((f, i) => {
			if (!f.mask || f.mask.points.length < 3) return null;
			const tone = toneClasses[getCondition(f.name).tone];
			const dim = active && active !== findingKey(f, i);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: f.mask.points.map(([x, y]) => `${x},${y}`).join(" "),
				className: `${tone.text} transition-opacity`,
				fill: "currentColor",
				fillOpacity: dim ? .08 : .28,
				stroke: "currentColor",
				strokeOpacity: dim ? .35 : .95,
				strokeWidth: 2,
				vectorEffect: "non-scaling-stroke",
				strokeLinejoin: "round"
			}, findingKey(f, i));
		})
	}), findings.map((f, i) => {
		if (!f.bbox) return null;
		const key = findingKey(f, i);
		const c = getCondition(f.name);
		const tone = toneClasses[c.tone];
		const dim = active && active !== findingKey(f, i);
		const hasMask = !!f.mask && f.mask.points.length >= 3;
		const style = {
			left: `${f.bbox.x * 100}%`,
			top: `${f.bbox.y * 100}%`,
			width: `${f.bbox.w * 100}%`,
			height: `${f.bbox.h * 100}%`
		};
		if (mode === "heatmap") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pointer-events-none absolute rounded-full mix-blend-multiply blur-xl",
			style: {
				...style,
				transform: "scale(1.6)",
				opacity: dim ? .25 : .4 + f.confidence * .5,
				background: "radial-gradient(circle, oklch(0.62 0.22 25) 0%, oklch(0.8 0.17 80 / 0.7) 45%, transparent 72%)"
			}
		}, key);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: () => onSelect?.(key),
			className: `absolute rounded-xl ${hasMask ? "border border-dashed border-transparent hover:border-current" : "border-[2.5px]"} ${tone.ring} transition-opacity ${dim ? "opacity-35" : "opacity-100"}`,
			style,
			"aria-label": `${c.title}, ${pct(f.confidence)} AI confidence`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: `absolute -top-1 left-0 -translate-y-full whitespace-nowrap rounded-lg ${tone.bar} px-2 py-1 text-[11px] font-semibold leading-tight text-primary-foreground shadow-soft`,
				children: [
					c.plain.split(" ")[0],
					" ",
					pct(f.confidence)
				]
			})
		}, key);
	})] });
}
function ImageViewer({ src, findings, active, onSelect }) {
	const [mode, setMode] = (0, import_react.useState)(findings.length ? "annotated" : "original");
	const [full, setFull] = (0, import_react.useState)(false);
	const [zoom, setZoom] = (0, import_react.useState)(1);
	const hasBoxes = findings.some((f) => f.bbox);
	const frame = (big) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `relative overflow-hidden rounded-3xl bg-foreground/95 ${big ? "h-full" : ""}`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto w-fit origin-center transition-transform duration-300",
			style: { transform: `scale(${zoom})` },
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src,
				alt: "Your uploaded dental image",
				className: `block ${big ? "max-h-[78vh]" : "max-h-[460px]"} w-auto max-w-full object-contain`
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlay, {
					findings,
					mode,
					active,
					onSelect
				})
			})]
		})
	});
	const controls = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "inline-flex rounded-full bg-secondary p-1 text-sm",
			children: [
				"original",
				"annotated",
				"heatmap"
			].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				disabled: m !== "original" && !hasBoxes,
				onClick: () => setMode(m),
				className: `rounded-full px-4 py-1.5 capitalize transition disabled:opacity-40 ${mode === m ? "bg-card font-semibold text-foreground shadow-soft" : "text-muted-foreground"}`,
				children: m === "annotated" ? "AI analysis" : m
			}, m))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setZoom((z) => Math.max(1, z - .25)),
					className: "rounded-full p-2 hover:bg-secondary",
					"aria-label": "Zoom out",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "h-4 w-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "w-12 text-center text-xs text-muted-foreground",
					children: [Math.round(zoom * 100), "%"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setZoom((z) => Math.min(3, z + .25)),
					className: "rounded-full p-2 hover:bg-secondary",
					"aria-label": "Zoom in",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setFull(true),
					className: "rounded-full p-2 hover:bg-secondary",
					"aria-label": "Fullscreen",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "h-4 w-4" })
				})
			]
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			frame(false),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "print:hidden",
				children: controls
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: full,
				onOpenChange: setFull,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-6xl border-none bg-card p-4 sm:p-6 [&>button]:hidden",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
							className: "sr-only",
							children: "Fullscreen image"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex justify-end",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setFull(false),
								className: "rounded-full p-2 hover:bg-secondary",
								"aria-label": "Close",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
							})
						}),
						frame(true),
						controls
					]
				})
			})
		]
	});
}
function FindingRow({ finding, active, onClick }) {
	const c = getCondition(finding.name);
	const t = toneClasses[c.tone];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		onClick,
		className: `group flex w-full items-center gap-4 rounded-2xl border p-4 text-left transition ${active ? "border-brand/40 bg-brand-soft/60" : "border-transparent bg-secondary/60 hover:bg-secondary"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-10 w-1.5 shrink-0 rounded-full ${t.bar}` }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex flex-wrap items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-semibold text-foreground",
						children: ["Possible ", c.title]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `rounded-full ${t.soft} ${t.text} px-2 py-0.5 text-[11px] font-semibold`,
						children: c.urgency
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "mt-0.5 block text-sm text-muted-foreground",
					children: [
						c.plain,
						" · ",
						getLocation(finding.location).label
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-right",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-lg font-bold tabular-nums text-foreground",
					children: pct(finding.confidence)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-[10px] uppercase tracking-wide text-muted-foreground",
					children: "AI confidence"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4 text-muted-foreground transition group-hover:translate-x-0.5" })
		]
	});
}
var List = ({ items }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
	className: "space-y-2",
	children: items.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex gap-2.5 text-[15px] leading-relaxed text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-brand/50" }), i]
	}, i))
});
var TABS = [
	{
		key: "overview",
		label: "Overview"
	},
	{
		key: "symptoms",
		label: "Symptoms"
	},
	{
		key: "causes",
		label: "Causes"
	},
	{
		key: "treatment",
		label: "Treatment Options"
	},
	{
		key: "prevention",
		label: "Prevention"
	},
	{
		key: "faqs",
		label: "FAQs"
	}
];
function ConditionDetail({ finding, index }) {
	const c = getCondition(finding.name);
	const t = toneClasses[c.tone];
	const loc = getLocation(finding.location);
	const [tab, setTab] = (0, import_react.useState)("overview");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "grid gap-5 animate-rise lg:grid-cols-[1fr_320px]",
		"aria-labelledby": `cd-${c.key}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "surface p-6 sm:p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							id: `cd-${c.key}`,
							className: "text-xl font-bold sm:text-2xl",
							children: [
								index !== void 0 && `${index + 1}. `,
								"Possible ",
								c.title
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `rounded-full ${t.soft} ${t.text} px-3 py-1 text-xs font-semibold`,
							children: c.urgency
						}),
						finding.location === "whole_image" && finding.confidence < .8 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full border border-border bg-muted px-3 py-1 text-xs font-semibold text-muted-foreground",
							children: "Moderate confidence"
						}),
						finding.confidence < .4 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full border border-border bg-muted px-3 py-1 text-xs font-semibold text-muted-foreground",
							children: "Subtle · low confidence"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "ml-auto flex items-baseline gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-medium text-muted-foreground",
								children: "AI confidence"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-2xl font-bold tabular-nums",
								children: pct(finding.confidence)
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 -mx-6 overflow-x-auto px-6 pb-1 sm:-mx-8 sm:px-8 print:hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex w-max flex-nowrap gap-1 rounded-full bg-secondary p-1",
						children: TABS.map(({ key, label }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setTab(key),
							className: `whitespace-nowrap rounded-full px-3.5 py-1.5 text-[13px] transition sm:px-4 sm:text-sm ${tab === key ? "bg-card font-semibold text-foreground shadow-soft" : "text-muted-foreground hover:text-foreground"}`,
							children: label
						}, key))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6",
					children: [
						tab === "overview" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid items-start gap-6 md:grid-cols-[1fr_1.2fr]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "text-lg font-semibold",
									children: [
										"What is ",
										c.title.toLowerCase(),
										"?"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 leading-relaxed text-muted-foreground",
									children: c.whatIsIt
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/learn/$key",
									params: { key: c.key },
									className: "mt-4 inline-flex rounded-full border border-border px-4 py-2 text-sm font-semibold hover:bg-secondary print:hidden",
									children: "Learn more →"
								})
							] }), c.stages && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StageStrip, { stages: c.stages })]
						}),
						tab === "symptoms" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "flex items-center gap-2 text-lg font-semibold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "h-4 w-4 text-brand" }), " Common symptoms"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, { items: c.symptoms })
						})] }),
						tab === "causes" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "flex items-center gap-2 text-lg font-semibold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeartPulse, { className: "h-4 w-4 text-brand" }), " Why can this happen?"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, { items: c.causes })
						})] }),
						tab === "treatment" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "flex items-center gap-2 text-lg font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stethoscope, { className: "h-4 w-4 text-brand" }), " What can a dentist do?"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, { items: c.dentistCan })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-xs text-muted-foreground",
								children: "Your dentist will decide the right approach after an examination."
							})
						] }),
						tab === "prevention" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "flex items-center gap-2 text-lg font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-4 w-4 text-brand" }), " What can I do now?"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, { items: c.doNow })
							})] }), c.ifIgnored && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "flex items-center gap-2 text-lg font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "h-4 w-4 text-brand" }), " What happens if it is ignored?"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-[15px] leading-relaxed text-muted-foreground",
								children: c.ifIgnored
							})] })]
						}),
						tab === "faqs" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "flex items-center gap-2 text-lg font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-4 w-4 text-brand" }), " When should I see a dentist?"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-[15px] leading-relaxed text-muted-foreground",
								children: c.whenToSee
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "flex items-center gap-2 text-lg font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleQuestionMark, { className: "h-4 w-4 text-brand" }), " Questions to ask your dentist"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, { items: c.questions })
							})] })]
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "surface flex flex-col p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
					className: "flex items-center gap-2 font-semibold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-4 w-4 text-brand" }), " Where it is on your tooth"]
				}),
				loc.teeth !== "—" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-1 items-center justify-center py-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DentalArch, { locations: [finding.location] })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold text-foreground",
						children: loc.label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: [
							"Tooth ",
							loc.teeth.includes("–") ? "numbers" : "number",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold text-foreground",
								children: loc.teeth
							}),
							" (FDI)"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: "Estimated location based on the image. Your dentist will confirm the exact tooth."
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 rounded-2xl bg-secondary/60 p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold text-foreground",
						children: "Whole photo"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: "The photo model looks at the whole image, so it can't point to a specific tooth. Your dentist will confirm where it is."
					})]
				}),
				c.cdt && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 rounded-2xl bg-secondary/60 p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold uppercase tracking-wide text-muted-foreground",
							children: "If treatment is needed"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1.5 text-sm font-semibold text-foreground",
							children: [
								c.cdt.code,
								" · ",
								c.cdt.label
							]
						}),
						c.billingNote && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs leading-relaxed text-muted-foreground",
							children: c.billingNote
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-[11px] text-muted-foreground",
							children: "Indicative procedure code for discussion with your clinic — not a quote or a claim."
						})
					]
				})
			]
		})]
	});
}
function ClinicalReferralSlip({ report, patientName }) {
	const date = new Date(report.created_at);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "clinical-slip",
		"aria-label": "Dental consultation brief",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-start justify-between border-b border-border pb-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, { className: "h-10 w-10" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-lg font-bold",
						children: "Dentist AI"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Dental consultation brief"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right text-xs text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Reference ", report.id.slice(0, 8).toUpperCase()] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: date.toLocaleDateString(void 0, { dateStyle: "long" }) })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid grid-cols-2 gap-8 border-b border-border py-6 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase text-muted-foreground",
					children: "Patient"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 font-semibold",
					children: patientName
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase text-muted-foreground",
					children: "Image reviewed"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 font-semibold",
					children: report.result.imageType === "xray" ? "Dental X-ray" : "Dental photograph"
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "py-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-bold",
						children: "Areas to discuss with a dentist"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-2xl text-sm leading-relaxed text-muted-foreground",
						children: report.result.explanation
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5 space-y-3",
						children: report.result.findings.length ? report.result.findings.map((finding) => {
							const condition = getCondition(finding.name);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-[1fr_auto] gap-6 border-b border-border py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-semibold",
									children: ["Possible ", condition.title]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-muted-foreground",
									children: [
										getLocation(finding.location).label,
										" · ",
										condition.urgency
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-right",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-semibold tabular-nums",
										children: pct(finding.confidence)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: "AI confidence"
									})]
								})]
							}, `${finding.name}-${finding.location}`);
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "rounded-lg bg-secondary p-4 text-sm",
							children: "No notable areas were identified in this image."
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "border-t border-border py-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-bold",
					children: "Suggested next steps"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-3 grid gap-2 text-sm",
					children: report.result.recommendations.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-semibold",
							children: [index + 1, "."]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item })]
					}, item))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "mt-8 border-t border-border pt-5 text-xs leading-relaxed text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold text-foreground",
						children: "AI-assisted information — not a diagnosis."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "This brief supports a conversation with a qualified dental professional. Findings and confidence values require clinical confirmation." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex items-end justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VeltrisCredit, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Generated by Dentist AI" })]
					})
				]
			})
		]
	});
}
function PrintReferralButton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		variant: "outline",
		onClick: () => window.print(),
		className: "rounded-full",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, {}), " Clinical brief"]
	});
}
/** Confidence is uncertainty, not evidence of poor lighting or image quality. */
function reportWarning(result) {
	const uncertainStatus = [
		"low_confidence",
		"poor_quality",
		"unsupported"
	].includes(result.status);
	const confidence = Math.max(0, ...result.findings.map((finding) => finding.confidence));
	if (!uncertainStatus && (!result.findings.length || confidence >= .65)) return null;
	const xray = result.imageType === "xray";
	return {
		title: result.status === "unsupported" ? "This image isn't supported" : result.status === "poor_quality" ? "Image quality was too low" : "The AI result is uncertain",
		body: result.status === "unsupported" ? "Choose the matching scan type: mouth photo or dental X-ray." : result.status === "poor_quality" ? xray ? "Try the original, uncropped X-ray file from your clinic." : "Try a sharper, close-up photo with the area in focus." : "The model did not reach a reliable confidence level. This does not confirm a condition, rule out a problem, or mean the lighting is bad. A dentist can review the image and examine you.",
		guidance: xray ? "xray" : "photo"
	};
}
var STATE_COPY = {
	no_findings: {
		title: "No clear concerns detected",
		body: "The model didn't find anything notable in this image. That's encouraging, but an image can't show everything — keep up regular check-ups."
	},
	low_confidence: {
		title: "The AI result is uncertain",
		body: "The model couldn't identify a finding with enough confidence. This does not rule out a problem or mean the lighting is bad."
	},
	unsupported: {
		title: "This image isn't supported",
		body: "Please upload a dental photo or a supported dental X-ray."
	},
	poor_quality: {
		title: "Image quality was too low",
		body: "Try a sharper, well-lit image taken straight on."
	}
};
function ReportPage() {
	const { id } = Route.useParams();
	const { data: report, isLoading, error } = useQuery(reportQuery(id));
	const { data: allReports } = useQuery(reportsQuery);
	const [active, setActive] = (0, import_react.useState)();
	const [thumbs, setThumbs] = (0, import_react.useState)({});
	const navigate = useNavigate();
	const qc = useQueryClient();
	const { user } = useAuth();
	const siblings = allReports ?? [];
	const index = siblings.findIndex((s) => s.id === id);
	const prev = index > 0 ? siblings[index - 1] : void 0;
	const next = index >= 0 && index < siblings.length - 1 ? siblings[index + 1] : void 0;
	(0, import_react.useEffect)(() => {
		const paths = siblings.slice(0, 8).map((s) => s.image_path);
		if (!paths.length) return;
		let on = true;
		signedUrls(paths).then((m) => {
			if (on) setThumbs(m);
		});
		return () => {
			on = false;
		};
	}, [allReports]);
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 lg:grid-cols-[1.4fr_1fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-[460px] animate-pulse rounded-3xl bg-secondary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-[460px] animate-pulse rounded-3xl bg-secondary" })]
	});
	if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
		icon: CircleAlert,
		title: "We couldn't load this report",
		body: "Check your connection and try again."
	});
	if (!report) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
		icon: SearchX,
		title: "Report not found",
		body: "It may have been deleted."
	});
	const r = report.result;
	const findings = r.model.id === "dentist-ai-siglip" ? r.findings.map(({ bbox: _b, ...f }) => ({
		...f,
		location: "whole_image"
	})) : r.findings;
	const selected = findings.find((f, i) => findingKey(f, i) === active) ?? findings[0];
	const date = new Date(report.created_at);
	const warning = reportWarning(r);
	async function share() {
		const url = window.location.href;
		const text = "My Dentist AI report (private — requires my sign-in).";
		try {
			if (navigator.share) await navigator.share({
				title: "Dentist AI report",
				text,
				url
			});
			else {
				await navigator.clipboard.writeText(url);
				toast.success("Private link copied. Only you can open it while signed in.");
			}
		} catch {}
	}
	async function remove() {
		if (!report) return;
		await supabase.storage.from("dental-images").remove([report.image_path]);
		const { error } = await supabase.from("analyses").delete().eq("id", report.id);
		if (error) {
			toast.error("Couldn't delete this report.");
			return;
		}
		await qc.invalidateQueries({ queryKey: ["reports"] });
		toast.success("Report deleted.");
		navigate({ to: "/reports" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "screen-report space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hidden items-center gap-3 print:flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xl font-bold",
					children: "Dentist AI — Analysis report"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center justify-between gap-4 print:hidden",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/reports",
							className: "flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), " Back to results"]
						}), siblings.length > 1 && index >= 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1 text-sm text-muted-foreground",
							children: [
								"Image ",
								index + 1,
								" of ",
								siblings.length,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									disabled: !prev,
									onClick: () => prev && navigate({
										to: "/reports/$id",
										params: { id: prev.id }
									}),
									className: "rounded-full p-1.5 hover:bg-secondary disabled:opacity-30",
									"aria-label": "Previous image",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-4 w-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									disabled: !next,
									onClick: () => next && navigate({
										to: "/reports/$id",
										params: { id: next.id }
									}),
									className: "rounded-full p-1.5 hover:bg-secondary disabled:opacity-30",
									"aria-label": "Next image",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4" })
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-bold sm:text-4xl",
						children: "Analysis results"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-muted-foreground",
						children: [
							r.imageType === "xray" ? "Dental X-ray" : "Dental photo",
							" · ",
							date.toLocaleDateString(void 0, { dateStyle: "long" }),
							", ",
							date.toLocaleTimeString(void 0, { timeStyle: "short" })
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2 print:hidden",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1.5 rounded-full bg-calm-soft px-3 py-2 text-sm font-medium text-calm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4" }), " Saved to My Reports"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							onClick: share,
							className: "rounded-full",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, {}), " Share"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintReferralButton, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialog, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTrigger, {
							className: "rounded-full p-2.5 text-muted-foreground hover:bg-secondary",
							"aria-label": "Delete report",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: "Delete this report?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: "The image, results and conversation will be permanently removed." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: "Cancel" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
							onClick: remove,
							children: "Delete"
						})] })] })] })
					]
				})]
			}),
			warning && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-2xl border border-attention/30 bg-attention-soft p-5 print:hidden",
				role: "alert",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "mt-0.5 h-5 w-5 shrink-0 text-attention" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold text-attention",
								children: warning.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-foreground/80",
								children: warning.body
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 grid gap-4 sm:grid-cols-[1.4fr_1fr]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2 text-sm text-foreground/80",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-semibold uppercase tracking-wide text-attention",
										children: warning.guidance === "xray" ? "For this X-ray" : "If you try another photo"
									}), warning.guidance === "xray" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
										className: "list-disc space-y-1.5 pl-4",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Use the original panoramic X-ray file, not a phone photo of a screen." }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Keep the full image uncropped and choose Dental X-ray when uploading." }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Ask your dentist to review it. Don't get another X-ray just for this app." })
										]
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
										className: "list-disc space-y-1.5 pl-4",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Fill the frame with the area of concern and keep it in focus." }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Hold steady and use even light without glare." }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "If it's already clear, a dentist's review is more useful than repeated scans." })
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col gap-2 self-start",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/analyze",
											className: "rounded-full border border-attention/40 px-4 py-2 text-center text-sm font-semibold text-attention transition hover:bg-attention/10",
											children: warning.guidance === "xray" ? "Upload X-ray" : "Try another photo"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
											href: "https://www.google.com/maps/search/dentist+near+me",
											target: "_blank",
											rel: "noreferrer",
											className: "rounded-full border border-border bg-card px-4 py-2 text-center text-sm font-semibold text-foreground transition hover:bg-secondary",
											children: "Find a dentist near you"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] text-muted-foreground",
											children: "A dentist can examine properly — we don't rank or endorse any clinic."
										})
									]
								})]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-6 lg:grid-cols-[1.35fr_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface p-4 sm:p-5",
					children: [report.imageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageViewer, {
						src: report.imageUrl,
						findings,
						active,
						onSelect: setActive
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-80 items-center justify-center text-muted-foreground",
						children: "Image unavailable"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex gap-3 overflow-x-auto pb-1 print:hidden",
						children: [siblings.slice(0, 8).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => s.id !== id && navigate({
								to: "/reports/$id",
								params: { id: s.id }
							}),
							className: `h-20 w-24 shrink-0 overflow-hidden rounded-xl border-2 transition ${s.id === id ? "border-brand" : "border-transparent opacity-70 hover:opacity-100"}`,
							"aria-label": `Open analysis from ${new Date(s.created_at).toLocaleDateString()}`,
							children: thumbs[s.image_path] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: thumbs[s.image_path],
								alt: "",
								className: "h-full w-full object-cover"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex h-full w-full items-center justify-center bg-secondary text-xs text-muted-foreground",
								children: "…"
							})
						}, s.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/analyze",
							className: "flex h-20 w-24 shrink-0 flex-col items-center justify-center gap-1 rounded-xl border-2 border-dashed border-border text-xs text-muted-foreground hover:border-brand/40 hover:text-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "h-5 w-5" }), " Add more images"]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface flex flex-col gap-4 p-5 sm:p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-xl font-bold",
								children: "AI Findings"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5 text-xs text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3.5 w-3.5" }),
									" ",
									(r.durationMs / 1e3).toFixed(1),
									"s"
								]
							})]
						}),
						findings.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-2.5",
							children: findings.map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FindingRow, {
								finding: f,
								active: selected === f,
								onClick: () => setActive(findingKey(f, i))
							}, findingKey(f, i)))
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl bg-secondary/70 p-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold",
								children: STATE_COPY[r.status]?.title ?? "No findings"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: STATE_COPY[r.status]?.body
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-relaxed text-muted-foreground",
							children: r.explanation
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-auto space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Disclaimer, { compact: true }), r.model.isMock && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "Sample result: the dental model isn't connected yet, so these values are illustrative and are not real model metrics."
							})]
						})
					]
				})]
			}),
			selected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConditionDetail, {
				finding: selected,
				index: findings.indexOf(selected)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "surface p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-bold",
					children: "Recommended next steps"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 grid gap-3 sm:grid-cols-3",
					children: r.recommendations.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "rounded-2xl bg-secondary/60 p-4 text-[15px] text-foreground",
						children: t
					}, t))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center print:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VeltrisCredit, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "surface p-6 sm:p-8 print:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-bold",
					children: "Ask Dentist AI"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AskChat, { analysisId: report.id })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "hidden text-xs text-muted-foreground print:block",
				children: "This is an AI-assisted analysis, not a diagnosis. A qualified dental professional should confirm any condition. AI confidence is not the same as medical certainty."
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClinicalReferralSlip, {
		report,
		patientName: displayName(user)
	})] });
}
function Empty({ icon: Icon, title, body }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-20 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "mx-auto h-10 w-10 text-muted-foreground" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-4 text-2xl font-bold",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted-foreground",
				children: body
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/reports",
				className: "mt-6 inline-flex rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground",
				children: "Back to My Reports"
			})
		]
	});
}
//#endregion
export { ReportPage as component };
