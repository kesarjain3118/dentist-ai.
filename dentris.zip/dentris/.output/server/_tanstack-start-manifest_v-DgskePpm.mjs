//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DgskePpm.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/Users/kesar/Downloads/screenshot-magic-maker-684-main/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/auth",
			"/reset-password",
			"/api/chat"
		],
		preloads: [
			"/assets/index-DZa9pkkw.js",
			"/assets/rolldown-runtime-Dd_uD5pT.js",
			"/assets/useRouter-TMV_hFnc.js",
			"/assets/react-dom-BX7XAP0F.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/lazyRouteComponent-D-OGAp4j.js",
			"/assets/link-D3xeIdRs.js",
			"/assets/matchContext-DiFaLIxi.js",
			"/assets/client-CoM1Kc1P.js",
			"/assets/preload-helper-COzTzGja.js",
			"/assets/types-CcJvaFSg.js",
			"/assets/conditions-CRnnvc4m.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DZa9pkkw.js"
		} }]
	},
	"/": {
		filePath: "/Users/kesar/Downloads/screenshot-magic-maker-684-main/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DCXZHThS.js",
			"/assets/arrow-right-CSeJ7gzX.js",
			"/assets/scan-line-DgqMWV9v.js",
			"/assets/brand-C8rCF75h.js",
			"/assets/message-circle-DL1uNsQD.js",
			"/assets/tooth-hero-DY-WClJT.js"
		]
	},
	"/_authenticated": {
		filePath: "/Users/kesar/Downloads/screenshot-magic-maker-684-main/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/analyze",
			"/_authenticated/ask",
			"/_authenticated/home",
			"/_authenticated/oral-care",
			"/_authenticated/settings",
			"/_authenticated/learn/$key",
			"/_authenticated/reports/$id",
			"/_authenticated/learn/",
			"/_authenticated/reports/"
		],
		preloads: [
			"/assets/route-BEhjC1ds.js",
			"/assets/useNavigate-DGc5BUW0.js",
			"/assets/createLucideIcon-C4fzP4MM.js",
			"/assets/brand-C8rCF75h.js",
			"/assets/file-text-DIR0alWX.js",
			"/assets/message-circle-DL1uNsQD.js",
			"/assets/plus-rmMBXzwM.js",
			"/assets/x-DkGQo4LL.js",
			"/assets/utils-B6KiDbIe.js",
			"/assets/dist-C1RJhgYD.js",
			"/assets/dist-CVbbTQMp.js"
		]
	},
	"/auth": {
		filePath: "/Users/kesar/Downloads/screenshot-magic-maker-684-main/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-C5br3iG8.js",
			"/assets/useNavigate-DGc5BUW0.js",
			"/assets/createLucideIcon-C4fzP4MM.js",
			"/assets/arrow-right-CSeJ7gzX.js",
			"/assets/brand-C8rCF75h.js",
			"/assets/loader-circle-BYP2lkLT.js",
			"/assets/shield-check-CVk1FA5Z.js",
			"/assets/sparkles-BsPpXgvR.js",
			"/assets/tooth-hero-DY-WClJT.js"
		]
	},
	"/reset-password": {
		filePath: "/Users/kesar/Downloads/screenshot-magic-maker-684-main/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-BAlG13Ts.js",
			"/assets/useNavigate-DGc5BUW0.js",
			"/assets/brand-C8rCF75h.js"
		]
	},
	"/_authenticated/analyze": {
		filePath: "/Users/kesar/Downloads/screenshot-magic-maker-684-main/src/routes/_authenticated/analyze.tsx",
		children: void 0,
		preloads: [
			"/assets/analyze-Cl9Da25C.js",
			"/assets/arrow-left-BUwgnA4X.js",
			"/assets/scan-line-DgqMWV9v.js",
			"/assets/check-CAHnL7QE.js",
			"/assets/circle-alert-CqMd0o3n.js",
			"/assets/service-F_7bF3ur.js"
		]
	},
	"/_authenticated/ask": {
		filePath: "/Users/kesar/Downloads/screenshot-magic-maker-684-main/src/routes/_authenticated/ask.tsx",
		children: void 0,
		preloads: [
			"/assets/ask-CeZwAqz_.js",
			"/assets/ask-chat-CnbSQMlv.js",
			"/assets/report-list-zVXaFDRz.js"
		]
	},
	"/_authenticated/home": {
		filePath: "/Users/kesar/Downloads/screenshot-magic-maker-684-main/src/routes/_authenticated/home.tsx",
		children: void 0,
		preloads: [
			"/assets/home-g7lfrq1D.js",
			"/assets/arrow-right-CSeJ7gzX.js",
			"/assets/shield-check-CVk1FA5Z.js",
			"/assets/report-list-zVXaFDRz.js",
			"/assets/tips-D833DFzA.js",
			"/assets/button-DORxSBEc.js"
		]
	},
	"/_authenticated/oral-care": {
		filePath: "/Users/kesar/Downloads/screenshot-magic-maker-684-main/src/routes/_authenticated/oral-care.tsx",
		children: void 0,
		preloads: [
			"/assets/oral-care-BWZLUXAa.js",
			"/assets/arrow-right-CSeJ7gzX.js",
			"/assets/tips-D833DFzA.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/Users/kesar/Downloads/screenshot-magic-maker-684-main/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: ["/assets/settings-hQvFFSUo.js", "/assets/alert-dialog-BIjjYusV.js"]
	},
	"/_authenticated/learn/$key": {
		filePath: "/Users/kesar/Downloads/screenshot-magic-maker-684-main/src/routes/_authenticated/learn.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/learn._key-HhftlSMG.js",
			"/assets/arrow-left-BUwgnA4X.js",
			"/assets/dental-visuals-ByMJNawT.js",
			"/assets/learn._key-JMCbA88S.js"
		]
	},
	"/_authenticated/reports/$id": {
		filePath: "/Users/kesar/Downloads/screenshot-magic-maker-684-main/src/routes/_authenticated/reports.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/reports._id-wJoFvahQ.js",
			"/assets/reports-DMd_A0dF.js",
			"/assets/arrow-left-BUwgnA4X.js",
			"/assets/ask-chat-CnbSQMlv.js",
			"/assets/chevron-right-Dkn2sAMq.js",
			"/assets/circle-alert-CqMd0o3n.js",
			"/assets/trending-up-Cc3NvZMo.js",
			"/assets/sparkles-BsPpXgvR.js",
			"/assets/button-DORxSBEc.js",
			"/assets/dental-visuals-ByMJNawT.js",
			"/assets/alert-dialog-BIjjYusV.js"
		]
	},
	"/_authenticated/learn/": {
		filePath: "/Users/kesar/Downloads/screenshot-magic-maker-684-main/src/routes/_authenticated/learn.index.tsx",
		children: void 0,
		preloads: ["/assets/learn.index-Bpj8VPVq.js"]
	},
	"/_authenticated/reports/": {
		filePath: "/Users/kesar/Downloads/screenshot-magic-maker-684-main/src/routes/_authenticated/reports.index.tsx",
		children: void 0,
		preloads: [
			"/assets/reports.index-Dymnl6Aq.js",
			"/assets/reports-DMd_A0dF.js",
			"/assets/trending-up-Cc3NvZMo.js",
			"/assets/report-list-zVXaFDRz.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
