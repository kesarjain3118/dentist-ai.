globalThis.__nitro_main__ = import.meta.url;
import { n as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx+unenv.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.png": {
		"type": "image/png",
		"etag": "\"be6-5XJdasyChVp2Oz6xcozSXJX1OLw\"",
		"mtime": "2026-10-14T05:24:58.917Z",
		"size": 3046,
		"path": "../public/favicon.png"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-10-14T05:24:58.917Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/assets/lazyRouteComponent-D-OGAp4j.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1184-xDVQeYO/AubINugp54o7Sxyck1w\"",
		"mtime": "2026-10-14T05:24:53.900Z",
		"size": 4484,
		"path": "../public/assets/lazyRouteComponent-D-OGAp4j.js"
	},
	"/assets/useRouter-TMV_hFnc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f38-ryd9X7Hd4poGdc9wxJ8ocIMDFHQ\"",
		"mtime": "2026-10-14T05:24:53.909Z",
		"size": 7992,
		"path": "../public/assets/useRouter-TMV_hFnc.js"
	},
	"/assets/useNavigate-DGc5BUW0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e9-OkdNuPk0mVE8VB1SlNFD0dpd/ck\"",
		"mtime": "2026-10-14T05:24:53.909Z",
		"size": 233,
		"path": "../public/assets/useNavigate-DGc5BUW0.js"
	},
	"/assets/shield-check-CVk1FA5Z.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"140-z5aCxrYBrIRhBp1W86Fi6mMPqWQ\"",
		"mtime": "2026-10-14T05:24:53.907Z",
		"size": 320,
		"path": "../public/assets/shield-check-CVk1FA5Z.js"
	},
	"/assets/not-found-i5RsCZif.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"76-Trmr7GZIBZuvfg4uM18tBiRtOXg\"",
		"mtime": "2026-10-14T05:24:53.903Z",
		"size": 118,
		"path": "../public/assets/not-found-i5RsCZif.js"
	},
	"/assets/settings-hQvFFSUo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d0f-xtfg/MPxsKnzNc5iVhHXYOmS10I\"",
		"mtime": "2026-10-14T05:24:53.906Z",
		"size": 3343,
		"path": "../public/assets/settings-hQvFFSUo.js"
	},
	"/assets/trending-up-Cc3NvZMo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ef-znPCKJ//N8iZ/f8klEjGgAF+XZ8\"",
		"mtime": "2026-10-14T05:24:53.908Z",
		"size": 239,
		"path": "../public/assets/trending-up-Cc3NvZMo.js"
	},
	"/assets/scan-line-DgqMWV9v.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"266-KxSkgwmZl62FFtOz5IVksfRCPLo\"",
		"mtime": "2026-10-14T05:24:53.906Z",
		"size": 614,
		"path": "../public/assets/scan-line-DgqMWV9v.js"
	},
	"/assets/route-BEhjC1ds.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1fcd-KeQA9HEOUsffVBUv75AhY4GqnVM\"",
		"mtime": "2026-10-14T05:24:53.905Z",
		"size": 8141,
		"path": "../public/assets/route-BEhjC1ds.js"
	},
	"/assets/routes-DCXZHThS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"da1-3+pj5V4ak+RJlR4R0jqmuPjwCsk\"",
		"mtime": "2026-10-14T05:24:53.906Z",
		"size": 3489,
		"path": "../public/assets/routes-DCXZHThS.js"
	},
	"/assets/reports-DMd_A0dF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"265c-ZSMChs6rwsyyoSYbZzMN2A2Alf4\"",
		"mtime": "2026-10-14T05:24:53.904Z",
		"size": 9820,
		"path": "../public/assets/reports-DMd_A0dF.js"
	},
	"/assets/tslib.es6-Tae09705.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"42d-qJHuGuq51+EbLaebsBAkbj1JLbk\"",
		"mtime": "2026-10-14T05:24:53.908Z",
		"size": 1069,
		"path": "../public/assets/tslib.es6-Tae09705.js"
	},
	"/assets/dist-C1RJhgYD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"281-K2XQEy4dSuaU+NZeVCiNF1cCMKU\"",
		"mtime": "2026-10-14T05:24:53.898Z",
		"size": 641,
		"path": "../public/assets/dist-C1RJhgYD.js"
	},
	"/assets/reset-password-BAlG13Ts.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5dc-DZva11KpTa7gasnWuKEfVBcImnw\"",
		"mtime": "2026-10-14T05:24:53.905Z",
		"size": 1500,
		"path": "../public/assets/reset-password-BAlG13Ts.js"
	},
	"/assets/auth-C5br3iG8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3793-YZ97CZfEf+yS7eWF5/9jyQvkVm0\"",
		"mtime": "2026-10-14T05:24:53.894Z",
		"size": 14227,
		"path": "../public/assets/auth-C5br3iG8.js"
	},
	"/assets/utils-B6KiDbIe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6a7d-iNkBSvaSyIjvZOzWoTvEa49qwcI\"",
		"mtime": "2026-10-14T05:24:53.909Z",
		"size": 27261,
		"path": "../public/assets/utils-B6KiDbIe.js"
	},
	"/assets/tooth-hero-R2iYMrzu.jpg": {
		"type": "image/jpeg",
		"etag": "\"1090a-3QyXjARfXW8kmIWsh+cHwyGAo+4\"",
		"mtime": "2026-10-14T05:24:53.950Z",
		"size": 67850,
		"path": "../public/assets/tooth-hero-R2iYMrzu.jpg"
	},
	"/assets/learn._key-JMCbA88S.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12d-JPVIwsSacQPU/b6sbIruNBRP7aU\"",
		"mtime": "2026-10-14T05:24:53.901Z",
		"size": 301,
		"path": "../public/assets/learn._key-JMCbA88S.js"
	},
	"/assets/x-DkGQo4LL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9a-tVvapLMX6mEyDPJR++BjzK5nKKI\"",
		"mtime": "2026-10-14T05:24:53.909Z",
		"size": 154,
		"path": "../public/assets/x-DkGQo4LL.js"
	},
	"/assets/check-CAHnL7QE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7c-JhotmX6WDwHPZIsUh6irl5iPKCU\"",
		"mtime": "2026-10-14T05:24:53.895Z",
		"size": 124,
		"path": "../public/assets/check-CAHnL7QE.js"
	},
	"/assets/button-DORxSBEc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"588-YfWHrctKHWJiEPLPPQBeNWxF+sw\"",
		"mtime": "2026-10-14T05:24:53.895Z",
		"size": 1416,
		"path": "../public/assets/button-DORxSBEc.js"
	},
	"/assets/arrow-right-CSeJ7gzX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-ClZ1Pu94+5ZMqYYc7V7PhaJ1XFs\"",
		"mtime": "2026-10-14T05:24:53.893Z",
		"size": 165,
		"path": "../public/assets/arrow-right-CSeJ7gzX.js"
	},
	"/assets/learn._key-HhftlSMG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"79f-kFtdn4H6L8bPJx+dCv7eQDto3ME\"",
		"mtime": "2026-10-14T05:24:53.900Z",
		"size": 1951,
		"path": "../public/assets/learn._key-HhftlSMG.js"
	},
	"/assets/rolldown-runtime-Dd_uD5pT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"452-sZl5y+VnYZJIxKNwHO0DTqczPH0\"",
		"mtime": "2026-10-14T05:24:53.905Z",
		"size": 1106,
		"path": "../public/assets/rolldown-runtime-Dd_uD5pT.js"
	},
	"/assets/preload-helper-COzTzGja.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4ae-v65t121Sh0Gh5f4IYROaWvzsKwU\"",
		"mtime": "2026-10-14T05:24:53.904Z",
		"size": 1198,
		"path": "../public/assets/preload-helper-COzTzGja.js"
	},
	"/assets/analyze-Cl9Da25C.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2993-UvsMvsNQjnQNSQJM1TPktUos/B8\"",
		"mtime": "2026-10-14T05:24:53.892Z",
		"size": 10643,
		"path": "../public/assets/analyze-Cl9Da25C.js"
	},
	"/assets/types-CcJvaFSg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dbea-CznCYxN5cWkUNv9zYwit+tEzqkI\"",
		"mtime": "2026-10-14T05:24:53.908Z",
		"size": 56298,
		"path": "../public/assets/types-CcJvaFSg.js"
	},
	"/assets/brand-C8rCF75h.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"edb9-QtOJCh8dmkCASHWpCK7wEQXsTz0\"",
		"mtime": "2026-10-14T05:24:53.894Z",
		"size": 60857,
		"path": "../public/assets/brand-C8rCF75h.js"
	},
	"/assets/arrow-left-BUwgnA4X.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-lxX10xe5CsUgk/se2o390+ziux4\"",
		"mtime": "2026-10-14T05:24:53.892Z",
		"size": 165,
		"path": "../public/assets/arrow-left-BUwgnA4X.js"
	},
	"/assets/home-g7lfrq1D.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dde-0mWT1IbEG7nsStgyyGCeS6z7rcs\"",
		"mtime": "2026-10-14T05:24:53.899Z",
		"size": 3550,
		"path": "../public/assets/home-g7lfrq1D.js"
	},
	"/assets/browser-model-DTLFMjov.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ba6-VH84+ZQv4ABhWe430EyZn73vAwM\"",
		"mtime": "2026-10-14T05:24:53.895Z",
		"size": 7078,
		"path": "../public/assets/browser-model-DTLFMjov.js"
	},
	"/assets/chevron-right-Dkn2sAMq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"82-DPYi4PNjVjle6pd2jxFZpPqWUsA\"",
		"mtime": "2026-10-14T05:24:53.896Z",
		"size": 130,
		"path": "../public/assets/chevron-right-Dkn2sAMq.js"
	},
	"/assets/oral-care-BWZLUXAa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f3d-Bi8uf63wTN1RHeJRunEMDMj/AKY\"",
		"mtime": "2026-10-14T05:24:53.903Z",
		"size": 3901,
		"path": "../public/assets/oral-care-BWZLUXAa.js"
	},
	"/assets/matchContext-DiFaLIxi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cc-UeL7IlrEvLEDxuzo59cLuHCwJas\"",
		"mtime": "2026-10-14T05:24:53.903Z",
		"size": 204,
		"path": "../public/assets/matchContext-DiFaLIxi.js"
	},
	"/assets/dental-visuals-ByMJNawT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1112-pX/fXnSTEAOZ0e2FNMT+2WXmq1A\"",
		"mtime": "2026-10-14T05:24:53.898Z",
		"size": 4370,
		"path": "../public/assets/dental-visuals-ByMJNawT.js"
	},
	"/assets/tips-D833DFzA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5a9-cMOTsf/bHhROCfSUna+DjZN1mc0\"",
		"mtime": "2026-10-14T05:24:53.907Z",
		"size": 1449,
		"path": "../public/assets/tips-D833DFzA.js"
	},
	"/assets/loader-circle-BYP2lkLT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"90-NH3B/my44mFP3w6nFuoIrkupFSE\"",
		"mtime": "2026-10-14T05:24:53.902Z",
		"size": 144,
		"path": "../public/assets/loader-circle-BYP2lkLT.js"
	},
	"/assets/message-circle-DL1uNsQD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f1-bJn4wAYjpkAkzHUKmyTnIiZIXbo\"",
		"mtime": "2026-10-14T05:24:53.903Z",
		"size": 241,
		"path": "../public/assets/message-circle-DL1uNsQD.js"
	},
	"/assets/dist-C5vvDCEs.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b66-TlPa7FRHpJEus5vJf3JIN2EOIqs\"",
		"mtime": "2026-10-14T05:24:53.898Z",
		"size": 2918,
		"path": "../public/assets/dist-C5vvDCEs.js"
	},
	"/assets/plus-rmMBXzwM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"99-fklcI9cuKT8z9sXrahaZk/iP4mE\"",
		"mtime": "2026-10-14T05:24:53.904Z",
		"size": 153,
		"path": "../public/assets/plus-rmMBXzwM.js"
	},
	"/assets/sparkles-BsPpXgvR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ee-AR2qfrXkR6OJNirF5wzo6wgvd7s\"",
		"mtime": "2026-10-14T05:24:53.907Z",
		"size": 494,
		"path": "../public/assets/sparkles-BsPpXgvR.js"
	},
	"/assets/createLucideIcon-C4fzP4MM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4d5-7Z2P/5efxj27VLdw8wI8GvNWTtQ\"",
		"mtime": "2026-10-14T05:24:53.897Z",
		"size": 1237,
		"path": "../public/assets/createLucideIcon-C4fzP4MM.js"
	},
	"/assets/ask-CeZwAqz_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"537-vkNDj2Twx7etxYuNgu1xn/Q04W8\"",
		"mtime": "2026-10-14T05:24:53.893Z",
		"size": 1335,
		"path": "../public/assets/ask-CeZwAqz_.js"
	},
	"/assets/reports._id-wJoFvahQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"81b1-o8CgplNeZ0z1U2KPiYvOns90PBk\"",
		"mtime": "2026-10-14T05:24:53.905Z",
		"size": 33201,
		"path": "../public/assets/reports._id-wJoFvahQ.js"
	},
	"/assets/link-D3xeIdRs.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2c00-MJhkisVcBMx2ayiC6nBycGGE/Aw\"",
		"mtime": "2026-10-14T05:24:53.902Z",
		"size": 11264,
		"path": "../public/assets/link-D3xeIdRs.js"
	},
	"/assets/conditions-CRnnvc4m.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"582f-+FVK8klwQ8V8airLwq8qLzuTKhI\"",
		"mtime": "2026-10-14T05:24:53.897Z",
		"size": 22575,
		"path": "../public/assets/conditions-CRnnvc4m.js"
	},
	"/assets/tooth-hero-DY-WClJT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"37-iV4nElj342F9Ew78uSsSwgyVi+4\"",
		"mtime": "2026-10-14T05:24:53.907Z",
		"size": 55,
		"path": "../public/assets/tooth-hero-DY-WClJT.js"
	},
	"/assets/react-dom-BX7XAP0F.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e04-mKqpW/Oowkq+fJuWOfmZ7hrDJGw\"",
		"mtime": "2026-10-14T05:24:53.904Z",
		"size": 3588,
		"path": "../public/assets/react-dom-BX7XAP0F.js"
	},
	"/assets/xray-model-Cd5FQ-kp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2215-mmATC1H1pxehgqIpadC72b46AxY\"",
		"mtime": "2026-10-14T05:24:53.910Z",
		"size": 8725,
		"path": "../public/assets/xray-model-Cd5FQ-kp.js"
	},
	"/assets/styles-CVNT77pb.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"17edd-RX0jD77OBhRimzAuQYgahaTOJ14\"",
		"mtime": "2026-10-14T05:24:53.946Z",
		"size": 98013,
		"path": "../public/assets/styles-CVNT77pb.css"
	},
	"/assets/dist-CVbbTQMp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12cc-SRADZtAau6bolnhX7O7+sCFUwaU\"",
		"mtime": "2026-10-14T05:24:53.899Z",
		"size": 4812,
		"path": "../public/assets/dist-CVbbTQMp.js"
	},
	"/assets/ask-chat-CnbSQMlv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3f87e-9GZ0Hjuprft9hEHc3CA7kPiV/8k\"",
		"mtime": "2026-10-14T05:24:53.893Z",
		"size": 260222,
		"path": "../public/assets/ask-chat-CnbSQMlv.js"
	},
	"/assets/learn.index-Bpj8VPVq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"51b-LGIPL9LogIZGmIrx9aD3205rATQ\"",
		"mtime": "2026-10-14T05:24:53.902Z",
		"size": 1307,
		"path": "../public/assets/learn.index-Bpj8VPVq.js"
	},
	"/assets/file-text-DIR0alWX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"181-OwP0b7FCHnQT3NaHAiz38iNtBB8\"",
		"mtime": "2026-10-14T05:24:53.899Z",
		"size": 385,
		"path": "../public/assets/file-text-DIR0alWX.js"
	},
	"/assets/alert-dialog-BIjjYusV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"eb4-RFsQlg663M8+/f5ndMnJouRXyjM\"",
		"mtime": "2026-10-14T05:24:53.892Z",
		"size": 3764,
		"path": "../public/assets/alert-dialog-BIjjYusV.js"
	},
	"/assets/index-DZa9pkkw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"574fc-gmyJuM5Y4XlhwVa682jv187w0wk\"",
		"mtime": "2026-10-14T05:24:53.891Z",
		"size": 357628,
		"path": "../public/assets/index-DZa9pkkw.js"
	},
	"/assets/client-CoM1Kc1P.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"35181-hSzpvxbQ8R3et62SN5OqWTkdkII\"",
		"mtime": "2026-10-14T05:24:53.896Z",
		"size": 217473,
		"path": "../public/assets/client-CoM1Kc1P.js"
	},
	"/assets/report-list-zVXaFDRz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5b-NBpYd64aZpRM9BoJlKjf3EwBiqo\"",
		"mtime": "2026-10-14T05:24:53.904Z",
		"size": 2651,
		"path": "../public/assets/report-list-zVXaFDRz.js"
	},
	"/assets/reports.index-Dymnl6Aq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e03-KrvK7KhE3Gd1eUnfKjuEdalWL/k\"",
		"mtime": "2026-10-14T05:24:53.905Z",
		"size": 3587,
		"path": "../public/assets/reports.index-Dymnl6Aq.js"
	},
	"/assets/ort.bundle.min-CZNRFVeH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"626cc-zyw35rcOp3sRxTF4uuNbZTTsVE4\"",
		"mtime": "2026-10-14T05:24:53.903Z",
		"size": 403148,
		"path": "../public/assets/ort.bundle.min-CZNRFVeH.js"
	},
	"/assets/Combination-DzbIBoiy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7471-cdfQeTszv8oW4izVpZatT16kFDc\"",
		"mtime": "2026-10-14T05:24:53.892Z",
		"size": 29809,
		"path": "../public/assets/Combination-DzbIBoiy.js"
	},
	"/assets/service-F_7bF3ur.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"126c-4oZP3/KGRZWScb7eXzK+8OCGA9I\"",
		"mtime": "2026-10-14T05:24:53.906Z",
		"size": 4716,
		"path": "../public/assets/service-F_7bF3ur.js"
	},
	"/assets/circle-alert-CqMd0o3n.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fa-qQP9Y3+oePtuvnqJoPUH5MRQq8U\"",
		"mtime": "2026-10-14T05:24:53.896Z",
		"size": 250,
		"path": "../public/assets/circle-alert-CqMd0o3n.js"
	},
	"/assets/ort-wasm-simd-threaded.jsep-MDYUKy93.wasm": {
		"type": "application/wasm",
		"etag": "\"1b001dc-la0MbV4U3NIctL2NvsQDo7dhL7Q\"",
		"mtime": "2026-10-14T05:24:53.942Z",
		"size": 28312028,
		"path": "../public/assets/ort-wasm-simd-threaded.jsep-MDYUKy93.wasm"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_N0yxfC = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_N0yxfC
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
