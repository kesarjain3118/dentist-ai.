import { describe, expect, it } from "vitest";
import { photoTier } from "@/lib/analysis/browser-model";

describe("photo confidence tiers", () => {
  it("reports a 78% gingivitis photo as a possible finding, not 'no concerns'", () => expect(photoTier(0.78)).toBe("possible"));
  it("reports a 54% photo answer as a possible finding", () => expect(photoTier(0.54)).toBe("possible"));
  it("reports an 80%+ photo answer as a clear finding", () => expect(photoTier(0.83)).toBe("clear"));
  it("treats answers under 50% as no clear concern", () => expect(photoTier(0.45)).toBe("none"));
});
