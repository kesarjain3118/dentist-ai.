import { describe, expect, it } from "vitest";
import { photoFindings } from "@/lib/analysis/browser-model";

const C = ["calculus", "caries", "gingivitis", "mouth_ulcer", "tooth_discoloration", "hypodontia"];

describe("photo multi-finding", () => {
  it("lists gum inflammation 54% and tartar 44% together", () => {
    const f = photoFindings([0.44, 0.01, 0.54, 0.0, 0.01, 0.0], C);
    expect(f.map((x) => x.name)).toEqual(["gingivitis", "calculus"]);
  });
  it("drops secondary classes under 30%", () => {
    expect(photoFindings([0.25, 0.05, 0.65, 0.02, 0.02, 0.01], C).map((x) => x.name)).toEqual(["gingivitis"]);
  });
  it("returns nothing when the top class is under 50%", () => {
    expect(photoFindings([0.4, 0.35, 0.1, 0.05, 0.05, 0.05], C)).toEqual([]);
  });
});
