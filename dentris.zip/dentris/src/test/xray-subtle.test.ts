import { describe, expect, it } from "vitest";
import { decode, mapBoxToImage, thresholdFor, xrayResult, xraySummary, XRAY_CLASSES } from "@/lib/analysis/xray-model";

const ROWS = 4 + 31 + 32;
function grid(boxes: { cls: string; score: number; b: [number, number, number, number] }[]) {
  const n = boxes.length, d = new Float32Array(ROWS * n);
  boxes.forEach(({ cls, score, b }, i) => {
    b.forEach((v, r) => (d[r * n + i] = v));
    d[(4 + XRAY_CLASSES.indexOf(cls)) * n + i] = score;
  });
  return { d, n };
}

describe("x-ray per-condition thresholds", () => {
  it("drops caries below its 30% subtle threshold, keeps it at 31%", () => {
    expect(decode(grid([{ cls: "caries", score: 0.29, b: [100, 100, 50, 50] }]).d, 1)).toHaveLength(0);
    expect(decode(grid([{ cls: "caries", score: 0.31, b: [100, 100, 50, 50] }]).d, 1)).toHaveLength(1);
  });
  it("needs 35% for bone loss to be kept", () => {
    expect(thresholdFor("bone_loss").subtle).toBe(0.35);
    expect(decode(grid([{ cls: "bone_loss", score: 0.34, b: [100, 100, 50, 50] }]).d, 1)).toHaveLength(0);
  });
  it("describes caries between 30% and 45% as subtle", () => {
    const s = xraySummary([{ name: "caries", confidence: 0.42, location: "upper_front" }]);
    expect(s.explanation).toMatch(/subtle, low-confidence/);
  });
  it("treats a 42% filling as clear (35% clear threshold)", () => {
    const s = xraySummary([{ name: "filling", confidence: 0.42, location: "upper_front" }]);
    expect(s.explanation).not.toMatch(/subtle/);
  });
  it("does not hide a 45% candidate as normal", () => {
    expect(xrayResult([{ name: "caries", confidence: 0.45, location: "upper_front" }]).status).toBe("complete");
  });
  it("returns no_findings without claiming disease is ruled out", () => {
    const r = xrayResult([]);
    expect(r.status).toBe("no_findings");
    expect(r.explanation).toMatch(/does not rule out/);
  });
});

describe("x-ray deduplication", () => {
  it("keeps one of five overlapping root_piece boxes", () => {
    const g = grid([0.65, 0.48, 0.46, 0.4, 0.35].map((s, i) => ({ cls: "root_piece", score: s, b: [200 + i, 300, 40, 40] as [number, number, number, number] })));
    expect(decode(g.d, g.n)).toHaveLength(1);
  });
  it("keeps the stronger of heavily overlapping root_piece / retained_root", () => {
    const g = grid([
      { cls: "retained_root", score: 0.7, b: [200, 300, 40, 40] },
      { cls: "root_piece", score: 0.5, b: [201, 300, 40, 40] },
    ]);
    const out = decode(g.d, g.n);
    expect(out).toHaveLength(1);
    expect(XRAY_CLASSES[out[0]!.cls]).toBe("retained_root");
  });
  it("keeps two nearby but distinct teeth", () => {
    const g = grid([
      { cls: "caries", score: 0.6, b: [200, 300, 40, 40] },
      { cls: "caries", score: 0.55, b: [250, 300, 40, 40] },
    ]);
    expect(decode(g.d, g.n)).toHaveLength(2);
  });
});

describe("x-ray coordinates", () => {
  const p = { padX: 0, padY: 140, scale: 1, W: 640, H: 360 };
  it("clips a box partly outside the image", () => {
    const b = mapBoxToImage({ cls: 0, score: 0.9, x1: -20, y1: 130, x2: 60, y2: 200 }, p)!;
    expect(b.x).toBe(0);
    expect(b.y).toBe(0);
    expect(b.w).toBeCloseTo(60 / 640);
  });
  it("discards a box entirely in the padding", () => {
    expect(mapBoxToImage({ cls: 0, score: 0.9, x1: 10, y1: 0, x2: 50, y2: 100 }, p)).toBeNull();
  });
});
