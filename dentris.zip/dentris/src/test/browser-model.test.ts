import { describe, expect, it } from "vitest";
import { CLASSES, softmax } from "@/lib/analysis/browser-model";

describe("in-browser dental model", () => {
  it("uses the 6 classes in trained order", () => {
    expect(CLASSES).toEqual(["calculus", "caries", "gingivitis", "mouth_ulcer", "tooth_discoloration", "hypodontia"]);
  });
  it("softmax picks the highest logit", () => {
    const p = softmax([3.5, -4.9, 4.5, -2.4, -0.3, -0.9]);
    expect(p.indexOf(Math.max(...p))).toBe(2);
    expect(p.reduce((a, b) => a + b, 0)).toBeCloseTo(1);
  });
});
