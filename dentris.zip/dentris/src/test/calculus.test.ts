/**
 * Decision-logic regression tests on model score vectors (not real images).
 * They check how scores become findings; they do NOT validate the model's accuracy.
 */
import { describe, expect, it } from "vitest";
import { CLASSES, photoFindings } from "@/lib/analysis/browser-model";

// order: calculus, caries, gingivitis, mouth_ulcer, tooth_discoloration, hypodontia
const names = (p: number[]) => photoFindings(p, CLASSES).map((f) => f.name);

describe("calculus decision logic", () => {
  it("calculus alone", () => expect(names([0.82, 0.05, 0.08, 0.01, 0.03, 0.01])).toEqual(["calculus"]));
  it("calculus with gingivitis (secondary kept)", () =>
    expect(names([0.44, 0.01, 0.54, 0, 0.01, 0])).toEqual(["gingivitis", "calculus"]));
  it("stained teeth: discoloration lead, weak calculus not shown", () =>
    expect(names([0.22, 0.03, 0.05, 0.01, 0.68, 0.01])).toEqual(["tooth_discoloration"]));
  it("normal teeth (flat scores) give no finding", () =>
    expect(names([0.25, 0.15, 0.2, 0.1, 0.2, 0.1])).toEqual([]));
  it("difficult lighting (uncertain top) gives no finding rather than calculus", () =>
    expect(names([0.45, 0.05, 0.1, 0.05, 0.3, 0.05])).toEqual([]));
});

import { isCloseCall } from "@/lib/analysis/browser-model";
// Score vectors measured from real saved scans with the INT8 model (2026-10-14).
describe("calculus close calls (measured scores)", () => {
  it("62% calculus vs 30% gingivitis is not a close call", () =>
    expect(isCloseCall([0.62, 0.06, 0.3, 0, 0.02, 0])).toBe(false));
  it("52% gingivitis vs 44% calculus is a close call", () =>
    expect(isCloseCall([0.44, 0.01, 0.52, 0, 0.03, 0])).toBe(true));
  it("a clear 85% answer is never a close call", () =>
    expect(isCloseCall([0.85, 0.0, 0.15, 0, 0, 0])).toBe(false));
});
