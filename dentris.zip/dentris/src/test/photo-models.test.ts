import { describe, expect, it } from "vitest";
import { PHOTO_MODELS } from "@/lib/analysis/browser-model";

describe("photo model order", () => {
  it("tries ResNet50 first and keeps SigLIP as backup", () => {
    expect(PHOTO_MODELS.map((m) => m.id)).toEqual(["dentist-ai-resnet50", "dentist-ai-siglip"]);
  });
  it("uses the ResNet50 checkpoint's own class order", () => {
    expect(PHOTO_MODELS[0]!.classes).toEqual(["calculus", "caries", "gingivitis", "hypodontia", "tooth_discoloration", "mouth_ulcer"]);
  });
  it("uses ImageNet normalization for ResNet50", () => {
    expect(PHOTO_MODELS[0]!.mean).toEqual([0.485, 0.456, 0.406]);
  });
});
