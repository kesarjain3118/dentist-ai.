import { describe, expect, it } from "vitest";
import { xrayResult, panoramicLocation } from "@/lib/analysis/xray-model";
import { photoFindings, SECONDARY_CONFIDENCE } from "@/lib/analysis/browser-model";
import { findingKey } from "@/components/image-viewer";
import type { Finding } from "@/lib/analysis/types";

const C = ["calculus", "caries", "gingivitis", "mouth_ulcer", "tooth_discoloration", "hypodontia"];
const f = (name: string, confidence: number, x: number, y = 0.3): Finding => ({
  name, confidence, location: panoramicLocation(x + 0.02, y + 0.02), bbox: { x, y, w: 0.04, h: 0.04 },
});

describe("multi-finding acceptance", () => {
  it("normal photo (top under 50%) gives no findings", () => {
    expect(photoFindings([0.3, 0.2, 0.2, 0.1, 0.1, 0.1], C)).toEqual([]);
  });
  it("secondary photo threshold defaults to 30% and is configurable", () => {
    expect(SECONDARY_CONFIDENCE).toBe(0.3);
    expect(photoFindings([0.25, 0, 0.75, 0, 0, 0], C, 0.2).map((x) => x.name)).toEqual(["gingivitis", "calculus"]);
  });
  it("normal X-ray with no qualifying detections is no_findings and does not rule out disease", () => {
    const r = xrayResult([]);
    expect(r.status).toBe("no_findings");
    expect(r.explanation).toMatch(/does not rule out/);
  });
  it("keeps several X-ray findings even when none reach 50%", () => {
    const r = xrayResult([f("caries", 0.42, 0.2), f("filling", 0.38, 0.6), f("impacted_tooth", 0.41, 0.85, 0.7)]);
    expect(r.status).toBe("complete");
    expect(r.findings).toHaveLength(3);
  });
  it("keeps multiple classes at distinct locations", () => {
    const r = xrayResult([f("caries", 0.6, 0.2), f("caries", 0.55, 0.75, 0.7)]);
    expect(new Set(r.findings.map((x) => x.location)).size).toBe(2);
  });
  it("gives same-name findings distinct keys", () => {
    const a = f("filling", 0.6, 0.2), b = f("filling", 0.6, 0.2);
    expect(findingKey(a, 0)).not.toBe(findingKey(b, 1));
  });
});
