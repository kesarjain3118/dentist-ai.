import { describe, expect, it } from "vitest";
import { maskPolygon, traceContour } from "@/lib/analysis/xray-model";

const P = { padX: 0, padY: 0, scale: 1, W: 640, H: 640 };

describe("X-ray segmentation masks", () => {
  it("returns a polygon inside the detection box in 0–1 image coords", () => {
    const size = 16, plane = size * size;
    const proto = new Float32Array(32 * plane);
    // channel 0 positive in a square at grid 4..8
    for (let y = 4; y < 8; y++) for (let x = 4; x < 8; x++) proto[y * size + x] = 1;
    for (let i = 0; i < plane; i++) if (!proto[i]) proto[i] = -1;
    const coefs = new Float32Array(32); coefs[0] = 1;
    const box = { cls: 0, score: 0.9, x1: 0, y1: 0, x2: 640, y2: 640 };
    const m = maskPolygon(proto, coefs, box, P, size)!;
    expect(m.points.length).toBeGreaterThanOrEqual(3);
    for (const [x, y] of m.points) {
      expect(x).toBeGreaterThan(0.25); expect(x).toBeLessThan(0.5);
      expect(y).toBeGreaterThan(0.25); expect(y).toBeLessThan(0.5);
    }
  });

  it("returns null when the mask is empty", () => {
    const size = 16;
    const proto = new Float32Array(32 * size * size).fill(-1);
    const coefs = new Float32Array(32); coefs[0] = 1;
    expect(maskPolygon(proto, coefs, { cls: 0, score: 0.9, x1: 0, y1: 0, x2: 640, y2: 640 }, P, size)).toBeNull();
  });

  it("traces nothing on an empty grid", () => {
    expect(traceContour(new Uint8Array(9), 3, 3)).toEqual([]);
  });
});
