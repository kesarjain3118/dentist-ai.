import { describe, expect, it } from "vitest";
import { reportWarning } from "@/lib/analysis/report-warning";
import type { AnalysisResult } from "@/lib/analysis/types";

const result: AnalysisResult = {
  imageType: "photo", status: "low_confidence", supported: true, findings: [],
  explanation: "", recommendations: [], durationMs: 1000,
  model: { id: "test", version: "1", isMock: false },
};

describe("report uncertainty guidance", () => {
  it("uses photo guidance for uncertain photos", () => {
    expect(reportWarning(result)?.guidance).toBe("photo");
  });
  it("never uses photo guidance for uncertain X-rays", () => {
    for (const status of ["low_confidence", "poor_quality", "unsupported"] as const) {
      expect(reportWarning({ ...result, imageType: "xray", status })?.guidance).toBe("xray");
    }
  });
  it("keeps the existing 65 percent warning boundary", () => {
    const finding = { name: "caries", location: "upper_front", confidence: 0.649 };
    expect(reportWarning({ ...result, status: "complete", findings: [finding] })).not.toBeNull();
    expect(reportWarning({ ...result, status: "complete", findings: [{ ...finding, confidence: 0.65 }] })).toBeNull();
  });
  it("does not warn on no-findings results", () => {
    expect(reportWarning({ ...result, status: "no_findings" })).toBeNull();
  });
});