import { describe, expect, it } from "vitest";
import { decode, panoramicLocation, XRAY_CLASSES } from "@/lib/analysis/xray-model";

describe("x-ray detector", () => {
  it("has the 31 training classes in order", () => {
    expect(XRAY_CLASSES).toHaveLength(31);
    expect(XRAY_CLASSES[0]).toBe("caries");
    expect(XRAY_CLASSES[30]).toBe("primary_teeth");
  });
  it("maps panoramic image left/top to patient's upper right", () => {
    expect(panoramicLocation(0.25, 0.3)).toBe("upper_right_molar");
    expect(panoramicLocation(0.5, 0.7)).toBe("lower_front");
  });
  it("keeps one box per overlapping same-class detection", () => {
    const n = 2, rows = 4 + 31 + 32;
    const d = new Float32Array(rows * n);
    [[100, 100, 50, 50], [102, 101, 50, 50]].forEach((b, i) => b.forEach((v, r) => (d[r * n + i] = v)));
    d[4 * n + 0] = 0.9; d[4 * n + 1] = 0.8;
    expect(decode(d, n)).toHaveLength(1);
  });
});
