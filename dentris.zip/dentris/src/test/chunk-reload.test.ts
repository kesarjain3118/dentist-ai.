import { describe, expect, it } from "vitest";
import { isStaleChunkError } from "@/lib/chunk-reload";

describe("isStaleChunkError", () => {
  it("detects Chrome stale chunk errors", () => {
    expect(isStaleChunkError(new TypeError("Failed to fetch dynamically imported module: https://x/assets/route-CxTChIYe.js"))).toBe(true);
  });
  it("detects Safari stale chunk errors", () => {
    expect(isStaleChunkError(new TypeError("Importing a module script failed."))).toBe(true);
  });
  it("detects TanStack lazy route failures after a missing chunk", () => {
    expect(isStaleChunkError(new TypeError("Cannot read properties of undefined (reading 'component')"))).toBe(true);
  });
  it("ignores unrelated errors", () => {
    expect(isStaleChunkError(new Error("Report not found"))).toBe(false);
  });
});
