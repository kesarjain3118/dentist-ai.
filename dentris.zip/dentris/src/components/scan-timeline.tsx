import { useEffect, useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { TrendingDown, TrendingUp, Minus } from "lucide-react";
import { reportsQuery, signedUrls, type Report } from "@/lib/reports";
import { getCondition, pct } from "@/lib/conditions";
import { useQuery } from "@tanstack/react-query";

function topFinding(r: Report) {
  const fs = r.result.findings ?? [];
  return fs.length ? fs.reduce((a, b) => (b.confidence > a.confidence ? b : a)) : undefined;
}

/** Chronological scan history with per-condition confidence trends. */
export function ScanTimeline() {
  const { data: reports } = useQuery(reportsQuery);
  const [thumbs, setThumbs] = useState<Record<string, string>>({});

  const ordered = useMemo(() => [...(reports ?? [])].sort((a, b) => a.created_at.localeCompare(b.created_at)), [reports]);

  useEffect(() => {
    const paths = ordered.map((r) => r.image_path);
    if (!paths.length) return;
    let on = true;
    signedUrls(paths).then((m) => { if (on) setThumbs(m); });
    return () => { on = false; };
  }, [ordered]);

  // Per-condition trend: compare each scan's confidence with the previous scan
  // that had the same top finding.
  const trends = useMemo(() => {
    const lastSeen: Record<string, number> = {};
    const map: Record<string, "up" | "down" | "same" | undefined> = {};
    for (const r of ordered) {
      const top = topFinding(r);
      if (!top) continue;
      const prev = lastSeen[top.name];
      map[r.id] = prev === undefined ? undefined : top.confidence > prev + 0.02 ? "up" : top.confidence < prev - 0.02 ? "down" : "same";
      lastSeen[top.name] = top.confidence;
    }
    return map;
  }, [ordered]);

  if (!ordered.length) return null;

  return (
    <section className="surface p-5 sm:p-6" aria-labelledby="scan-timeline">
      <h2 id="scan-timeline" className="text-xl font-bold">Scan timeline</h2>
      <p className="mt-1 text-sm text-muted-foreground">Your scans over time. Arrows show how the same finding's confidence changed since the previous matching scan.</p>
      <div className="mt-5 flex gap-4 overflow-x-auto pb-2">
        {ordered.map((r) => {
          const top = topFinding(r);
          const c = top ? getCondition(top.name) : undefined;
          const trend = trends[r.id];
          const date = new Date(r.created_at);
          return (
            <Link
              key={r.id}
              to="/reports/$id"
              params={{ id: r.id }}
              className="group w-36 shrink-0 rounded-2xl border border-border bg-card p-2.5 transition hover:border-primary/40"
            >
              <div className="h-24 overflow-hidden rounded-xl bg-secondary">
                {thumbs[r.image_path] ? (
                  <img src={thumbs[r.image_path]} alt="" className="h-full w-full object-cover transition group-hover:scale-105" />
                ) : (
                  <span className="flex h-full items-center justify-center text-xs text-muted-foreground">…</span>
                )}
              </div>
              <p className="mt-2 text-xs font-medium text-muted-foreground">
                {date.toLocaleDateString(undefined, { month: "short", day: "numeric" })}
              </p>
              {top && c ? (
                <p className="mt-0.5 flex items-center gap-1 text-sm font-semibold text-foreground">
                  {c.plain}
                  <span className="ml-auto flex items-center gap-0.5 text-xs font-medium text-muted-foreground">
                    {trend === "up" && <TrendingUp className="h-3.5 w-3.5 text-attention" />}
                    {trend === "down" && <TrendingDown className="h-3.5 w-3.5 text-calm" />}
                    {trend === "same" && <Minus className="h-3.5 w-3.5" />}
                    {pct(top.confidence)}
                  </span>
                </p>
              ) : (
                <p className="mt-0.5 text-sm text-muted-foreground">No clear finding</p>
              )}
            </Link>
          );
        })}
      </div>
    </section>
  );
}
