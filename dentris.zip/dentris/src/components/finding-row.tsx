import { ChevronRight } from "lucide-react";
import type { Finding } from "@/lib/analysis/types";
import { getCondition, pct, toneClasses } from "@/lib/conditions";
import { getLocation } from "@/lib/locations";

export function FindingRow({ finding, active, onClick }: { finding: Finding; active?: boolean; onClick?: () => void }) {
  const c = getCondition(finding.name);
  const t = toneClasses[c.tone];
  return (
    <button
      onClick={onClick}
      className={`group flex w-full items-center gap-4 rounded-2xl border p-4 text-left transition ${active ? "border-brand/40 bg-brand-soft/60" : "border-transparent bg-secondary/60 hover:bg-secondary"}`}
    >
      <span className={`h-10 w-1.5 shrink-0 rounded-full ${t.bar}`} />
      <span className="min-w-0 flex-1">
        <span className="flex flex-wrap items-center gap-2">
          <span className="font-semibold text-foreground">Possible {c.title}</span>
          <span className={`rounded-full ${t.soft} ${t.text} px-2 py-0.5 text-[11px] font-semibold`}>{c.urgency}</span>
        </span>
        <span className="mt-0.5 block text-sm text-muted-foreground">{c.plain} · {getLocation(finding.location).label}</span>
      </span>
      <span className="text-right">
        <span className="block text-lg font-bold tabular-nums text-foreground">{pct(finding.confidence)}</span>
        <span className="block text-[10px] uppercase tracking-wide text-muted-foreground">AI confidence</span>
      </span>
      <ChevronRight className="h-4 w-4 text-muted-foreground transition group-hover:translate-x-0.5" />
    </button>
  );
}
