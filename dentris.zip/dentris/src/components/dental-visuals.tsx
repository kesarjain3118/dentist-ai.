import { getLocation } from "@/lib/locations";

/** Simple, elegant tooth glyph with optional decay stage (0 healthy → 3 advanced). */
export function ToothGlyph({ stage = 0, className = "h-24 w-20" }: { stage?: 0 | 1 | 2 | 3; className?: string }) {
  return (
    <svg viewBox="0 0 80 96" className={className} aria-hidden>
      <defs>
        <linearGradient id={`tg${stage}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="oklch(0.995 0.005 90)" />
          <stop offset="1" stopColor="oklch(0.93 0.02 80)" />
        </linearGradient>
      </defs>
      <path
        d="M20 6c-9 0-14 7-14 17 0 10 3 18 6 28 2 8 4 39 11 39 6 0 6-24 10-24h14c4 0 4 24 10 24 7 0 9-31 11-39 3-10 6-18 6-28 0-10-5-17-14-17-7 0-10 4-20 4S27 6 20 6Z"
        fill={`url(#tg${stage})`}
        stroke="oklch(0.85 0.02 80)"
        strokeWidth="1.2"
      />
      {stage >= 1 && <ellipse cx="46" cy="22" rx={stage === 1 ? 6 : 8} ry={stage === 1 ? 4 : 6} fill={stage === 1 ? "oklch(0.97 0.01 90)" : "oklch(0.55 0.08 55)"} stroke="oklch(0.8 0.03 70)" strokeWidth="0.8" />}
      {stage >= 2 && <ellipse cx="46" cy="23" rx="4" ry="3.5" fill="oklch(0.3 0.05 40)" />}
      {stage >= 3 && <path d="M40 22c-2 10 2 22 0 34" stroke="oklch(0.35 0.06 40)" strokeWidth="3" fill="none" strokeLinecap="round" />}
    </svg>
  );
}

export function StageStrip({ stages }: { stages: { label: string; sub: string }[] }) {
  return (
    <div className="flex items-end justify-between gap-2 rounded-3xl bg-attention-soft/60 px-4 py-6 sm:px-8">
      {stages.map((s, i) => (
        <div key={s.label} className="flex flex-1 items-end">
          <div className="flex flex-1 flex-col items-center text-center">
            <ToothGlyph stage={i as 0 | 1 | 2 | 3} className="h-16 w-14 sm:h-24 sm:w-20" />
            <p className="mt-2 text-xs font-semibold text-foreground sm:text-sm">{s.label}</p>
            <p className="text-[11px] text-muted-foreground sm:text-xs">{s.sub}</p>
          </div>
          {i < stages.length - 1 && <span className="mb-14 text-attention">→</span>}
        </div>
      ))}
    </div>
  );
}

/** Top-down dental arch with highlighted estimated locations. */
export function DentalArch({ locations, active }: { locations: string[]; active?: string }) {
  const teeth = 14;
  const point = (arch: "upper" | "lower", t: number) => {
    const angle = Math.PI * (1 - t);
    const cx = 100, rx = 70, ry = arch === "upper" ? 78 : 70;
    const cy = arch === "upper" ? 112 : 128;
    return arch === "upper"
      ? { x: cx + rx * Math.cos(angle), y: cy - ry * Math.sin(angle) }
      : { x: cx + rx * Math.cos(angle), y: cy + ry * Math.sin(angle) };
  };
  return (
    <svg viewBox="0 0 200 240" className="h-auto w-full max-w-[240px]" role="img" aria-label="Dental arch showing estimated locations">
      {(["upper", "lower"] as const).map((arch) =>
        Array.from({ length: teeth }).map((_, i) => {
          const t = i / (teeth - 1);
          const p = point(arch, t);
          const size = Math.abs(t - 0.5) > 0.3 ? 9 : 7;
          return <circle key={arch + i} cx={p.x} cy={p.y} r={size} fill="oklch(0.985 0.006 85)" stroke="oklch(0.86 0.02 80)" strokeWidth="1" />;
        }),
      )}
      <text x="100" y="58" textAnchor="middle" className="fill-muted-foreground text-[8px]">Upper</text>
      <text x="100" y="188" textAnchor="middle" className="fill-muted-foreground text-[8px]">Lower</text>
      <text x="14" y="122" className="fill-muted-foreground text-[7px]">R</text>
      <text x="182" y="122" className="fill-muted-foreground text-[7px]">L</text>
      {locations.map((code) => {
        const loc = getLocation(code);
        const p = point(loc.arch, loc.t);
        const on = !active || active === code;
        return (
          <g key={code} opacity={on ? 1 : 0.35}>
            <circle cx={p.x} cy={p.y} r="16" fill="oklch(0.6 0.19 22 / 0.18)" className={on ? "animate-breathe" : ""} style={{ transformOrigin: `${p.x}px ${p.y}px` }} />
            <circle cx={p.x} cy={p.y} r="9" fill="oklch(0.6 0.19 22 / 0.85)" />
          </g>
        );
      })}
    </svg>
  );
}
