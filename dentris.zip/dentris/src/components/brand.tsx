import { Link } from "@tanstack/react-router";
import { Globe } from "lucide-react";
import veltrisLogo from "@/assets/veltris-logo.png.asset.json";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function LogoMark({ className = "h-8 w-8" }: { className?: string }) {
  return (
    <svg viewBox="0 0 40 40" className={className} aria-hidden>
      <defs>
        <linearGradient id="lm" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="oklch(0.66 0.11 178)" />
          <stop offset="1" stopColor="oklch(0.54 0.11 192)" />
        </linearGradient>
      </defs>
      <path
        fill="url(#lm)"
        d="M11 5c-4.5 0-7 3.6-7 8.6 0 5 1.6 9.2 3 14 1 3.5 1.8 7.4 4.6 7.4 2.6 0 3-3.6 3.9-7 .6-2.4 1.3-4.6 4.5-4.6s3.9 2.2 4.5 4.6c.9 3.4 1.3 7 3.9 7 2.8 0 3.6-3.9 4.6-7.4 1.4-4.8 3-9 3-14C36 8.6 33.5 5 29 5c-3.9 0-5.6 2.2-9 2.2S14.9 5 11 5Z"
      />
    </svg>
  );
}

export function Logo({ to = "/" as const, tagline = true }: { to?: "/" | "/home" | "/ask"; tagline?: boolean }) {
  return (
    <Link to={to} className="flex items-center gap-2.5" aria-label="Dentist AI home">
      <LogoMark />
      <span className="leading-none">
        <span className="block text-[19px] font-bold tracking-tight text-foreground">Dentist AI</span>
        {tagline && <span className="mt-1 block text-[11px] text-muted-foreground">A clearer way to understand your smile</span>}
      </span>
    </Link>
  );
}

export function VeltrisCredit({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-2 text-muted-foreground" aria-label="Powered by Veltris AI">
      <span className="text-[10px] font-medium uppercase">Powered by</span>
      <img src={veltrisLogo.url} alt="Veltris AI" className={compact ? "h-3.5 w-auto" : "h-4 w-auto"} />
    </div>
  );
}

const LANGS = ["English", "Español", "Français", "Deutsch", "العربية", "日本語"];

export function LanguageSelect() {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger className="flex items-center gap-1.5 rounded-full px-3 py-2 text-sm text-foreground hover:bg-secondary">
        <Globe className="h-4 w-4" /> EN
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48">
        <DropdownMenuLabel className="text-xs text-muted-foreground">Language</DropdownMenuLabel>
        <DropdownMenuItem>English ✓</DropdownMenuItem>
        <DropdownMenuSeparator />
        {LANGS.slice(1).map((l) => (
          <DropdownMenuItem key={l} disabled>
            {l} <span className="ml-auto text-[10px]">Coming soon</span>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export function Disclaimer({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`rounded-2xl bg-brand-soft ${compact ? "p-4" : "p-5"} text-sm`}>
      <p className="font-semibold text-foreground">This is an AI-assisted analysis, not a diagnosis.</p>
      <p className="mt-1 text-muted-foreground">
        A qualified dental professional should confirm any condition. AI confidence is not the same as medical certainty.
      </p>
    </div>
  );
}
