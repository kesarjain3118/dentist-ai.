import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ChevronRight, FileText } from "lucide-react";
import { reportsQuery, signedUrls, statusLabel, type Report } from "@/lib/reports";
import { getCondition } from "@/lib/conditions";

export function useReports() {
  return useQuery(reportsQuery);
}

export function useThumbs(reports: Report[] | undefined) {
  const paths = (reports ?? []).map((r) => r.image_path);
  return useQuery({ queryKey: ["thumbs", paths], queryFn: () => signedUrls(paths), enabled: paths.length > 0, staleTime: 30 * 60 * 1000 });
}

export function ReportList({ limit }: { limit?: number }) {
  const { data, isLoading, error } = useReports();
  const items = limit ? data?.slice(0, limit) : data;
  const thumbs = useThumbs(items);

  if (isLoading) return <div className="space-y-3">{[0, 1, 2].map((i) => <div key={i} className="h-20 animate-pulse rounded-2xl bg-secondary" />)}</div>;
  if (error) return <p className="text-sm text-attention">We couldn't load your reports. Please refresh.</p>;
  if (!items?.length)
    return (
      <div className="rounded-3xl border border-dashed border-border p-10 text-center">
        <FileText className="mx-auto h-8 w-8 text-muted-foreground" strokeWidth={1.5} />
        <p className="mt-3 font-semibold">No reports yet</p>
        <p className="mt-1 text-sm text-muted-foreground">Your analyses will appear here once you upload an image.</p>
        <Link to="/analyze" className="mt-5 inline-flex rounded-full bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground">Analyze an Image</Link>
      </div>
    );

  return (
    <ul className="divide-y divide-border overflow-hidden rounded-3xl border border-border bg-card">
      {items.map((r) => {
        const date = new Date(r.created_at);
        const names = r.result.findings.map((f) => getCondition(f.name).plain);
        return (
          <li key={r.id}>
            <Link to="/reports/$id" params={{ id: r.id }} className="flex items-center gap-4 p-4 transition hover:bg-secondary/60">
              <div className="h-14 w-14 shrink-0 overflow-hidden rounded-xl bg-secondary">
                {thumbs.data?.[r.image_path] && <img src={thumbs.data[r.image_path]} alt="" className="h-full w-full object-cover" loading="lazy" />}
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate font-semibold">{names.length ? names.join(", ") : statusLabel[r.status] ?? r.status}</p>
                <p className="text-sm text-muted-foreground">
                  {r.image_type === "xray" ? "X-ray" : "Photo"} · {date.toLocaleDateString(undefined, { dateStyle: "medium" })}
                </p>
              </div>
              <span className={`hidden rounded-full px-3 py-1 text-xs font-semibold sm:inline ${r.status === "complete" ? "bg-moderate-soft text-moderate" : r.status === "no_findings" ? "bg-calm-soft text-calm" : "bg-secondary text-muted-foreground"}`}>
                {statusLabel[r.status] ?? r.status}
              </span>
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            </Link>
          </li>
        );
      })}
    </ul>
  );
}
