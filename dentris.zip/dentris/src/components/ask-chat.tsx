import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport, type UIMessage } from "ai";
import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from "react";
import ReactMarkdown from "react-markdown";
import { ArrowUp, Camera, ImagePlus, Loader2, ScanLine, Square, Stethoscope, X } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { analyzeImage } from "@/lib/analysis/service";
import type { AnalysisResult } from "@/lib/analysis/types";
import { getCondition, pct, toneClasses } from "@/lib/conditions";
import { LogoMark } from "./brand";

const GENERAL = [
  "Why do my gums bleed when I brush?",
  "Is a root canal painful?",
  "Explain how to read a panoramic X-ray",
  "How often should I replace my toothbrush?",
];
const REPORT = ["Is this serious?", "Can this get worse?", "How can I prevent this?", "What should I ask my dentist?"];

function useHistory(analysisId?: string) {
  return useQuery({
    queryKey: ["chat", analysisId ?? "general"],
    enabled: !!analysisId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("chat_messages")
        .select("id,role,content")
        .eq("analysis_id", analysisId!)
        .order("created_at");
      if (error) throw error;
      return (data ?? []).map<UIMessage>((m) => ({ id: m.id, role: m.role as "user" | "assistant", parts: [{ type: "text", text: m.content }] }));
    },
    staleTime: Infinity,
  });
}

export function AskChat({ analysisId, header }: { analysisId?: string | undefined; header?: ReactNode }) {
  const history = useHistory(analysisId);
  if (analysisId && history.isLoading) return <div className="m-auto h-10 w-10 animate-pulse rounded-full bg-accent" />;
  if (history.error) return <p className="m-auto text-sm text-attention">Couldn't load your conversation. Please refresh.</p>;
  return <ChatWindow key={analysisId ?? "general"} analysisId={analysisId} initial={history.data ?? []} header={header} />;
}

function ChatWindow({ analysisId, initial, header }: { analysisId?: string | undefined; initial: UIMessage[]; header?: ReactNode }) {
  const [input, setInput] = useState("");
  const [scan, setScan] = useState<{ result: AnalysisResult; preview: string } | undefined>();
  const [scanning, setScanning] = useState(false);
  const camera = useRef<HTMLInputElement>(null);
  const area = useRef<HTMLTextAreaElement>(null);
  const scroller = useRef<HTMLDivElement>(null);

  async function scanPhoto(file: File) {
    setScanning(true);
    try {
      const result = await analyzeImage(file, "photo");
      setScan({ result, preview: URL.createObjectURL(file) });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Couldn't scan that photo. Please try another one.");
    } finally {
      setScanning(false);
      if (camera.current) camera.current.value = "";
    }
  }
  const transport = useMemo(
    () =>
      new DefaultChatTransport({
        api: "/api/chat",
        body: analysisId ? { analysisId } : {},
        headers: async (): Promise<Record<string, string>> => {
          const { data } = await supabase.auth.getSession();
          return data.session ? { Authorization: `Bearer ${data.session.access_token}` } : {};
        },
      }),
    [analysisId],
  );
  const { messages, sendMessage, status, stop } = useChat({
    id: analysisId ?? "general",
    messages: initial,
    transport,
    onError: (e) => toast.error(e.message?.includes("{") ? "Dentist AI couldn't answer right now. Please try again." : e.message),
  });
  const busy = status === "submitted" || status === "streaming";

  useEffect(() => {
    scroller.current?.scrollTo({ top: scroller.current.scrollHeight, behavior: "smooth" });
  }, [messages, status]);
  useEffect(() => {
    if (!busy) area.current?.focus({ preventScroll: true });
  }, [busy]);

  function send(text: string) {
    const t = text.trim();
    if (!t || busy) return;
    sendMessage({ text: t });
    setInput("");
  }
  function onSubmit(e: FormEvent) {
    e.preventDefault();
    send(input);
  }
  const suggestions = analysisId ? REPORT : GENERAL;

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div ref={scroller} className="min-h-0 flex-1 overflow-y-auto px-4 sm:px-8">
        {messages.length === 0 ? (
          <div className="mx-auto flex min-h-full max-w-2xl flex-col items-center justify-center py-10 text-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground">
              <Stethoscope className="h-7 w-7" />
            </span>
            <h1 className="mt-5 text-3xl font-bold tracking-tight">How can I help today?</h1>
            <p className="mt-2 text-muted-foreground">
              {analysisId ? "Ask anything about this report — answers use its results only." : "Ask me anything — or upload a tooth photo or X-ray to scan it."}
            </p>
            {header && <div className="mt-4">{header}</div>}
            <div className="mt-8 grid w-full gap-3 sm:grid-cols-2">
              {suggestions.map((s) => (
                <button
                  key={s}
                  onClick={() => send(s)}
                  className="rounded-xl border border-border bg-card px-4 py-3 text-left text-sm transition-colors hover:border-primary/40 hover:bg-accent"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="mx-auto max-w-3xl space-y-6 py-8">
            {header}
            {messages.map((m) =>
              m.role === "user" ? (
                <div key={m.id} className="flex justify-end">
                  <p className="max-w-[85%] rounded-2xl rounded-br-md bg-primary px-4 py-2.5 text-[15px] text-primary-foreground">
                    {m.parts.map((p) => (p.type === "text" ? p.text : "")).join("")}
                  </p>
                </div>
              ) : (
                <div key={m.id} className="flex gap-3">
                  <LogoMark className="mt-0.5 h-6 w-6 shrink-0" />
                  <div className="min-w-0 flex-1 text-[15px] leading-relaxed [&_li]:ml-4 [&_li]:list-disc [&_p]:my-2 [&_strong]:font-semibold [&_ul]:my-2">
                    {m.parts.map((p, i) => (p.type === "text" ? <ReactMarkdown key={i}>{p.text}</ReactMarkdown> : null))}
                  </div>
                </div>
              ),
            )}
            {status === "submitted" && (
              <div className="flex items-center gap-3">
                <LogoMark className="h-6 w-6" />
                <span className="flex gap-1">
                  {[0, 1, 2].map((i) => <span key={i} className="h-1.5 w-1.5 animate-pulse rounded-full bg-primary" style={{ animationDelay: `${i * 150}ms` }} />)}
                </span>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="border-t border-border/60 px-4 pb-3 pt-4 sm:px-8">
        {(scan || scanning) && (
          <div className="mx-auto mb-3 max-w-3xl">
            {scanning ? (
              <div className="flex items-center gap-3 rounded-2xl border border-border bg-card p-4">
                <Loader2 className="h-5 w-5 animate-spin text-primary" />
                <p className="text-sm text-muted-foreground">Scanning your photo with the dental model…</p>
              </div>
            ) : scan ? (
              <ScanCard scan={scan} onClose={() => setScan(undefined)} onAsk={(q: string) => send(q)} />
            ) : null}
          </div>
        )}
        <form onSubmit={onSubmit} className="mx-auto max-w-3xl rounded-2xl border border-input bg-card p-3 shadow-soft focus-within:border-primary">
          <textarea
            ref={area}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                send(input);
              }
            }}
            rows={2}
            placeholder="Ask anything, or attach a dental photo / X-ray…"
            className="w-full resize-none bg-transparent px-1 text-[15px] outline-none placeholder:text-muted-foreground"
            aria-label="Message Dentist AI"
          />
          <div className="mt-2 flex items-center gap-1">
            <input
              ref={camera}
              type="file"
              accept="image/jpeg,image/png,image/webp"
              capture="environment"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) void scanPhoto(f);
              }}
            />
            <button
              type="button"
              onClick={() => camera.current?.click()}
              disabled={scanning}
              className="flex items-center gap-1.5 rounded-lg px-2 py-1.5 text-sm text-muted-foreground hover:bg-secondary hover:text-foreground disabled:opacity-40"
              aria-label="Scan a photo now"
            >
              <Camera className="h-4 w-4" /> Scan now
            </button>
            <Link to="/analyze" className="flex items-center gap-1.5 rounded-lg px-2 py-1.5 text-sm text-muted-foreground hover:bg-secondary hover:text-foreground">
              <ImagePlus className="h-4 w-4" /> Add image
            </Link>
            <Link to="/analyze" className="flex items-center gap-1.5 rounded-lg px-2 py-1.5 text-sm text-primary hover:bg-accent">
              <ScanLine className="h-4 w-4" /> Scan & save
            </Link>
            {busy ? (
              <button type="button" onClick={stop} className="ml-auto flex h-9 w-9 items-center justify-center rounded-xl bg-secondary" aria-label="Stop">
                <Square className="h-4 w-4" />
              </button>
            ) : (
              <button type="submit" disabled={!input.trim()} className="ml-auto flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-primary-foreground disabled:opacity-40" aria-label="Send">
                <ArrowUp className="h-4 w-4" />
              </button>
            )}
          </div>
        </form>
        <p className="mt-2 text-center text-[11px] text-muted-foreground">AI-assisted screening, not a diagnosis. Review results with a qualified dental professional.</p>
      </div>
    </div>
  );
}

function ScanCard({
  scan,
  onClose,
  onAsk,
}: {
  scan: { result: AnalysisResult; preview: string };
  onClose: () => void;
  onAsk: (q: string) => void;
}) {
  const r = scan.result;
  const top = r.findings.length ? r.findings.reduce((a, b) => (b.confidence > a.confidence ? b : a)) : undefined;
  const c = top ? getCondition(top.name) : undefined;
  const t = c ? toneClasses[c.tone] : undefined;
  return (
    <div className="flex gap-4 rounded-2xl border border-border bg-card p-4">
      <img src={scan.preview} alt="Scanned photo" className="h-20 w-20 shrink-0 rounded-xl object-cover" />
      <div className="min-w-0 flex-1">
        {top && c && t ? (
          <>
            <p className="flex flex-wrap items-center gap-2 text-sm font-semibold">
              Possible {c.title}
              <span className={`rounded-full ${t.soft} ${t.text} px-2 py-0.5 text-[11px] font-semibold`}>{c.urgency}</span>
              <span className="ml-auto text-xs font-medium text-muted-foreground">{pct(top.confidence)} confidence</span>
            </p>
            <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{r.explanation}</p>
          </>
        ) : (
          <p className="text-sm text-muted-foreground">{r.explanation}</p>
        )}
        <div className="mt-2 flex flex-wrap items-center gap-2">
          {top && (
            <button
              type="button"
              onClick={() => onAsk(`I just scanned a photo and the model reported possible ${c?.title ?? top.name} at ${pct(top.confidence)} confidence. What does that mean for me?`)}
              className="rounded-full bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground"
            >
              Ask about this result
            </button>
          )}
          <Link to="/analyze" className="rounded-full border border-border px-3 py-1.5 text-xs font-semibold hover:bg-secondary">
            Save as full report
          </Link>
        </div>
        <p className="mt-2 text-[11px] text-muted-foreground">AI-assisted screening, not a diagnosis.</p>
      </div>
      <button type="button" onClick={onClose} className="self-start rounded-full p-1 text-muted-foreground hover:bg-secondary" aria-label="Dismiss scan result">
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}
