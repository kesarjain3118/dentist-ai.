import { Link, Outlet, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { FileText, LayoutGrid, BookOpen, MessageCircle, Settings, Plus, Menu, LogOut } from "lucide-react";
import { Logo, LanguageSelect, VeltrisCredit } from "./brand";
import { supabase } from "@/integrations/supabase/client";
import { useAuth, displayName } from "@/lib/auth";
import { Sheet, SheetContent, SheetTitle } from "@/components/ui/sheet";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const HUBS = [
  { to: "/ask", label: "Chat & Scan", icon: MessageCircle },
  { to: "/home", label: "Dashboard", icon: LayoutGrid },
  { to: "/reports", label: "Scans", icon: FileText },
  { to: "/oral-care", label: "Care & learn", icon: BookOpen },
] as const;

function NavList({ onNavigate }: { onNavigate?: () => void }) {
  const item =
    "flex items-center gap-3 rounded-lg px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground";
  const active = { className: "bg-accent !text-accent-foreground font-medium" };
  return (
    <nav className="flex flex-col gap-0.5">
      {HUBS.map(({ to, label, icon: Icon }) => (
        <Link key={to} to={to} onClick={onNavigate} className={item} activeProps={active}>
          <Icon className="h-4 w-4" strokeWidth={1.8} />
          {label}
        </Link>
      ))}
    </nav>
  );
}

function NewAnalysisButton({ onNavigate }: { onNavigate?: () => void }) {
  return (
    <Link
      to="/analyze"
      onClick={onNavigate}
      className="flex items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
    >
      <Plus className="h-4 w-4" /> New scan
    </Link>
  );
}

export function AppShell() {
  const [open, setOpen] = useState(false);
  const { user } = useAuth();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const name = displayName(user);

  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-30 flex h-14 items-center justify-between gap-2 border-b border-border/60 bg-background/85 px-4 backdrop-blur-xl sm:px-6 print:hidden">
        <div className="flex min-w-0 items-center gap-2">
          <button onClick={() => setOpen(true)} className="shrink-0 rounded-md p-2 hover:bg-secondary lg:hidden" aria-label="Open menu">
            <Menu className="h-5 w-5" />
          </button>
          <Logo to="/ask" />
        </div>
        <div className="flex items-center gap-1">
          <div className="hidden sm:block"><LanguageSelect /></div>
          <DropdownMenu>
            <DropdownMenuTrigger
              className="ml-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-secondary text-xs font-semibold text-foreground"
              aria-label="Account menu"
            >
              {name.charAt(0).toUpperCase()}
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel>
                <span className="block truncate">{name}</span>
                <span className="block truncate text-xs font-normal text-muted-foreground">{user?.email}</span>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => navigate({ to: "/settings" })}>
                <Settings className="mr-2 h-4 w-4" /> Settings
              </DropdownMenuItem>
              <DropdownMenuItem onClick={signOut}>
                <LogOut className="mr-2 h-4 w-4" /> Sign out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </header>

      <aside className="fixed bottom-0 left-0 top-14 hidden w-60 flex-col gap-6 border-r border-border/60 px-3 py-5 lg:flex print:hidden">
        <NewAnalysisButton />
        <NavList />
        <div className="mt-auto flex justify-center border-t border-border/60 pt-4"><VeltrisCredit compact /></div>
      </aside>

      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent side="left" className="w-72 overflow-y-auto p-5">
          <SheetTitle className="sr-only">Navigation</SheetTitle>
          <div className="flex flex-col gap-6">
            <Logo to="/ask" />
            <NewAnalysisButton onNavigate={() => setOpen(false)} />
            <NavList onNavigate={() => setOpen(false)} />
          </div>
        </SheetContent>
      </Sheet>

      <main className="w-full overflow-x-hidden px-4 pb-28 pt-8 sm:px-8 lg:pb-10 lg:pl-[17rem] lg:pr-10">
        <div className="mx-auto max-w-6xl">
          <Outlet />
        </div>
      </main>

      <nav
        className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-border/60 bg-background/90 px-2 pb-[max(env(safe-area-inset-bottom),0.5rem)] pt-2 backdrop-blur-xl lg:hidden print:hidden"
        aria-label="Main"
      >
        {[
          { to: "/ask", label: "Chat", icon: MessageCircle },
          { to: "/reports", label: "Scans", icon: FileText },
          { to: "/analyze", label: "New", icon: Plus },
          { to: "/home", label: "Dashboard", icon: LayoutGrid },
          { to: "/oral-care", label: "Care", icon: BookOpen },
        ].map(({ to, label, icon: Icon }) => (
          <Link
            key={to}
            to={to}
            className="flex flex-col items-center gap-1 rounded-xl py-1.5 text-[11px] text-muted-foreground"
            activeProps={{ className: "!text-foreground font-semibold" }}
          >
            {to === "/analyze" ? (
              <span className="-mt-4 flex h-11 w-11 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-soft">
                <Icon className="h-5 w-5" />
              </span>
            ) : (
              <Icon className="h-5 w-5" strokeWidth={1.8} />
            )}
            {label}
          </Link>
        ))}
      </nav>
    </div>
  );
}
