import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { Stethoscope, HeartPulse, Activity, Sparkles, Clock, HelpCircle, TrendingUp, MapPin } from "lucide-react";
import type { Finding } from "@/lib/analysis/types";
import { getCondition, pct, toneClasses } from "@/lib/conditions";
import { getLocation } from "@/lib/locations";
import { StageStrip, DentalArch } from "./dental-visuals";

const List = ({ items }: { items: string[] }) => (
  <ul className="space-y-2">
    {items.map((i) => (
      <li key={i} className="flex gap-2.5 text-[15px] leading-relaxed text-muted-foreground">
        <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-brand/50" />{i}
      </li>
    ))}
  </ul>
);

type TabKey = "overview" | "symptoms" | "causes" | "treatment" | "prevention" | "faqs";

const TABS: { key: TabKey; label: string }[] = [
  { key: "overview", label: "Overview" },
  { key: "symptoms", label: "Symptoms" },
  { key: "causes", label: "Causes" },
  { key: "treatment", label: "Treatment Options" },
  { key: "prevention", label: "Prevention" },
  { key: "faqs", label: "FAQs" },
];

export function ConditionDetail({ finding, index }: { finding: Finding; index?: number }) {
  const c = getCondition(finding.name);
  const t = toneClasses[c.tone];
  const loc = getLocation(finding.location);
  const [tab, setTab] = useState<TabKey>("overview");

  return (
    <section className="grid gap-5 animate-rise lg:grid-cols-[1fr_320px]" aria-labelledby={`cd-${c.key}`}>
      <div className="surface p-6 sm:p-8">
        <div className="flex flex-wrap items-center gap-3">
          <h2 id={`cd-${c.key}`} className="text-xl font-bold sm:text-2xl">
            {index !== undefined && `${index + 1}. `}Possible {c.title}
          </h2>
          <span className={`rounded-full ${t.soft} ${t.text} px-3 py-1 text-xs font-semibold`}>{c.urgency}</span>
          {finding.location === "whole_image" && finding.confidence < 0.8 && (
            <span className="rounded-full border border-border bg-muted px-3 py-1 text-xs font-semibold text-muted-foreground">
              Moderate confidence
            </span>
          )}
          {finding.confidence < 0.4 && (
            <span className="rounded-full border border-border bg-muted px-3 py-1 text-xs font-semibold text-muted-foreground">
              Subtle · low confidence
            </span>
          )}
          <span className="ml-auto flex items-baseline gap-2">
            <span className="text-xs font-medium text-muted-foreground">AI confidence</span>
            <span className="text-2xl font-bold tabular-nums">{pct(finding.confidence)}</span>
          </span>
        </div>

        <div className="mt-5 -mx-6 overflow-x-auto px-6 pb-1 sm:-mx-8 sm:px-8 print:hidden">
          <div className="flex w-max flex-nowrap gap-1 rounded-full bg-secondary p-1">
            {TABS.map(({ key, label }) => (
              <button
                key={key}
                onClick={() => setTab(key)}
                className={`whitespace-nowrap rounded-full px-3.5 py-1.5 text-[13px] transition sm:px-4 sm:text-sm ${tab === key ? "bg-card font-semibold text-foreground shadow-soft" : "text-muted-foreground hover:text-foreground"}`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-6">
          {tab === "overview" && (
            <div className="grid items-start gap-6 md:grid-cols-[1fr_1.2fr]">
              <div>
                <h3 className="text-lg font-semibold">What is {c.title.toLowerCase()}?</h3>
                <p className="mt-2 leading-relaxed text-muted-foreground">{c.whatIsIt}</p>
                <Link to="/learn/$key" params={{ key: c.key }} className="mt-4 inline-flex rounded-full border border-border px-4 py-2 text-sm font-semibold hover:bg-secondary print:hidden">
                  Learn more →
                </Link>
              </div>
              {c.stages && <StageStrip stages={c.stages} />}
            </div>
          )}
          {tab === "symptoms" && (
            <div>
              <h3 className="flex items-center gap-2 text-lg font-semibold"><Activity className="h-4 w-4 text-brand" /> Common symptoms</h3>
              <div className="mt-3"><List items={c.symptoms} /></div>
            </div>
          )}
          {tab === "causes" && (
            <div>
              <h3 className="flex items-center gap-2 text-lg font-semibold"><HeartPulse className="h-4 w-4 text-brand" /> Why can this happen?</h3>
              <div className="mt-3"><List items={c.causes} /></div>
            </div>
          )}
          {tab === "treatment" && (
            <div>
              <h3 className="flex items-center gap-2 text-lg font-semibold"><Stethoscope className="h-4 w-4 text-brand" /> What can a dentist do?</h3>
              <div className="mt-3"><List items={c.dentistCan} /></div>
              <p className="mt-3 text-xs text-muted-foreground">Your dentist will decide the right approach after an examination.</p>
            </div>
          )}
          {tab === "prevention" && (
            <div className="space-y-5">
              <div>
                <h3 className="flex items-center gap-2 text-lg font-semibold"><Sparkles className="h-4 w-4 text-brand" /> What can I do now?</h3>
                <div className="mt-3"><List items={c.doNow} /></div>
              </div>
              {c.ifIgnored && (
                <div>
                  <h3 className="flex items-center gap-2 text-lg font-semibold"><TrendingUp className="h-4 w-4 text-brand" /> What happens if it is ignored?</h3>
                  <p className="mt-2 text-[15px] leading-relaxed text-muted-foreground">{c.ifIgnored}</p>
                </div>
              )}
            </div>
          )}
          {tab === "faqs" && (
            <div className="space-y-5">
              <div>
                <h3 className="flex items-center gap-2 text-lg font-semibold"><Clock className="h-4 w-4 text-brand" /> When should I see a dentist?</h3>
                <p className="mt-2 text-[15px] leading-relaxed text-muted-foreground">{c.whenToSee}</p>
              </div>
              <div>
                <h3 className="flex items-center gap-2 text-lg font-semibold"><HelpCircle className="h-4 w-4 text-brand" /> Questions to ask your dentist</h3>
                <div className="mt-3"><List items={c.questions} /></div>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="surface flex flex-col p-6">
        <h3 className="flex items-center gap-2 font-semibold"><MapPin className="h-4 w-4 text-brand" /> Where it is on your tooth</h3>
        {loc.teeth !== "—" ? (
          <>
            <div className="flex flex-1 items-center justify-center py-4"><DentalArch locations={[finding.location]} /></div>
            <p className="font-semibold text-foreground">{loc.label}</p>
            <p className="mt-1 text-sm text-muted-foreground">
              Tooth {loc.teeth.includes("–") ? "numbers" : "number"} <span className="font-semibold text-foreground">{loc.teeth}</span> (FDI)
            </p>
            <p className="mt-1 text-xs text-muted-foreground">Estimated location based on the image. Your dentist will confirm the exact tooth.</p>
          </>
        ) : (
          <div className="mt-3 rounded-2xl bg-secondary/60 p-4">
            <p className="font-semibold text-foreground">Whole photo</p>
            <p className="mt-1 text-sm text-muted-foreground">The photo model looks at the whole image, so it can't point to a specific tooth. Your dentist will confirm where it is.</p>
          </div>
        )}
        {c.cdt && (
          <div className="mt-4 rounded-2xl bg-secondary/60 p-4">
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">If treatment is needed</p>
            <p className="mt-1.5 text-sm font-semibold text-foreground">{c.cdt.code} · {c.cdt.label}</p>
            {c.billingNote && <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{c.billingNote}</p>}
            <p className="mt-2 text-[11px] text-muted-foreground">Indicative procedure code for discussion with your clinic — not a quote or a claim.</p>
          </div>
        )}
      </div>
    </section>
  );
}
