import { useState } from "react";
import { Maximize2, Minus, Plus, X } from "lucide-react";
import type { Finding } from "@/lib/analysis/types";
import { getCondition, pct, toneClasses } from "@/lib/conditions";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";

export type ViewMode = "original" | "annotated" | "heatmap";

export function findingKey(f: Finding, index: number) {
  return f.id ?? `${f.name}-${f.location}-${index}`;
}

function Overlay({ findings, mode, active, onSelect }: { findings: Finding[]; mode: ViewMode; active?: string | undefined; onSelect?: ((n: string) => void) | undefined }) {
  if (mode === "original") return null;
  const masked = findings.filter((f) => f.mask && f.mask.points.length >= 3);
  return (
    <>
      {mode === "annotated" && masked.length > 0 && (
        <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 1 1" preserveAspectRatio="none" aria-hidden="true">
          {findings.map((f, i) => {
            if (!f.mask || f.mask.points.length < 3) return null;
            const tone = toneClasses[getCondition(f.name).tone];
            const dim = active && active !== findingKey(f, i);
            return (
              <polygon
                key={findingKey(f, i)}
                points={f.mask.points.map(([x, y]) => `${x},${y}`).join(" ")}
                className={`${tone.text} transition-opacity`}
                fill="currentColor"
                fillOpacity={dim ? 0.08 : 0.28}
                stroke="currentColor"
                strokeOpacity={dim ? 0.35 : 0.95}
                strokeWidth={2}
                vectorEffect="non-scaling-stroke"
                strokeLinejoin="round"
              />
            );
          })}
        </svg>
      )}
      {findings.map((f, i) => {
        if (!f.bbox) return null;
        const key = findingKey(f, i);
        const c = getCondition(f.name);
        const tone = toneClasses[c.tone];
        const dim = active && active !== findingKey(f, i);
        const hasMask = !!f.mask && f.mask.points.length >= 3;
        const style = { left: `${f.bbox.x * 100}%`, top: `${f.bbox.y * 100}%`, width: `${f.bbox.w * 100}%`, height: `${f.bbox.h * 100}%` };
        if (mode === "heatmap") {
          return (
            <div
              key={key}
              className="pointer-events-none absolute rounded-full mix-blend-multiply blur-xl"
              style={{
                ...style,
                transform: "scale(1.6)",
                opacity: dim ? 0.25 : 0.4 + f.confidence * 0.5,
                background: "radial-gradient(circle, oklch(0.62 0.22 25) 0%, oklch(0.8 0.17 80 / 0.7) 45%, transparent 72%)",
              }}
            />
          );
        }
        return (
          <button
            key={key}
            onClick={() => onSelect?.(key)}
            className={`absolute rounded-xl ${hasMask ? "border border-dashed border-transparent hover:border-current" : "border-[2.5px]"} ${tone.ring} transition-opacity ${dim ? "opacity-35" : "opacity-100"}`}
            style={style}
            aria-label={`${c.title}, ${pct(f.confidence)} AI confidence`}
          >
            <span className={`absolute -top-1 left-0 -translate-y-full whitespace-nowrap rounded-lg ${tone.bar} px-2 py-1 text-[11px] font-semibold leading-tight text-primary-foreground shadow-soft`}>
              {c.plain.split(" ")[0]} {pct(f.confidence)}
            </span>
          </button>
        );
      })}
    </>
  );
}

export function ImageViewer({ src, findings, active, onSelect }: { src: string; findings: Finding[]; active?: string | undefined; onSelect?: ((n: string) => void) | undefined }) {
  const [mode, setMode] = useState<ViewMode>(findings.length ? "annotated" : "original");
  const [full, setFull] = useState(false);
  const [zoom, setZoom] = useState(1);
  const hasBoxes = findings.some((f) => f.bbox);

  const frame = (big: boolean) => (
    <div className={`relative overflow-hidden rounded-3xl bg-foreground/95 ${big ? "h-full" : ""}`}>
      <div className="relative mx-auto w-fit origin-center transition-transform duration-300" style={{ transform: `scale(${zoom})` }}>
        <img src={src} alt="Your uploaded dental image" className={`block ${big ? "max-h-[78vh]" : "max-h-[460px]"} w-auto max-w-full object-contain`} />
        <div className="absolute inset-0">
          <Overlay findings={findings} mode={mode} active={active} onSelect={onSelect} />
        </div>
      </div>
    </div>
  );

  const controls = (
    <div className="flex flex-wrap items-center justify-between gap-3">
      <div className="inline-flex rounded-full bg-secondary p-1 text-sm">
        {(["original", "annotated", "heatmap"] as ViewMode[]).map((m) => (
          <button
            key={m}
            disabled={m !== "original" && !hasBoxes}
            onClick={() => setMode(m)}
            className={`rounded-full px-4 py-1.5 capitalize transition disabled:opacity-40 ${mode === m ? "bg-card font-semibold text-foreground shadow-soft" : "text-muted-foreground"}`}
          >
            {m === "annotated" ? "AI analysis" : m}
          </button>
        ))}
      </div>
      <div className="flex items-center gap-1">
        <button onClick={() => setZoom((z) => Math.max(1, z - 0.25))} className="rounded-full p-2 hover:bg-secondary" aria-label="Zoom out"><Minus className="h-4 w-4" /></button>
        <span className="w-12 text-center text-xs text-muted-foreground">{Math.round(zoom * 100)}%</span>
        <button onClick={() => setZoom((z) => Math.min(3, z + 0.25))} className="rounded-full p-2 hover:bg-secondary" aria-label="Zoom in"><Plus className="h-4 w-4" /></button>
        <button onClick={() => setFull(true)} className="rounded-full p-2 hover:bg-secondary" aria-label="Fullscreen"><Maximize2 className="h-4 w-4" /></button>
      </div>
    </div>
  );

  return (
    <div className="space-y-4">
      {frame(false)}
      <div className="print:hidden">{controls}</div>
      <Dialog open={full} onOpenChange={setFull}>
        <DialogContent className="max-w-6xl border-none bg-card p-4 sm:p-6 [&>button]:hidden">
          <DialogTitle className="sr-only">Fullscreen image</DialogTitle>
          <div className="flex justify-end"><button onClick={() => setFull(false)} className="rounded-full p-2 hover:bg-secondary" aria-label="Close"><X className="h-5 w-5" /></button></div>
          {frame(true)}
          {controls}
        </DialogContent>
      </Dialog>
    </div>
  );
}
