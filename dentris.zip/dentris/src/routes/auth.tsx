import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { ArrowRight, Eye, EyeOff, Lock, Mail, ShieldCheck, Sparkles, User, Loader2 } from "lucide-react";
import { toast } from "sonner";
import * as z from "zod";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { useAuth } from "@/lib/auth";
import { Logo, LanguageSelect } from "@/components/brand";
import toothHero from "@/assets/tooth-hero.jpg";

const search = z.object({ redirect: z.string().optional(), mode: z.enum(["signin", "signup"]).optional() });

export const Route = createFileRoute("/auth")({
  validateSearch: search,
  head: () => ({
    meta: [
      { title: "Sign in — Dentist AI" },
      { name: "description", content: "Sign in to Dentist AI to analyze dental photos and X-rays and view your saved reports." },
      { property: "og:title", content: "Sign in — Dentist AI" },
      { property: "og:description", content: "Understand your dental health with AI." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AuthPage,
});

type Mode = "signin" | "signup" | "forgot";

function safeRedirect(r?: string) {
  if (!r) return "/ask";
  try {
    const u = new URL(r, window.location.origin);
    if (u.origin !== window.location.origin || u.pathname.startsWith("/auth")) return "/ask";
    return u.pathname + u.search;
  } catch {
    return "/ask";
  }
}

function AuthPage() {
  const { redirect, mode: initial } = Route.useSearch();
  const navigate = useNavigate();
  const { session } = useAuth();
  const [mode, setMode] = useState<Mode>(initial ?? "signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [sent, setSent] = useState<string | null>(null);

  useEffect(() => {
    if (session) navigate({ href: safeRedirect(redirect), replace: true });
  }, [session, redirect, navigate]);

  async function social(provider: "google" | "apple") {
    setBusy(provider);
    const r = await lovable.auth.signInWithOAuth(provider, { redirect_uri: window.location.origin + "/auth" });
    if (r.error) {
      toast.error("Sign-in didn't complete. Please try again.");
      setBusy(null);
    }
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy("form");
    try {
      if (mode === "signin") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      } else if (mode === "signup") {
        if (password.length < 8) throw new Error("Use at least 8 characters for your password.");
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: window.location.origin + "/ask", data: { full_name: name } },
        });
        if (error) throw error;
        if (!data.session) setSent("Check your inbox to confirm your email, then sign in.");
      } else {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: window.location.origin + "/reset-password",
        });
        if (error) throw error;
        setSent("If an account exists for that email, we've sent a reset link.");
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Something went wrong.");
    } finally {
      setBusy(null);
    }
  }

  const title = mode === "signin" ? "Welcome back" : mode === "signup" ? "Create your account" : "Reset your password";
  const sub =
    mode === "signin" ? "Sign in to continue." : mode === "signup" ? "It takes less than a minute." : "We'll email you a secure link.";

  return (
    <div className="grid min-h-screen bg-background lg:grid-cols-[1.1fr_1fr]">
      <section className="relative hidden overflow-hidden bg-wash lg:block">
        <img src={toothHero} alt="" width={1024} height={1280} className="absolute inset-0 h-full w-full object-cover opacity-90" />
        <div className="absolute inset-0 bg-gradient-to-r from-background/90 via-background/40 to-transparent" />
        <div className="relative flex h-full flex-col justify-between p-12">
          <Logo />
          <div className="max-w-md animate-rise">
            <h1 className="text-6xl font-bold leading-[1.02] text-foreground">A healthier, happier smile starts here.</h1>
            <p className="mt-5 text-lg text-muted-foreground">Understand your dental health with AI.</p>
          </div>
          <div className="grid max-w-lg grid-cols-3 gap-6 text-sm">
            {[
              ["AI-assisted insights", "What may be visible"],
              ["Simple guidance", "Clear next steps"],
              ["Track over time", "All your reports"],
            ].map(([t, s]) => (
              <div key={t}>
                <p className="font-semibold text-foreground">{t}</p>
                <p className="text-muted-foreground">{s}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="flex flex-col px-6 py-6 sm:px-12">
        <div className="flex items-center justify-between">
          <div className="lg:hidden">
            <Logo />
          </div>
          <div className="ml-auto">
            <LanguageSelect />
          </div>
        </div>

        <div className="mx-auto flex w-full max-w-md flex-1 flex-col justify-center py-10 animate-rise">
          <p className="mb-6 hidden text-center text-sm text-muted-foreground lg:block">Dentist AI</p>
          <h2 className="text-center text-4xl font-bold text-foreground">{title}</h2>
          <p className="mt-2 text-center text-muted-foreground">{sub}</p>

          {sent ? (
            <div className="mt-10 rounded-2xl bg-brand-soft p-6 text-center">
              <Mail className="mx-auto h-6 w-6 text-brand" />
              <p className="mt-3 font-medium text-foreground">{sent}</p>
              <button onClick={() => { setSent(null); setMode("signin"); }} className="mt-4 text-sm font-semibold text-brand">
                Back to sign in
              </button>
            </div>
          ) : (
            <>
              {mode !== "forgot" && (
                <>
                  <div className="mt-10 space-y-3">
                    <button
                      onClick={() => social("apple")}
                      disabled={!!busy}
                      className="flex w-full items-center justify-center gap-3 rounded-2xl border border-border bg-card py-3.5 font-semibold text-foreground shadow-soft transition hover:bg-secondary disabled:opacity-60"
                    >
                      <svg viewBox="0 0 24 24" className="h-5 w-5 fill-current" aria-hidden><path d="M16.37 12.6c-.02-2.2 1.8-3.26 1.88-3.31-1.03-1.5-2.62-1.7-3.18-1.73-1.35-.14-2.64.8-3.33.8-.69 0-1.74-.78-2.86-.76-1.47.02-2.83.86-3.59 2.17-1.53 2.65-.39 6.58 1.1 8.73.73 1.05 1.6 2.23 2.73 2.19 1.1-.04 1.51-.71 2.84-.71 1.32 0 1.7.71 2.86.69 1.18-.02 1.93-1.07 2.65-2.13.84-1.22 1.18-2.4 1.2-2.46-.03-.01-2.28-.88-2.3-3.48ZM14.2 6.13c.6-.74 1.01-1.75.9-2.77-.87.04-1.93.58-2.55 1.31-.56.65-1.05 1.69-.92 2.68.97.08 1.97-.49 2.57-1.22Z"/></svg>
                      {busy === "apple" ? "Opening Apple…" : "Continue with Apple"}
                    </button>
                    <button
                      onClick={() => social("google")}
                      disabled={!!busy}
                      className="flex w-full items-center justify-center gap-3 rounded-2xl border border-border bg-card py-3.5 font-semibold text-foreground shadow-soft transition hover:bg-secondary disabled:opacity-60"
                    >
                      <svg viewBox="0 0 24 24" className="h-5 w-5" aria-hidden><path fill="#4285F4" d="M22.5 12.27c0-.79-.07-1.54-.19-2.27H12v4.3h5.9a5.05 5.05 0 0 1-2.19 3.31v2.75h3.54c2.07-1.9 3.25-4.71 3.25-8.09Z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.54-2.75c-.98.66-2.24 1.05-3.74 1.05-2.87 0-5.3-1.94-6.17-4.55H2.18v2.84A11 11 0 0 0 12 23Z"/><path fill="#FBBC05" d="M5.83 14.09a6.6 6.6 0 0 1 0-4.18V7.07H2.18a11 11 0 0 0 0 9.86l3.65-2.84Z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15A10.96 10.96 0 0 0 12 1 11 11 0 0 0 2.18 7.07l3.65 2.84C6.7 7.3 9.13 5.38 12 5.38Z"/></svg>
                      {busy === "google" ? "Opening Google…" : "Continue with Google"}
                    </button>
                  </div>
                  <div className="my-7 flex items-center gap-4 text-sm text-muted-foreground">
                    <span className="h-px flex-1 bg-border" /> or <span className="h-px flex-1 bg-border" />
                  </div>
                </>
              )}

              <form onSubmit={submit} className={`space-y-4 ${mode === "forgot" ? "mt-10" : ""}`}>
                {mode === "signup" && (
                  <Field icon={User} label="Your name" value={name} onChange={setName} placeholder="Alex Morgan" autoComplete="name" />
                )}
                <Field icon={Mail} label="Email address" type="email" value={email} onChange={setEmail} placeholder="you@example.com" autoComplete="email" required />
                {mode !== "forgot" && (
                  <div>
                    <Field
                      icon={Lock}
                      label="Password"
                      type={show ? "text" : "password"}
                      value={password}
                      onChange={setPassword}
                      placeholder={mode === "signup" ? "At least 8 characters" : "Enter your password"}
                      autoComplete={mode === "signup" ? "new-password" : "current-password"}
                      required
                      trailing={
                        <button type="button" onClick={() => setShow(!show)} className="text-muted-foreground" aria-label={show ? "Hide password" : "Show password"}>
                          {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      }
                    />
                    {mode === "signin" && (
                      <div className="mt-2 text-right">
                        <button type="button" onClick={() => setMode("forgot")} className="text-sm font-semibold text-brand">
                          Forgot password?
                        </button>
                      </div>
                    )}
                  </div>
                )}
                <button
                  type="submit"
                  disabled={!!busy}
                  className="flex w-full items-center justify-center gap-2 rounded-2xl bg-primary py-4 font-semibold text-primary-foreground shadow-float transition hover:bg-primary/90 disabled:opacity-60"
                >
                  {busy === "form" ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
                  {mode === "signin" ? "Sign in" : mode === "signup" ? "Create account" : "Send reset link"}
                  {busy !== "form" && <ArrowRight className="h-4 w-4" />}
                </button>
              </form>

              <p className="mt-7 text-center text-sm text-muted-foreground">
                {mode === "signin" ? (
                  <>Don't have an account? <button onClick={() => setMode("signup")} className="font-semibold text-brand">Create one</button></>
                ) : (
                  <>Already have an account? <button onClick={() => setMode("signin")} className="font-semibold text-brand">Sign in</button></>
                )}
              </p>
            </>
          )}
        </div>

        <div className="mx-auto max-w-md pb-2 text-center">
          <p className="text-sm font-semibold text-foreground">Your privacy matters.</p>
          <p className="mt-1 flex items-center justify-center gap-3 text-xs text-muted-foreground">
            <ShieldCheck className="h-3.5 w-3.5" /> Secure • Private • AI-assisted insights <Sparkles className="h-3.5 w-3.5" />
          </p>
          <Link to="/" className="mt-3 inline-block text-xs text-muted-foreground underline-offset-4 hover:underline">
            Learn about Dentist AI
          </Link>
        </div>
      </section>
    </div>
  );
}

function Field({
  icon: Icon,
  label,
  value,
  onChange,
  trailing,
  ...rest
}: {
  icon: typeof Mail;
  label: string;
  value: string;
  onChange: (v: string) => void;
  trailing?: React.ReactNode;
} & Omit<React.InputHTMLAttributes<HTMLInputElement>, "onChange" | "value">) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-medium text-foreground">{label}</span>
      <span className="flex items-center gap-3 rounded-2xl border border-input bg-card px-4 py-3.5 transition focus-within:border-brand focus-within:ring-4 focus-within:ring-brand/10">
        <Icon className="h-4 w-4 text-muted-foreground" />
        <input
          {...rest}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="min-w-0 flex-1 bg-transparent text-foreground outline-none placeholder:text-muted-foreground/70"
        />
        {trailing}
      </span>
    </label>
  );
}
