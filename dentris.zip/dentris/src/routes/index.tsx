import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Camera, ScanLine, MessageCircle } from "lucide-react";
import { Logo, LanguageSelect } from "@/components/brand";
import { useAuth } from "@/lib/auth";
import toothHero from "@/assets/tooth-hero.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "AI Dental Image Insights — Dentist AI" },
      { name: "description", content: "Upload a dental photo or X-ray and get simple, AI-assisted insights about what may be visible." },
      { property: "og:title", content: "Dentist AI — Understand your dental health with AI" },
      { property: "og:description", content: "A clearer way to understand your smile." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Landing,
});

function Landing() {
  const { session } = useAuth();
  const cta = session ? "/analyze" : "/auth";
  return (
    <div className="min-h-screen bg-background bg-wash">
      <header className="mx-auto flex max-w-7xl items-center justify-between px-6 py-5">
        <Logo />
        <div className="flex items-center gap-2">
          <LanguageSelect />
          {session ? (
            <Link to="/ask" className="rounded-full bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground">Open app</Link>
          ) : (
            <Link to="/auth" className="rounded-full px-4 py-2.5 text-sm font-semibold text-foreground hover:bg-secondary">Sign in</Link>
          )}
        </div>
      </header>

      <section className="mx-auto grid max-w-7xl items-center gap-10 px-6 pb-20 pt-8 lg:grid-cols-2 lg:pt-16">
        <div className="animate-rise">
          <h1 className="text-5xl font-bold leading-[1.03] text-foreground text-balance-pro sm:text-7xl">
            Understand your dental health with AI.
          </h1>
          <p className="mt-6 max-w-lg text-lg text-muted-foreground">
            Upload a dental photo or X-ray and get simple, AI-assisted insights about what may be visible.
          </p>
          <div className="mt-9 flex flex-wrap gap-3">
            <Link to={cta} className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-4 font-semibold text-primary-foreground shadow-float transition hover:-translate-y-0.5">
              Analyze an Image <ArrowRight className="h-4 w-4" />
            </Link>
            <a href="#how" className="rounded-full px-6 py-4 font-semibold text-foreground hover:bg-secondary">How It Works</a>
          </div>
          <p className="mt-8 text-xs text-muted-foreground">AI-assisted analysis, not a diagnosis. Always confirm with a dentist.</p>
        </div>
        <div className="relative mx-auto aspect-[4/5] w-full max-w-md overflow-hidden rounded-4xl shadow-float">
          <img src={toothHero} alt="A translucent tooth beside a green leaf" width={1024} height={1280} className="h-full w-full object-cover" />
        </div>
      </section>

      <section id="how" className="mx-auto max-w-7xl px-6 pb-28">
        <h2 className="text-3xl font-bold sm:text-4xl">How it works</h2>
        <div className="mt-10 grid gap-10 sm:grid-cols-3">
          {[
            { icon: Camera, t: "Upload", d: "A clear photo of your teeth, or a dental X-ray from your clinic." },
            { icon: ScanLine, t: "Analyze", d: "A specialised model looks for possible findings and where they appear." },
            { icon: MessageCircle, t: "Understand", d: "Plain-language explanations, next steps, and answers to your questions." },
          ].map(({ icon: Icon, t, d }, i) => (
            <div key={t}>
              <span className="text-sm font-semibold text-brand">0{i + 1}</span>
              <Icon className="mt-4 h-6 w-6 text-foreground" strokeWidth={1.6} />
              <h3 className="mt-4 text-xl font-semibold">{t}</h3>
              <p className="mt-2 text-muted-foreground">{d}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="border-t border-border py-8 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} Dentist AI · Educational information only, not medical advice.
      </footer>
    </div>
  );
}
