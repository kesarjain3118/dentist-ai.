import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Logo } from "@/components/brand";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Set a new password — Dentist AI" },
      { name: "description", content: "Choose a new password for your Dentist AI account." },
      { property: "og:title", content: "Set a new password — Dentist AI" },
      { property: "og:description", content: "Choose a new password for your Dentist AI account." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ResetPassword,
});

function ResetPassword() {
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const navigate = useNavigate();

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (password.length < 8) { toast.error("Use at least 8 characters."); return; }
    setBusy(true);
    const { error } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Password updated.");
    navigate({ to: "/ask" });
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-wash px-6">
      <div className="mb-10"><Logo /></div>
      <form onSubmit={submit} className="surface w-full max-w-md p-8">
        <h1 className="text-2xl font-bold">Set a new password</h1>
        <p className="mt-1 text-sm text-muted-foreground">Choose something you haven't used before.</p>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="New password"
          autoComplete="new-password"
          className="mt-6 w-full rounded-2xl border border-input bg-card px-4 py-3.5 outline-none focus:border-brand"
        />
        <button disabled={busy} className="mt-4 w-full rounded-2xl bg-primary py-3.5 font-semibold text-primary-foreground disabled:opacity-60">
          {busy ? "Saving…" : "Update password"}
        </button>
      </form>
    </div>
  );
}
