import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export const Route = createFileRoute("/_authenticated/settings")({
  head: () => ({
    meta: [
      { title: "Settings — Dentist AI" },
      { name: "description", content: "Manage your profile, privacy and data." },
      { property: "og:title", content: "Settings — Dentist AI" },
      { property: "og:description", content: "Manage your profile, privacy and data." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Settings,
});

function Settings() {
  const { user } = useAuth();
  const [name, setName] = useState("");
  const [saving, setSaving] = useState(false);
  const qc = useQueryClient();
  const navigate = useNavigate();

  useEffect(() => {
    if (!user) return;
    supabase.from("profiles").select("display_name").eq("id", user.id).maybeSingle().then(({ data }) => setName(data?.display_name ?? ""));
  }, [user]);

  async function save() {
    if (!user) return;
    setSaving(true);
    const { error } = await supabase.from("profiles").upsert({ id: user.id, display_name: name });
    await supabase.auth.updateUser({ data: { full_name: name } });
    setSaving(false);
    error ? toast.error("Couldn't save.") : toast.success("Profile updated.");
  }

  async function deleteAll() {
    if (!user) return;
    const { data: list } = await supabase.storage.from("dental-images").list(user.id, { limit: 1000 });
    if (list?.length) await supabase.storage.from("dental-images").remove(list.map((f) => `${user.id}/${f.name}`));
    const { error } = await supabase.from("analyses").delete().eq("user_id", user.id);
    if (error) { toast.error("Couldn't delete your data."); return; }
    await qc.invalidateQueries();
    toast.success("All reports and images deleted.");
  }

  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <div className="mx-auto max-w-2xl space-y-8">
      <h1 className="text-4xl font-bold">Settings</h1>

      <section className="surface p-6 sm:p-8">
        <h2 className="text-lg font-semibold">Profile</h2>
        <label className="mt-5 block text-sm font-medium">Name</label>
        <input value={name} onChange={(e) => setName(e.target.value)} className="mt-2 w-full rounded-2xl border border-input bg-card px-4 py-3 outline-none focus:border-brand" />
        <p className="mt-4 text-sm text-muted-foreground">Email: {user?.email}</p>
        <button onClick={save} disabled={saving} className="mt-5 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground disabled:opacity-60">{saving ? "Saving…" : "Save changes"}</button>
      </section>

      <section className="surface p-6 sm:p-8">
        <h2 className="text-lg font-semibold">Privacy & data</h2>
        <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
          <li>Your images and reports are stored privately and are visible only to your account.</li>
          <li>Ask Dentist AI uses your analysis results to answer questions; images aren't shared with the assistant.</li>
          <li>You can delete any report, or all your data, at any time.</li>
        </ul>
        <AlertDialog>
          <AlertDialogTrigger className="mt-6 rounded-full border border-attention/40 px-5 py-2.5 text-sm font-semibold text-attention hover:bg-attention-soft">Delete all my reports</AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete all reports?</AlertDialogTitle>
              <AlertDialogDescription>All your images, results and conversations will be permanently removed.</AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={deleteAll}>Delete everything</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </section>

      <button onClick={signOut} className="rounded-full px-5 py-3 text-sm font-semibold hover:bg-secondary">Sign out</button>
    </div>
  );
}
