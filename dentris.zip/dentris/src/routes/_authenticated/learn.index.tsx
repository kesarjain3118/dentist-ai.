import { createFileRoute, Link } from "@tanstack/react-router";
import { CONDITIONS, toneClasses } from "@/lib/conditions";

export const Route = createFileRoute("/_authenticated/learn/")({
  head: () => ({
    meta: [
      { title: "Learn — Dentist AI" },
      { name: "description", content: "Simple, trustworthy explanations of common dental conditions." },
      { property: "og:title", content: "Learn — Dentist AI" },
      { property: "og:description", content: "Simple explanations of common dental conditions." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <div className="mx-auto max-w-5xl space-y-10">
      <div>
        <h1 className="text-4xl font-bold">Learn</h1>
        <p className="mt-2 text-muted-foreground">Clear, calm explanations of what the analysis may show.</p>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        {Object.values(CONDITIONS).map((c) => (
          <Link key={c.key} to="/learn/$key" params={{ key: c.key }} className="surface group p-7 transition hover:-translate-y-0.5 hover:shadow-float">
            <div className="flex items-center gap-2">
              <span className={`h-2 w-2 rounded-full ${toneClasses[c.tone].bar}`} />
              <span className="text-xs text-muted-foreground">{c.modalities.map((m) => (m === "xray" ? "X-ray" : "Photo")).join(" · ")}</span>
            </div>
            <h2 className="mt-4 text-2xl font-semibold">{c.title}</h2>
            <p className="text-sm text-muted-foreground">{c.plain}</p>
            <p className="mt-3 text-muted-foreground">{c.summary}</p>
            <span className="mt-5 inline-block text-sm font-semibold text-brand">Read more →</span>
          </Link>
        ))}
      </div>
    </div>
  ),
});
