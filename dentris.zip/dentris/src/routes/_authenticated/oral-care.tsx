import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ArrowRight, Search } from "lucide-react";
import { TIPS } from "@/lib/tips";
import { CONDITIONS } from "@/lib/conditions";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/_authenticated/oral-care")({
  head: () => ({
    meta: [
      { title: "Care & Learn — Dentist AI" },
      { name: "description", content: "Daily oral-care guidance and plain-language condition library." },
      { property: "og:title", content: "Care & Learn — Dentist AI" },
      { property: "og:description", content: "Daily oral-care guidance and plain-language condition library." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: OralCare,
});

const GROUPS = [...new Set(TIPS.map((t) => t.group))];
const TABS = ["All", ...GROUPS, "Conditions"] as const;

function OralCare() {
  const [tab, setTab] = useState<string>("All");
  const [q, setQ] = useState("");
  const term = q.trim().toLowerCase();

  const tips = useMemo(
    () =>
      TIPS.filter((t) => (tab === "All" || t.group === tab) && (!term || `${t.title} ${t.body}`.toLowerCase().includes(term))),
    [tab, term],
  );
  const conditions = Object.values(CONDITIONS).filter(
    (c) => !term || `${c.title} ${c.plain} ${c.summary}`.toLowerCase().includes(term),
  );

  return (
    <div className="mx-auto max-w-3xl">
      <header className="border-b border-border pb-6">
        <h1 className="text-2xl font-semibold tracking-tight">Care & learn</h1>
        <p className="mt-1 text-sm text-muted-foreground">Evidence-based habits and plain-language guidance.</p>
      </header>

      <div className="sticky top-14 z-10 -mx-4 flex flex-col gap-3 bg-background/90 px-4 py-4 backdrop-blur sm:mx-0 sm:flex-row sm:items-center sm:justify-between sm:px-0">
        <div className="-mx-1 flex gap-1 overflow-x-auto px-1" role="tablist">
          {TABS.map((t) => (
            <button
              key={t}
              role="tab"
              aria-selected={tab === t}
              onClick={() => setTab(t)}
              className={`shrink-0 rounded-md px-3 py-1.5 text-sm transition-colors ${
                tab === t ? "bg-foreground text-background" : "text-muted-foreground hover:bg-secondary hover:text-foreground"
              }`}
            >
              {t}
            </button>
          ))}
        </div>
        <div className="relative sm:w-56">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search" className="h-9 pl-9" aria-label="Search guidance" />
        </div>
      </div>

      {tab === "Conditions" ? (
        <ul className="divide-y divide-border rounded-xl border border-border bg-card">
          {conditions.map((c) => (
            <li key={c.key}>
              <Link to="/learn/$key" params={{ key: c.key }} className="flex items-center justify-between gap-4 px-5 py-4 transition-colors hover:bg-secondary/50">
                <div className="min-w-0">
                  <p className="font-medium">{c.title}</p>
                  <p className="mt-0.5 line-clamp-1 text-sm text-muted-foreground">{c.summary}</p>
                </div>
                <ArrowRight className="h-4 w-4 shrink-0 text-muted-foreground" />
              </Link>
            </li>
          ))}
          {!conditions.length && <Empty />}
        </ul>
      ) : (
        <ul className="divide-y divide-border rounded-xl border border-border bg-card">
          {tips.map((t) => (
            <li key={t.title} className="grid gap-1 px-5 py-4 sm:grid-cols-[9rem_1fr] sm:gap-6">
              <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground sm:pt-0.5">{t.group}</span>
              <div>
                <p className="font-medium">{t.title}</p>
                <p className="mt-0.5 text-sm leading-relaxed text-muted-foreground">{t.body}</p>
              </div>
            </li>
          ))}
          {!tips.length && <Empty />}
        </ul>
      )}
    </div>
  );
}

function Empty() {
  return <li className="px-5 py-10 text-center text-sm text-muted-foreground">No matches.</li>;
}
