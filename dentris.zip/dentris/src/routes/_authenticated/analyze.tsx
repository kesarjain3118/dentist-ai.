import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useEffect, useRef, useState, type DragEvent } from "react";
import { Camera, Check, ImageUp, ScanLine, AlertCircle, ArrowLeft } from "lucide-react";
import { analyzeImage, validateFile } from "@/lib/analysis/service";
import { AnalysisError, type ImageType } from "@/lib/analysis/types";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/_authenticated/analyze")({
  head: () => ({
    meta: [
      { title: "New analysis — Dentist AI" },
      { name: "description", content: "Upload a dental photo or X-ray for an AI-assisted analysis." },
      { property: "og:title", content: "New analysis — Dentist AI" },
      { property: "og:description", content: "Upload a dental photo or X-ray for an AI-assisted analysis." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Analyze,
});

const STEPS = ["Checking image quality", "Analyzing dental patterns", "Looking for possible findings", "Preparing your results"];

type Phase = "choose" | "upload" | "processing" | "error";

function Analyze() {
  const [phase, setPhase] = useState<Phase>("choose");
  const [type, setType] = useState<ImageType>("photo");
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [step, setStep] = useState(0);
  const [drag, setDrag] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  const cameraInput = useRef<HTMLInputElement>(null);
  const { user } = useAuth();
  const navigate = useNavigate();
  const qc = useQueryClient();

  useEffect(() => () => { if (preview) URL.revokeObjectURL(preview); }, [preview]);

  // Start downloading the AI engine as soon as the page opens, so the scan itself is quick.
  const [modelProgress, setModelProgress] = useState(0);
  useEffect(() => {
    let off: (() => void) | undefined;
    import("@/lib/analysis/browser-model").then(async (m) => {
      const unsub = m.onModelProgress(setModelProgress);
      off = () => { unsub(); };
      if (type === "xray") {
        const x = await import("@/lib/analysis/xray-model");
        x.preloadXrayModel().catch(() => {});
      } else {
        m.preloadModel().catch(() => {});
      }
    });
    return () => off?.();
  }, [type]);
  const modelReady = modelProgress >= 1;

  function pick(f?: File) {
    if (!f) return;
    try {
      validateFile(f);
      setFile(f);
      setPreview(URL.createObjectURL(f));
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Unsupported file.");
    }
  }

  function onDrop(e: DragEvent) {
    e.preventDefault();
    setDrag(false);
    pick(e.dataTransfer.files?.[0]);
  }

  async function run() {
    if (!file || !user) return;
    setPhase("processing");
    setStep(0);
    const timer = setInterval(() => setStep((s) => Math.min(s + 1, STEPS.length - 1)), 900);
    try {
      const ext = file.name.split(".").pop() || "jpg";
      const path = `${user.id}/${crypto.randomUUID()}.${ext}`;
      const upload = supabase.storage.from("dental-images").upload(path, file, { contentType: file.type });
      const [up, result] = await Promise.all([upload, analyzeImage(file, type)]);
      if (up.error) throw new AnalysisError("upload_failed", "Your image couldn't be uploaded. Please try again.");
      const { data, error: dbErr } = await supabase
        .from("analyses")
        .insert({ image_type: type, image_path: path, status: result.status, result: JSON.parse(JSON.stringify(result)) })
        .select("id")
        .single();
      if (dbErr) throw new AnalysisError("api_error", "We couldn't save your report. Please try again.");
      clearInterval(timer);
      setStep(STEPS.length);
      await qc.invalidateQueries({ queryKey: ["reports"] });
      setTimeout(() => navigate({ to: "/reports/$id", params: { id: data.id } }), 400);
    } catch (e) {
      clearInterval(timer);
      setError(e instanceof Error ? e.message : "Something went wrong.");
      setPhase("error");
    }
  }

  if (phase === "processing") {
    return (
      <div className="mx-auto max-w-xl py-10 text-center animate-rise">
        <div className="relative mx-auto aspect-square w-64 overflow-hidden rounded-4xl bg-foreground/90 shadow-float">
          {preview && <img src={preview} alt="" className="h-full w-full object-cover opacity-80" />}
          <div className="absolute inset-x-0 h-1/3 animate-scan bg-gradient-to-b from-transparent via-brand/30 to-transparent" />
        </div>
        <h1 className="mt-10 text-3xl font-bold">Analyzing your image</h1>
        {!modelReady && (
          <div className="mx-auto mt-4 max-w-xs">
            <p className="text-sm text-muted-foreground">Preparing the AI engine (first time only) · {Math.round(modelProgress * 100)}%</p>
            <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-secondary">
              <div className="h-full bg-brand transition-all" style={{ width: `${Math.round(modelProgress * 100)}%` }} />
            </div>
          </div>
        )}
        <ul className="mx-auto mt-8 max-w-xs space-y-4 text-left">
          {STEPS.map((s, i) => (
            <li key={s} className={`flex items-center gap-3 transition-opacity ${i <= step ? "opacity-100" : "opacity-35"}`}>
              <span className={`flex h-6 w-6 items-center justify-center rounded-full ${i < step ? "bg-calm text-primary-foreground" : i === step ? "border-2 border-brand" : "border border-border"}`}>
                {i < step ? <Check className="h-3.5 w-3.5" /> : i === step ? <span className="h-2 w-2 animate-pulse rounded-full bg-brand" /> : null}
              </span>
              <span className="text-[15px] text-foreground">{s}</span>
            </li>
          ))}
        </ul>
        {modelReady && (
          <p className="mt-8 flex items-center justify-center gap-2 text-sm text-muted-foreground animate-pulse">
            <span className="h-1.5 w-1.5 animate-ping rounded-full bg-brand" />
            Almost there — uploading your image and saving the report
          </p>
        )}
      </div>
    );
  }

  if (phase === "error") {
    return (
      <div className="mx-auto max-w-md py-16 text-center">
        <AlertCircle className="mx-auto h-10 w-10 text-attention" />
        <h1 className="mt-5 text-2xl font-bold">We couldn't finish the analysis</h1>
        <p className="mt-2 text-muted-foreground">{error}</p>
        <div className="mt-8 flex justify-center gap-3">
          <button onClick={run} className="rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground">Try again</button>
          <button onClick={() => { setPhase("upload"); setError(null); }} className="rounded-full px-6 py-3 font-semibold hover:bg-secondary">Choose another image</button>
        </div>
      </div>
    );
  }

  if (phase === "choose") {
    return (
      <div className="mx-auto max-w-3xl py-6 animate-rise">
        <h1 className="text-3xl font-bold sm:text-5xl">What would you like to analyze?</h1>
        <p className="mt-3 text-base text-muted-foreground sm:text-lg">Different images are analyzed by different specialised models.</p>
        <div className="mt-10 grid gap-5 sm:grid-cols-2">
          {([
            { t: "photo", icon: Camera, title: "Dental Photo", d: "Upload a clear photo of your teeth or gums." },
            { t: "xray", icon: ScanLine, title: "Dental X-Ray", d: "Upload a supported panoramic or dental X-ray." },
          ] as const).map(({ t, icon: Icon, title, d }) => (
            <button
              key={t}
              onClick={() => { setType(t); setPhase("upload"); }}
              className="surface group p-8 text-left transition hover:-translate-y-1 hover:shadow-float"
            >
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-soft text-brand"><Icon className="h-6 w-6" /></span>
              <h2 className="mt-8 text-2xl font-semibold">{title}</h2>
              <p className="mt-2 text-muted-foreground">{d}</p>
            </button>
          ))}
        </div>
        <div className="mt-10 flex justify-center">
          <EngineStatus ready={modelReady} progress={modelProgress} />
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl py-6 animate-rise">
      <button onClick={() => { setPhase("choose"); setFile(null); setPreview(null); }} className="mb-6 flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> Back
      </button>
      <h1 className="text-2xl font-bold sm:text-4xl">Upload {type === "photo" ? "a dental photo" : "a dental X-ray"}</h1>
      <div className="mt-3">
        <EngineStatus ready={modelReady} progress={modelProgress} />
      </div>

      <div
        onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
        onDragLeave={() => setDrag(false)}
        onDrop={onDrop}
        onClick={() => input.current?.click()}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => e.key === "Enter" && input.current?.click()}
        className={`mt-8 flex min-h-72 cursor-pointer flex-col items-center justify-center rounded-4xl border-2 border-dashed p-8 text-center transition ${drag ? "border-brand bg-brand-soft" : "border-border bg-card hover:border-brand/50"}`}
      >
        {preview ? (
          <img src={preview} alt="Selected image preview" className="max-h-80 rounded-2xl object-contain" />
        ) : (
          <>
            <ImageUp className="h-10 w-10 text-brand" strokeWidth={1.5} />
            <p className="mt-4 text-lg font-semibold"><span className="hidden sm:inline">Drag and drop your image</span><span className="sm:hidden">Tap to choose an image</span></p>
            <p className="text-sm text-muted-foreground"><span className="hidden sm:inline">or click to choose a file · </span>JPG, PNG or WebP up to 15 MB</p>
          </>
        )}
        <input ref={input} type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={(e) => pick(e.target.files?.[0])} />
      </div>
      {type === "photo" && (
        <button
          onClick={() => cameraInput.current?.click()}
          className="mt-3 flex w-full items-center justify-center gap-2 rounded-2xl border border-border bg-card py-3.5 text-sm font-semibold text-foreground transition hover:bg-secondary sm:hidden"
        >
          <Camera className="h-4 w-4 text-brand" /> Take a photo with your camera
        </button>
      )}
      <input ref={cameraInput} type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => pick(e.target.files?.[0])} />
      {error && <p className="mt-4 flex items-center gap-2 text-sm text-attention"><AlertCircle className="h-4 w-4" /> {error}</p>}

      <div className="mt-8 grid gap-6 sm:grid-cols-2">
        <div>
          <p className="font-semibold">For best results</p>
          <ul className="mt-2 space-y-1.5 text-sm text-muted-foreground">
            {(type === "photo"
              ? ["Use bright, even light", "Keep the camera steady and in focus", "Show the area close-up and straight on", "Gently pull lips back"]
              : ["Use the original digital file if possible", "Avoid photos of a screen with glare", "Include the whole X-ray", "Panoramic and bitewing X-rays work best"]
            ).map((t) => <li key={t} className="flex gap-2"><Check className="mt-0.5 h-4 w-4 shrink-0 text-calm" />{t}</li>)}
          </ul>
        </div>
        <div className="flex items-end justify-end gap-3">
          {file && <button onClick={() => { setFile(null); setPreview(null); }} className="rounded-full px-5 py-3 font-semibold hover:bg-secondary">Remove</button>}
          <button disabled={!file} onClick={run} className="rounded-full bg-primary px-7 py-3.5 font-semibold text-primary-foreground shadow-float disabled:opacity-40">
            Analyze image
          </button>
        </div>
      </div>
    </div>
  );
}

function EngineStatus({ ready, progress }: { ready: boolean; progress: number }) {
  if (ready) {
    return (
      <p className="flex items-center gap-2 text-sm text-muted-foreground">
        <Check className="h-4 w-4 text-calm" /> AI engine ready on this device
      </p>
    );
  }
  return (
    <div className="max-w-xs">
      <p className="text-sm text-muted-foreground">
        Getting the AI engine ready (first time only) · {Math.round(progress * 100)}%
      </p>
      <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-secondary">
        <div className="h-full bg-brand transition-all" style={{ width: `${Math.max(4, Math.round(progress * 100))}%` }} />
      </div>
    </div>
  );
}

