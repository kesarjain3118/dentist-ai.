import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { ArrowLeft, Share2, CheckCircle2, Trash2, Clock, AlertCircle, AlertTriangle, SearchX, ChevronLeft, ChevronRight, ImagePlus } from "lucide-react";
import { toast } from "sonner";
import { reportQuery, reportsQuery, signedUrls } from "@/lib/reports";
import { supabase } from "@/integrations/supabase/client";
import { ImageViewer, findingKey } from "@/components/image-viewer";
import { FindingRow } from "@/components/finding-row";
import { ConditionDetail } from "@/components/condition-detail";
import { AskChat } from "@/components/ask-chat";
import { Disclaimer, LogoMark } from "@/components/brand";
import { ClinicalReferralSlip, PrintReferralButton } from "@/components/clinical-referral";
import { VeltrisCredit } from "@/components/brand";
import { Button } from "@/components/ui/button";
import { useAuth, displayName } from "@/lib/auth";
import { reportWarning } from "@/lib/analysis/report-warning";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export const Route = createFileRoute("/_authenticated/reports/$id")({
  head: () => ({
    meta: [
      { title: "Your analysis — Dentist AI" },
      { name: "description", content: "AI-assisted dental analysis results with explanations and next steps." },
      { property: "og:title", content: "Your analysis — Dentist AI" },
      { property: "og:description", content: "AI-assisted dental analysis results." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ReportPage,
});

const STATE_COPY: Record<string, { title: string; body: string }> = {
  no_findings: { title: "No clear concerns detected", body: "The model didn't find anything notable in this image. That's encouraging, but an image can't show everything — keep up regular check-ups." },
  low_confidence: { title: "The AI result is uncertain", body: "The model couldn't identify a finding with enough confidence. This does not rule out a problem or mean the lighting is bad." },
  unsupported: { title: "This image isn't supported", body: "Please upload a dental photo or a supported dental X-ray." },
  poor_quality: { title: "Image quality was too low", body: "Try a sharper, well-lit image taken straight on." },
};

function ReportPage() {
  const { id } = Route.useParams();
  const { data: report, isLoading, error } = useQuery(reportQuery(id));
  const { data: allReports } = useQuery(reportsQuery);
  const [active, setActive] = useState<string | undefined>();
  const [thumbs, setThumbs] = useState<Record<string, string>>({});
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { user } = useAuth();

  const siblings = allReports ?? [];
  const index = siblings.findIndex((s) => s.id === id);
  const prev = index > 0 ? siblings[index - 1] : undefined;
  const next = index >= 0 && index < siblings.length - 1 ? siblings[index + 1] : undefined;

  useEffect(() => {
    const paths = siblings.slice(0, 8).map((s) => s.image_path);
    if (!paths.length) return;
    let on = true;
    signedUrls(paths).then((m) => { if (on) setThumbs(m); });
    return () => { on = false; };
  }, [allReports]);

  if (isLoading) return <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]"><div className="h-[460px] animate-pulse rounded-3xl bg-secondary" /><div className="h-[460px] animate-pulse rounded-3xl bg-secondary" /></div>;
  if (error) return <Empty icon={AlertCircle} title="We couldn't load this report" body="Check your connection and try again." />;
  if (!report) return <Empty icon={SearchX} title="Report not found" body="It may have been deleted." />;

  const r = report.result;
  // Older photo reports stored a placeholder box/location; the photo model never located teeth.
  const findings = r.model.id === "dentist-ai-siglip"
    ? r.findings.map(({ bbox: _b, ...f }) => ({ ...f, location: "whole_image" }))
    : r.findings;
  const selected = findings.find((f, i) => findingKey(f, i) === active) ?? findings[0];
  const date = new Date(report.created_at);
  const warning = reportWarning(r);

  async function share() {
    const url = window.location.href;
    const text = "My Dentist AI report (private — requires my sign-in).";
    try {
      if (navigator.share) await navigator.share({ title: "Dentist AI report", text, url });
      else {
        await navigator.clipboard.writeText(url);
        toast.success("Private link copied. Only you can open it while signed in.");
      }
    } catch { /* cancelled */ }
  }

  async function remove() {
    if (!report) return;
    await supabase.storage.from("dental-images").remove([report.image_path]);
    const { error } = await supabase.from("analyses").delete().eq("id", report.id);
    if (error) { toast.error("Couldn't delete this report."); return; }
    await qc.invalidateQueries({ queryKey: ["reports"] });
    toast.success("Report deleted.");
    navigate({ to: "/reports" });
  }

  return (
    <>
    <div className="screen-report space-y-8">
      <div className="hidden items-center gap-3 print:flex"><LogoMark /><span className="text-xl font-bold">Dentist AI — Analysis report</span></div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="mb-3 flex items-center justify-between gap-4 print:hidden">
            <Link to="/reports" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"><ArrowLeft className="h-4 w-4" /> Back to results</Link>
            {siblings.length > 1 && index >= 0 && (
              <span className="flex items-center gap-1 text-sm text-muted-foreground">
                Image {index + 1} of {siblings.length}
                <button
                  disabled={!prev}
                  onClick={() => prev && navigate({ to: "/reports/$id", params: { id: prev.id } })}
                  className="rounded-full p-1.5 hover:bg-secondary disabled:opacity-30"
                  aria-label="Previous image"
                ><ChevronLeft className="h-4 w-4" /></button>
                <button
                  disabled={!next}
                  onClick={() => next && navigate({ to: "/reports/$id", params: { id: next.id } })}
                  className="rounded-full p-1.5 hover:bg-secondary disabled:opacity-30"
                  aria-label="Next image"
                ><ChevronRight className="h-4 w-4" /></button>
              </span>
            )}
          </div>
          <h1 className="text-2xl font-bold sm:text-4xl">Analysis results</h1>
          <p className="mt-1 text-muted-foreground">
            {r.imageType === "xray" ? "Dental X-ray" : "Dental photo"} · {date.toLocaleDateString(undefined, { dateStyle: "long" })}, {date.toLocaleTimeString(undefined, { timeStyle: "short" })}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2 print:hidden">
          <span className="flex items-center gap-1.5 rounded-full bg-calm-soft px-3 py-2 text-sm font-medium text-calm"><CheckCircle2 className="h-4 w-4" /> Saved to My Reports</span>
          <Button variant="outline" onClick={share} className="rounded-full"><Share2 /> Share</Button>
          <PrintReferralButton />
          <AlertDialog>
            <AlertDialogTrigger className="rounded-full p-2.5 text-muted-foreground hover:bg-secondary" aria-label="Delete report"><Trash2 className="h-4 w-4" /></AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Delete this report?</AlertDialogTitle>
                <AlertDialogDescription>The image, results and conversation will be permanently removed.</AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={remove}>Delete</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>

      {warning && (
        <div className="rounded-2xl border border-attention/30 bg-attention-soft p-5 print:hidden" role="alert">
          <div className="flex items-start gap-3">
            <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-attention" />
            <div className="flex-1">
              <p className="font-semibold text-attention">{warning.title}</p>
              <p className="mt-1 text-sm text-foreground/80">{warning.body}</p>
              <div className="mt-4 grid gap-4 sm:grid-cols-[1.4fr_1fr]">
                <div className="space-y-2 text-sm text-foreground/80">
                  <p className="text-xs font-semibold uppercase tracking-wide text-attention">{warning.guidance === "xray" ? "For this X-ray" : "If you try another photo"}</p>
                  {warning.guidance === "xray" ? (
                    <ul className="list-disc space-y-1.5 pl-4">
                      <li>Use the original panoramic X-ray file, not a phone photo of a screen.</li>
                      <li>Keep the full image uncropped and choose Dental X-ray when uploading.</li>
                      <li>Ask your dentist to review it. Don't get another X-ray just for this app.</li>
                    </ul>
                  ) : (
                    <ul className="list-disc space-y-1.5 pl-4">
                      <li>Fill the frame with the area of concern and keep it in focus.</li>
                      <li>Hold steady and use even light without glare.</li>
                      <li>If it's already clear, a dentist's review is more useful than repeated scans.</li>
                    </ul>
                  )}
                </div>
                <div className="flex flex-col gap-2 self-start">
                  <Link
                    to="/analyze"
                    className="rounded-full border border-attention/40 px-4 py-2 text-center text-sm font-semibold text-attention transition hover:bg-attention/10"
                  >
                    {warning.guidance === "xray" ? "Upload X-ray" : "Try another photo"}
                  </Link>
                  <a
                    href="https://www.google.com/maps/search/dentist+near+me"
                    target="_blank"
                    rel="noreferrer"
                    className="rounded-full border border-border bg-card px-4 py-2 text-center text-sm font-semibold text-foreground transition hover:bg-secondary"
                  >
                    Find a dentist near you
                  </a>
                  <p className="text-[11px] text-muted-foreground">A dentist can examine properly — we don't rank or endorse any clinic.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="grid gap-6 lg:grid-cols-[1.35fr_1fr]">
        <div className="surface p-4 sm:p-5">
          {report.imageUrl ? (
            <ImageViewer src={report.imageUrl} findings={findings} active={active} onSelect={setActive} />
          ) : (
            <div className="flex h-80 items-center justify-center text-muted-foreground">Image unavailable</div>
          )}
          <div className="mt-4 flex gap-3 overflow-x-auto pb-1 print:hidden">
            {siblings.slice(0, 8).map((s) => (
              <button
                key={s.id}
                onClick={() => s.id !== id && navigate({ to: "/reports/$id", params: { id: s.id } })}
                className={`h-20 w-24 shrink-0 overflow-hidden rounded-xl border-2 transition ${s.id === id ? "border-brand" : "border-transparent opacity-70 hover:opacity-100"}`}
                aria-label={`Open analysis from ${new Date(s.created_at).toLocaleDateString()}`}
              >
                {thumbs[s.image_path] ? (
                  <img src={thumbs[s.image_path]} alt="" className="h-full w-full object-cover" />
                ) : (
                  <span className="flex h-full w-full items-center justify-center bg-secondary text-xs text-muted-foreground">…</span>
                )}
              </button>
            ))}
            <Link
              to="/analyze"
              className="flex h-20 w-24 shrink-0 flex-col items-center justify-center gap-1 rounded-xl border-2 border-dashed border-border text-xs text-muted-foreground hover:border-brand/40 hover:text-foreground"
            >
              <ImagePlus className="h-5 w-5" /> Add more images
            </Link>
          </div>
        </div>

        <div className="surface flex flex-col gap-4 p-5 sm:p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold">AI Findings</h2>
            <span className="flex items-center gap-1.5 text-xs text-muted-foreground"><Clock className="h-3.5 w-3.5" /> {(r.durationMs / 1000).toFixed(1)}s</span>
          </div>
          {findings.length ? (
            <div className="space-y-2.5">
              {findings.map((f, i) => (
                <FindingRow key={findingKey(f, i)} finding={f} active={selected === f} onClick={() => setActive(findingKey(f, i))} />
              ))}
            </div>
          ) : (
            <div className="rounded-2xl bg-secondary/70 p-5">
              <p className="font-semibold">{STATE_COPY[r.status]?.title ?? "No findings"}</p>
              <p className="mt-1 text-sm text-muted-foreground">{STATE_COPY[r.status]?.body}</p>
            </div>
          )}
          <p className="text-sm leading-relaxed text-muted-foreground">{r.explanation}</p>
          <div className="mt-auto space-y-3">
            <Disclaimer compact />
            {r.model.isMock && (
              <p className="text-xs text-muted-foreground">Sample result: the dental model isn't connected yet, so these values are illustrative and are not real model metrics.</p>
            )}
          </div>
        </div>
      </div>

      {selected && <ConditionDetail finding={selected} index={findings.indexOf(selected)} />}

      <section className="surface p-6">
        <h2 className="text-xl font-bold">Recommended next steps</h2>
        <ul className="mt-4 grid gap-3 sm:grid-cols-3">
          {r.recommendations.map((t) => (
            <li key={t} className="rounded-2xl bg-secondary/60 p-4 text-[15px] text-foreground">{t}</li>
          ))}
        </ul>
      </section>

      <div className="flex justify-center print:hidden"><VeltrisCredit /></div>

      <section className="surface p-6 sm:p-8 print:hidden">
        <h2 className="text-xl font-bold">Ask Dentist AI</h2>
        <div className="mt-4"><AskChat analysisId={report.id} /></div>
      </section>

      <p className="hidden text-xs text-muted-foreground print:block">
        This is an AI-assisted analysis, not a diagnosis. A qualified dental professional should confirm any condition. AI confidence is not the same as medical certainty.
      </p>
    </div>
    <ClinicalReferralSlip report={report} patientName={displayName(user)} />
    </>
  );
}

function Empty({ icon: Icon, title, body }: { icon: typeof AlertCircle; title: string; body: string }) {
  return (
    <div className="py-20 text-center">
      <Icon className="mx-auto h-10 w-10 text-muted-foreground" />
      <h1 className="mt-4 text-2xl font-bold">{title}</h1>
      <p className="mt-2 text-muted-foreground">{body}</p>
      <Link to="/reports" className="mt-6 inline-flex rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground">Back to My Reports</Link>
    </div>
  );
}
