import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, CalendarCheck, FileText, Plus, ShieldCheck } from "lucide-react";
import { useAuth, displayName } from "@/lib/auth";
import { ReportList, useReports } from "@/components/report-list";
import { TIPS } from "@/lib/tips";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/home")({
  head: () => ({
    meta: [
      { title: "Home — Dentist AI" },
      { name: "description", content: "Your dental health at a glance: recent analyses, guidance and oral-care tips." },
      { property: "og:title", content: "Home — Dentist AI" },
      { property: "og:description", content: "Your dental health at a glance." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

function Home() {
  const { user } = useAuth();
  const { data } = useReports();
  const total = data?.length ?? 0;
  const withFindings = data?.filter((r) => r.result.findings.length).length ?? 0;
  const last = data?.[0];
  const tip = TIPS[new Date().getDate() % TIPS.length]!;

  return (
    <div className="space-y-10 animate-rise">
      <section className="grid gap-8 border-b border-border pb-9 md:grid-cols-[minmax(0,1fr)_auto] md:items-end">
        <div className="min-w-0">
          <p className="text-sm font-medium text-muted-foreground">Welcome back, {displayName(user)}</p>
          <h1 className="mt-2 max-w-2xl text-2xl font-semibold tracking-tight sm:text-3xl">Your dental health, clearly organized.</h1>
          <p className="mt-3 max-w-xl text-base leading-relaxed text-muted-foreground">Review previous results or start a new AI-assisted image analysis.</p>
        </div>
        <Button asChild size="lg" className="w-full rounded-full px-6 md:w-auto">
          <Link to="/analyze"><Plus /> New analysis</Link>
        </Button>
      </section>

      <section className="grid divide-y divide-border border-y border-border sm:grid-cols-3 sm:divide-x sm:divide-y-0">
        <Metric icon={FileText} value={total} label="Saved analyses" />
        <Metric icon={ShieldCheck} value={withFindings} label="With areas to review" />
        <Metric icon={CalendarCheck} value={last ? new Date(last.created_at).toLocaleDateString(undefined, { month: "short", day: "numeric" }) : "—"} label="Last analysis" />
      </section>

      <section className="grid gap-10 lg:grid-cols-[1.6fr_1fr]">
        <div>
          <div className="mb-5 flex items-center justify-between">
            <h2 className="text-lg font-semibold">Recent analyses</h2>
            <Link to="/reports" className="text-sm font-semibold text-brand">View all</Link>
          </div>
          <ReportList limit={3} />
        </div>
        <div>
          <h2 className="mb-5 text-lg font-semibold">Daily care</h2>
          <div className="border-l-2 border-calm pl-5">
            <p className="text-xs font-semibold uppercase text-calm">Today</p>
            <p className="mt-2 font-semibold text-foreground">{tip.title}</p>
            <p className="mt-1 text-sm text-muted-foreground">{tip.body}</p>
          </div>
          <Button asChild variant="ghost" className="mt-5 px-0 text-brand hover:bg-transparent">
            <Link to="/oral-care">View oral care guidance <ArrowRight /></Link>
          </Button>
        </div>
      </section>

    </div>
  );
}

function Metric({ icon: Icon, value, label }: { icon: typeof FileText; value: number | string; label: string }) {
  return (
    <div className="flex items-center gap-4 px-1 py-5 sm:px-6 sm:first:pl-0">
      <Icon className="h-5 w-5 shrink-0 text-muted-foreground" strokeWidth={1.7} />
      <div><p className="text-xl font-bold tabular-nums">{value}</p><p className="text-sm text-muted-foreground">{label}</p></div>
    </div>
  );
}
