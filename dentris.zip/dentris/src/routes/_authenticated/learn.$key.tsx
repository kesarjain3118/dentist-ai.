import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { CONDITIONS } from "@/lib/conditions";
import { StageStrip } from "@/components/dental-visuals";
import { Disclaimer } from "@/components/brand";

export const Route = createFileRoute("/_authenticated/learn/$key")({
  loader: ({ params }) => {
    const c = CONDITIONS[params.key];
    if (!c) throw notFound();
    return { key: c.key };
  },
  head: ({ params }) => {
    const c = CONDITIONS[params.key];
    const t = c ? `${c.title} (${c.plain}) — Dentist AI` : "Learn — Dentist AI";
    return {
      meta: [
        { title: t },
        { name: "description", content: c?.summary ?? "Dental education" },
        { property: "og:title", content: t },
        { property: "og:description", content: c?.summary ?? "Dental education" },
        { property: "og:type", content: "article" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  notFoundComponent: () => <p className="py-20 text-center text-muted-foreground">Topic not found. <Link to="/learn" className="text-brand">Back to Learn</Link></p>,
  component: LearnTopic,
});

function Block({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section>
      <h2 className="text-xl font-semibold">{title}</h2>
      <div className="mt-3 leading-relaxed text-muted-foreground">{children}</div>
    </section>
  );
}
const L = ({ items }: { items: string[] }) => <ul className="list-disc space-y-1 pl-5">{items.map((i) => <li key={i}>{i}</li>)}</ul>;

function LearnTopic() {
  const { key } = Route.useLoaderData();
  const c = CONDITIONS[key]!;
  return (
    <article className="mx-auto max-w-3xl space-y-10">
      <div>
        <Link to="/learn" className="mb-4 flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"><ArrowLeft className="h-4 w-4" /> Learn</Link>
        <p className="text-sm font-medium text-brand">{c.plain}</p>
        <h1 className="mt-1 text-4xl font-bold sm:text-5xl">{c.title}</h1>
        <p className="mt-4 text-lg text-muted-foreground">{c.whatIsIt}</p>
      </div>
      {c.stages && <StageStrip stages={c.stages} />}
      <Block title="Why can this happen?"><L items={c.causes} /></Block>
      <Block title="What symptoms can occur?"><L items={c.symptoms} /></Block>
      <Block title="What happens if it is ignored?"><p>{c.ifIgnored}</p></Block>
      <Block title="What can a dentist do?"><L items={c.dentistCan} /></Block>
      <Block title="What can I do now?"><L items={c.doNow} /></Block>
      <Block title="When should I see a dentist?"><p>{c.whenToSee}</p></Block>
      <Block title="Questions to ask your dentist"><L items={c.questions} /></Block>
      <Disclaimer />
    </article>
  );
}
