import { createFileRoute, Link } from "@tanstack/react-router";
import { Plus } from "lucide-react";
import { ReportList } from "@/components/report-list";
import { ScanTimeline } from "@/components/scan-timeline";

export const Route = createFileRoute("/_authenticated/reports/")({
  head: () => ({
    meta: [
      { title: "My Reports — Dentist AI" },
      { name: "description", content: "All your saved dental analyses in one place." },
      { property: "og:title", content: "My Reports — Dentist AI" },
      { property: "og:description", content: "All your saved dental analyses in one place." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <div className="mx-auto max-w-4xl space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-4xl font-bold">My Reports</h1>
          <p className="mt-2 text-muted-foreground">Every analysis you've run, saved privately to your account.</p>
        </div>
        <Link to="/analyze" className="flex items-center gap-2 rounded-full bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground"><Plus className="h-4 w-4" /> New Analysis</Link>
      </div>
      <ScanTimeline />
      <ReportList />
    </div>
  ),
});
