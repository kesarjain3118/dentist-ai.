import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import * as z from "zod";
import { useReports } from "@/components/report-list";
import { AskChat } from "@/components/ask-chat";

export const Route = createFileRoute("/_authenticated/ask")({
  validateSearch: z.object({ report: z.string().optional() }),
  head: () => ({
    meta: [
      { title: "Chat & Scan — Dentist AI" },
      { name: "description", content: "Ask dental questions in plain language or scan a tooth photo or X-ray." },
      { property: "og:title", content: "Chat & Scan — Dentist AI" },
      { property: "og:description", content: "Ask dental questions or scan a tooth photo or X-ray." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Ask,
});

function Ask() {
  const { report } = Route.useSearch();
  const navigate = useNavigate();
  const { data } = useReports();
  const current = report ? data?.find((r) => r.id === report) : undefined;

  const picker = data?.length ? (
    <div className="flex flex-wrap items-center justify-center gap-2 text-xs">
      <span className="text-muted-foreground">Context:</span>
      <select
        value={report ?? ""}
        onChange={(e) => navigate({ to: "/ask", search: e.target.value ? { report: e.target.value } : {} })}
        className="rounded-lg border border-border bg-card px-2 py-1"
        aria-label="Choose a report"
      >
        <option value="">General questions</option>
        {data.map((r) => (
          <option key={r.id} value={r.id}>
            {new Date(r.created_at).toLocaleDateString(undefined, { dateStyle: "medium" })} · {r.image_type === "xray" ? "X-ray" : "Photo"}
          </option>
        ))}
      </select>
      {current && <Link to="/reports/$id" params={{ id: current.id }} className="font-semibold text-primary">Open report</Link>}
    </div>
  ) : null;

  return (
    <div className="-mx-4 -mb-28 -mt-8 h-[calc(100dvh-3.5rem-5rem)] sm:-mx-8 lg:-mb-10 lg:-ml-[1rem] lg:-mr-10 lg:h-[calc(100dvh-3.5rem)]">
      <AskChat analysisId={current?.id} header={picker} />
    </div>
  );
}
