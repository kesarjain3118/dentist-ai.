import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { AnalysisResult, ImageType } from "./analysis/types";

export interface Report {
  id: string;
  image_type: ImageType;
  image_path: string;
  status: string;
  result: AnalysisResult;
  created_at: string;
}

export const reportsQuery = queryOptions({
  queryKey: ["reports"],
  queryFn: async () => {
    const { data, error } = await supabase
      .from("analyses")
      .select("id,image_type,image_path,status,result,created_at")
      .order("created_at", { ascending: false });
    if (error) throw error;
    return (data ?? []) as unknown as Report[];
  },
});

export const reportQuery = (id: string) =>
  queryOptions({
    queryKey: ["report", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("analyses")
        .select("id,image_type,image_path,status,result,created_at")
        .eq("id", id)
        .maybeSingle();
      if (error) throw error;
      if (!data) return null;
      const report = data as unknown as Report;
      const { data: signed } = await supabase.storage.from("dental-images").createSignedUrl(report.image_path, 3600);
      return { ...report, imageUrl: signed?.signedUrl ?? null };
    },
  });

export async function signedUrls(paths: string[]) {
  if (!paths.length) return {} as Record<string, string>;
  const { data } = await supabase.storage.from("dental-images").createSignedUrls(paths, 3600);
  const out: Record<string, string> = {};
  data?.forEach((d) => {
    if (d.path && d.signedUrl) out[d.path] = d.signedUrl;
  });
  return out;
}

export const statusLabel: Record<string, string> = {
  complete: "Possible findings",
  no_findings: "Nothing notable",
  low_confidence: "Uncertain",
  unsupported: "Unsupported image",
  poor_quality: "Poor image quality",
};
