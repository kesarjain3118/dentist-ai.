/**
 * Patient-friendly educational content keyed by model label.
 * General information only — never a diagnosis.
 */
export type Tone = "attention" | "moderate" | "calm";

export interface ConditionInfo {
  key: string;
  title: string; // "Dental Caries"
  plain: string; // "Cavity"
  tone: Tone;
  urgency: string; // calm guidance label
  modalities: ("photo" | "xray")[];
  summary: string;
  whatIsIt: string;
  causes: string[];
  symptoms: string[];
  ifIgnored: string;
  dentistCan: string[];
  doNow: string[];
  whenToSee: string;
  questions: string[];
  stages?: { label: string; sub: string }[];
  /** Indicative ADA CDT procedure code a clinic might use — for discussion, not a claim. */
  cdt?: { code: string; label: string };
  /** Plain-language note about what billing usually involves. */
  billingNote?: string;
}

export const CONDITIONS: Record<string, ConditionInfo> = {
  caries: {
    key: "caries",

    cdt: { code: "D2391–D2394", label: "Resin-based composite filling" },
    billingNote: "Usually billed per tooth and per surface treated; early spots may only need a low-cost fluoride visit.",
    title: "Dental Caries",
    plain: "Cavity",
    tone: "attention",
    urgency: "Needs attention",
    modalities: ["photo", "xray"],
    summary: "An area where the tooth surface may be breaking down due to acids from bacteria.",
    whatIsIt:
      "Dental caries is damage to the tooth's surface caused by acids that bacteria produce from sugars. It can start as a small chalky white spot and may progress into a visible hole (a cavity) if it isn't treated.",
    causes: [
      "Frequent sugary foods or drinks",
      "Plaque build-up on and between teeth",
      "Brushing or flossing less often",
      "Dry mouth, sometimes from medications",
      "Deep grooves on back teeth that trap food",
    ],
    symptoms: [
      "Sensitivity to hot, cold or sweet",
      "Pain when biting",
      "A visible dark spot or hole",
      "Food getting stuck in one place",
      "Often no symptoms at all in early stages",
    ],
    ifIgnored:
      "Early decay can sometimes be reversed or stopped. If it continues, it may reach deeper layers of the tooth, which can cause pain or infection and may need more involved treatment. This does not mean it will happen to you.",
    dentistCan: [
      "Fluoride treatment or sealants for very early changes",
      "A filling to restore the tooth",
      "A crown if a larger part of the tooth is affected",
      "Root canal treatment if decay reaches the nerve",
    ],
    doNow: [
      "Brush twice daily with fluoride toothpaste",
      "Clean between teeth once a day",
      "Reduce sugary snacks and drinks between meals",
      "Drink water after eating",
    ],
    whenToSee:
      "Book a routine dental visit soon to have the area checked. See a dentist promptly if you have pain, swelling, or sensitivity that lasts.",
    questions: [
      "Is this an early change that can be reversed?",
      "Does this tooth need a filling, and what material do you recommend?",
      "How can I lower my risk of new cavities?",
      "Should I use a higher-fluoride toothpaste?",
    ],
    stages: [
      { label: "Healthy tooth", sub: "Intact enamel" },
      { label: "Early decay", sub: "White spot" },
      { label: "Cavity", sub: "Visible hole" },
      { label: "Advanced", sub: "Deeper damage" },
    ],
  },
  calculus: {
    key: "calculus",

    cdt: { code: "D1110", label: "Professional cleaning (prophylaxis)" },
    billingNote: "Typically a single cleaning visit; deeper deposits below the gumline may be billed as scaling (D4341/D4342).",
    title: "Calculus",
    plain: "Tartar build-up",
    tone: "moderate",
    urgency: "Consider professional evaluation",
    modalities: ["photo", "xray"],
    summary: "Hardened plaque that has mineralised on the teeth, often near the gumline.",
    whatIsIt:
      "Calculus (tartar) is plaque that has hardened on the tooth surface. Unlike soft plaque, it can't be removed by brushing and usually appears as a hard yellow or brown deposit along the gumline. Natural tooth colour, surface stains, fillings and light reflections can look similar in a photo, so only a dentist can confirm it.",
    causes: ["Plaque left on teeth for several days", "Hard-to-reach areas", "Natural mineral content of saliva", "Smoking"],
    symptoms: ["Yellow or brown deposits", "Rough feeling on teeth", "Bad breath", "Gums that bleed easily"],
    ifIgnored:
      "Tartar can make it easier for plaque to collect and may contribute to gum inflammation over time.",
    dentistCan: ["Professional cleaning (scaling and polishing)", "Advice on cleaning hard-to-reach areas"],
    doNow: ["Brush along the gumline at an angle", "Clean between teeth daily", "Consider an electric toothbrush"],
    whenToSee: "Tartar can only be removed professionally — a routine cleaning appointment is a good next step.",
    questions: ["How often should I have a professional cleaning?", "Which areas am I missing when I brush?"],
  },
  gingivitis: {
    key: "gingivitis",

    cdt: { code: "D4346", label: "Scaling in the presence of gum inflammation" },
    billingNote: "Often resolved with one cleaning visit; persistent cases may need a full gum assessment (D0180).",
    title: "Gingivitis",
    plain: "Gum inflammation",
    tone: "moderate",
    urgency: "Consider professional evaluation",
    modalities: ["photo"],
    summary: "Possible signs of gum inflammation, such as redness or swelling along the gumline.",
    whatIsIt:
      "Gingivitis is inflammation of the gums, usually caused by plaque along the gumline. It is common and is often reversible with good daily care.",
    causes: ["Plaque along the gumline", "Irregular flossing", "Hormonal changes", "Smoking", "Some medical conditions"],
    symptoms: ["Red or swollen gums", "Bleeding when brushing or flossing", "Tender gums", "Bad breath"],
    ifIgnored:
      "In some people, ongoing gum inflammation can progress to a deeper gum condition that affects the supporting bone.",
    dentistCan: ["Professional cleaning", "Gum assessment and measurement", "Personalised cleaning advice"],
    doNow: ["Brush gently along the gumline twice daily", "Floss or use interdental brushes daily", "Don't stop if gums bleed a little at first"],
    whenToSee: "Mention it at your next check-up. See a dentist sooner if bleeding persists beyond two weeks or gums are painful.",
    questions: ["Is this gingivitis or something deeper?", "What cleaning tools suit my teeth best?"],
  },
  impacted_tooth: {
    key: "impacted_tooth",

    cdt: { code: "D7140–D7241", label: "Extraction of erupted or impacted tooth" },
    billingNote: "Cost varies widely by impaction depth; monitoring with periodic X-rays (D0330) is the low-cost path.",
    title: "Impacted Tooth",
    plain: "Tooth that hasn't fully come through",
    tone: "moderate",
    urgency: "Consider professional evaluation",
    modalities: ["xray"],
    summary: "A tooth — often a wisdom tooth — that may not have fully erupted into position.",
    whatIsIt:
      "An impacted tooth is one that is blocked from fully coming through the gum, often because of limited space. Wisdom teeth are the most common example.",
    causes: ["Limited space in the jaw", "Tooth growing at an angle", "Genetics"],
    symptoms: ["Often none", "Pain or pressure at the back of the mouth", "Swollen gum over the tooth", "Difficulty opening wide"],
    ifIgnored: "Many impacted teeth cause no problems. Some can lead to gum infection or affect nearby teeth.",
    dentistCan: ["Monitor with periodic X-rays", "Recommend removal if it's causing issues"],
    doNow: ["Keep the area clean", "Rinse with warm salt water if the gum feels tender"],
    whenToSee: "Discuss at your next visit. Seek care promptly for swelling, fever, or difficulty opening your mouth.",
    questions: ["Does this tooth need to be removed or just monitored?", "Is it affecting the neighbouring tooth?"],
  },
  bone_loss: {
    key: "bone_loss",

    cdt: { code: "D4341/D4342", label: "Periodontal scaling and root planing" },
    billingNote: "Usually billed per quadrant; a full periodontal charting (D0180) comes first.",
    title: "Possible Bone Level Changes",
    plain: "Changes in supporting bone",
    tone: "moderate",
    urgency: "Consider professional evaluation",
    modalities: ["xray"],
    summary: "Areas where the bone supporting the teeth may appear lower than expected.",
    whatIsIt:
      "The bone around teeth helps hold them in place. X-rays can show areas where this bone level may be reduced, which can be associated with gum disease.",
    causes: ["Long-standing gum inflammation", "Smoking", "Genetics", "Some health conditions such as diabetes"],
    symptoms: ["Often none early on", "Gums pulling back", "Teeth feeling loose", "Persistent bad breath"],
    ifIgnored: "If related to active gum disease, bone changes may continue. A dentist can assess whether this is active.",
    dentistCan: ["Detailed gum assessment", "Deep cleaning", "Referral to a gum specialist if needed"],
    doNow: ["Clean between teeth daily", "Avoid smoking", "Keep regular check-ups"],
    whenToSee: "Book a dental assessment to check your gum and bone health.",
    questions: ["Is this bone loss active or stable?", "Do I need a referral to a periodontist?"],
  },
  abrasion: {
    key: "abrasion",

    cdt: { code: "D2391", label: "Bonded restoration of a worn area" },
    billingNote: "Small bonded fillings are per-tooth; a night guard (D9944) is a separate item if grinding is the cause.",
    title: "Tooth Wear (Abrasion)",
    plain: "Worn tooth surface",
    tone: "moderate",
    urgency: "Consider professional evaluation",
    modalities: ["photo"],
    summary: "Possible wear on the tooth surface, often near the gumline, commonly from brushing too firmly or grinding.",
    whatIsIt:
      "Abrasion is gradual wearing away of the tooth surface, often caused by brushing with too much pressure, a hard toothbrush, or habits like nail biting. It often appears as a notch near the gumline.",
    causes: ["Brushing too hard or with a hard brush", "Teeth grinding or clenching", "Habits like nail biting or holding objects with teeth", "Acidic foods and drinks softening enamel"],
    symptoms: ["A visible notch or groove near the gumline", "Sensitivity to cold or sweet", "Often no symptoms early on"],
    ifIgnored: "Wear can slowly deepen over time, which may increase sensitivity and, in some cases, need a filling to protect the tooth.",
    dentistCan: ["Check the cause of the wear", "Apply fluoride or bonding to protect the area", "Suggest a night guard if grinding is involved"],
    doNow: ["Switch to a soft-bristled toothbrush", "Brush gently in small circles", "Avoid scrubbing side to side"],
    whenToSee: "Mention it at your next check-up, or sooner if the area is sensitive.",
    questions: ["What is causing this wear?", "Do I need treatment or just monitoring?", "Should I use a night guard?"],
  },
  crown: {
    key: "crown",

    cdt: { code: "D2740–D2799", label: "Crown placement or replacement" },
    billingNote: "A healthy crown needs no billing; replacement is one of the higher-cost single-tooth procedures.",
    title: "Dental Crown",
    plain: "Existing crown (cap)",
    tone: "calm",
    urgency: "Routine",
    modalities: ["photo", "xray"],
    summary: "The model detected what appears to be an existing dental crown — a cap placed over a tooth.",
    whatIsIt:
      "A crown is a cap placed over a damaged or treated tooth to restore its shape and strength. This finding usually means the model recognised existing dental work rather than a new problem.",
    causes: ["Previous treatment for a large cavity, crack, or root canal"],
    symptoms: ["Usually none", "Sensitivity or looseness if the crown is ageing"],
    ifIgnored: "A healthy crown needs no action. If it becomes loose or the edge traps plaque, decay can develop underneath.",
    dentistCan: ["Check the crown's fit and edges", "Replace it if it is loose, cracked, or leaking"],
    doNow: ["Brush and floss around the crown edges daily", "Avoid biting very hard foods on it"],
    whenToSee: "Routine check-ups are enough unless the crown feels loose, painful, or rough.",
    questions: ["Is this crown still in good condition?", "How long do crowns usually last?"],
  },
  filling: {
    key: "filling",

    cdt: { code: "D2391–D2394", label: "Filling repair or replacement" },
    billingNote: "Repair is billed per surface; a check-up visit (D0120) confirms whether anything is needed at all.",
    title: "Dental Filling",
    plain: "Existing filling",
    tone: "calm",
    urgency: "Routine",
    modalities: ["photo", "xray"],
    summary: "The model detected what appears to be an existing dental filling — previous restorative work on a tooth.",
    whatIsIt:
      "A filling is material used to repair a tooth after decay or damage. This finding usually means the model recognised existing dental work rather than a new problem.",
    causes: ["Previous treatment for a cavity or minor tooth damage"],
    symptoms: ["Usually none", "Rough edges, sensitivity, or pain if the filling is wearing out"],
    ifIgnored: "Fillings can wear or leak over time, which may let decay develop underneath.",
    dentistCan: ["Check the filling's condition", "Repair or replace it if worn or leaking"],
    doNow: ["Keep brushing and flossing around the filled tooth", "Mention any new sensitivity to your dentist"],
    whenToSee: "Routine check-ups are enough unless you feel pain, sensitivity, or a rough edge.",
    questions: ["Is this filling still sealed and healthy?", "Will it need replacing soon?"],
  },
  mouth_ulcer: {
    key: "mouth_ulcer",

    cdt: { code: "D0140", label: "Limited problem-focused evaluation" },
    billingNote: "Usually a short, low-cost evaluation visit; most ulcers need no procedure at all.",
    title: "Mouth Ulcer",
    plain: "Mouth sore",
    tone: "moderate",
    urgency: "Monitor",
    modalities: ["photo"],
    summary: "The model noticed what may be a small sore on the soft tissue inside the mouth.",
    whatIsIt:
      "Mouth ulcers are small, often painful sores on the gums, cheeks, lips or tongue. Most are harmless and heal on their own within one to two weeks.",
    causes: ["Accidental biting or brushing injury", "Stress or tiredness", "Certain foods or toothpastes", "Some vitamin deficiencies"],
    symptoms: ["A round white, yellow or grey sore with a red edge", "Stinging when eating or drinking"],
    ifIgnored: "Most heal by themselves. A sore that lasts longer than two weeks should always be checked.",
    dentistCan: ["Examine the sore", "Suggest soothing gels or rinses", "Refer you if it needs further checks"],
    doNow: ["Avoid spicy, salty or acidic foods while it heals", "Use a soft toothbrush around the area"],
    whenToSee: "See a dentist or doctor if a sore lasts more than two weeks, keeps coming back, or is very painful.",
    questions: ["Is this a normal ulcer?", "What could be causing repeated sores?"],
  },
  tooth_discoloration: {
    key: "tooth_discoloration",

    cdt: { code: "D9972", label: "External bleaching / whitening (per arch)" },
    billingNote: "Whitening is cosmetic and often not covered by insurance; a cleaning (D1110) may be enough for surface stains.",
    title: "Tooth Discoloration",
    plain: "Staining",
    tone: "calm",
    urgency: "Routine",
    modalities: ["photo"],
    summary: "The model noticed possible staining or colour changes on the teeth.",
    whatIsIt:
      "Tooth discoloration is a change in tooth colour. Surface stains often come from food, drinks or tobacco; deeper colour changes can have other causes a dentist can assess.",
    causes: ["Coffee, tea, red wine or cola", "Tobacco use", "Plaque and tartar build-up", "Ageing or certain medicines"],
    symptoms: ["Yellow, brown or grey areas on teeth", "Uneven tooth colour"],
    ifIgnored: "Surface stains are usually cosmetic, but a single darkening tooth is worth having checked.",
    dentistCan: ["Clean and polish away surface stains", "Discuss safe whitening options", "Check a single dark tooth"],
    doNow: ["Brush twice daily", "Rinse with water after coffee or tea", "Limit tobacco"],
    whenToSee: "Mention it at your next check-up, or sooner if one tooth suddenly darkens.",
    questions: ["Is this staining on the surface or deeper?", "Is whitening safe for me?"],
  },
  hypodontia: {
    key: "hypodontia",

    cdt: { code: "D0150", label: "Comprehensive evaluation" },
    billingNote: "Confirmation is a routine exam plus X-ray; replacement options (bridge D6240+, implant D6010+) are quoted separately.",
    title: "Hypodontia",
    plain: "Missing teeth",
    tone: "moderate",
    urgency: "Consider professional evaluation",
    modalities: ["photo", "xray"],
    summary: "The model noticed what may be one or more teeth that never developed.",
    whatIsIt:
      "Hypodontia means one or more permanent teeth did not form. It is fairly common and is usually confirmed with a dental X-ray.",
    causes: ["Usually genetic or developmental"],
    symptoms: ["Gaps between teeth", "Baby teeth that stay in longer than expected"],
    ifIgnored: "Gaps can let nearby teeth drift or tilt over time.",
    dentistCan: ["Confirm with an X-ray", "Discuss options such as braces, bridges or implants"],
    doNow: ["Keep the area clean", "Note any baby teeth that haven't fallen out"],
    whenToSee: "Book a routine visit to confirm and discuss options.",
    questions: ["Are any teeth missing on my X-ray?", "What options exist to fill the gap?"],
  },
};

export function getCondition(name: string): ConditionInfo {
  return (
    CONDITIONS[name] ?? {
      key: name,
      title: name.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()),
      plain: "Possible finding",
      tone: "moderate",
      urgency: "Consider professional evaluation",
      modalities: ["photo", "xray"],
      summary: "A possible finding identified by the model.",
      whatIsIt: "We don't yet have a detailed explanation for this finding. A dentist can explain what it means for you.",
      causes: [],
      symptoms: [],
      ifIgnored: "",
      dentistCan: [],
      doNow: ["Keep up your regular oral-care routine."],
      whenToSee: "Discuss this at your next dental visit.",
      questions: ["What does this finding mean for me?"],
    }
  );
}

export const toneClasses: Record<Tone, { text: string; soft: string; bar: string; ring: string }> = {
  attention: { text: "text-attention", soft: "bg-attention-soft", bar: "bg-attention", ring: "border-attention" },
  moderate: { text: "text-moderate", soft: "bg-moderate-soft", bar: "bg-moderate", ring: "border-moderate" },
  calm: { text: "text-calm", soft: "bg-calm-soft", bar: "bg-calm", ring: "border-calm" },
};

export const pct = (c: number) => `${Math.round(c * 100)}%`;

/** Compact entries for the panoramic X-ray detector's extra classes. */
function xray(
  key: string, title: string, plain: string, tone: Tone, summary: string, whatIsIt: string,
  dentistCan: string[], cdt?: { code: string; label: string },
): ConditionInfo {
  const concern = tone !== "calm";
  return {
    key, title, plain, tone,
    urgency: tone === "attention" ? "Consider a dental visit soon" : concern ? "Consider professional evaluation" : "Routine",
    modalities: ["xray"], summary, whatIsIt, causes: [], symptoms: [],
    ifIgnored: concern ? "Some X-ray findings can progress without symptoms, so a dentist's review is worthwhile." : "Existing dental work usually needs only routine monitoring.",
    dentistCan, doNow: ["Keep up brushing twice daily and flossing", "Bring this report to your dentist"],
    whenToSee: concern ? "Ask a dentist to review this area on your X-ray." : "Routine check-ups are usually enough.",
    questions: [`Can you confirm the ${plain.toLowerCase()} on my X-ray?`, "Does this need treatment or just monitoring?"],
    ...(cdt ? { cdt, billingNote: "Indicative code for discussion only — your clinic decides what, if anything, is needed." } : {}),
  };
}

Object.assign(CONDITIONS, {
  periapical_lesion: xray("periapical_lesion", "Periapical Lesion", "Possible root-tip infection", "attention",
    "The model marked a darker area near a root tip that may suggest infection or inflammation.",
    "A periapical lesion is a change in the bone around the tip of a tooth root, often linked to infection inside the tooth.",
    ["Confirm with a focused X-ray and tests", "Discuss root canal treatment if needed"], { code: "D3310–D3330", label: "Root canal therapy" }),
  cyst: xray("cyst", "Possible Cyst", "Possible cyst", "attention",
    "The model marked an area that may be a cyst in the jaw.", "A jaw cyst is a fluid-filled sac in the bone. Many are harmless but should be checked.",
    ["Confirm with further imaging", "Refer to an oral surgeon if needed"]),
  fracture_teeth: xray("fracture_teeth", "Fractured Tooth", "Possible cracked tooth", "attention",
    "The model marked a tooth that may be fractured.", "A fracture is a crack or break in a tooth, which can range from minor to serious.",
    ["Examine the tooth", "Repair with a filling, crown or other treatment"], { code: "D2740", label: "Crown" }),
  retained_root: xray("retained_root", "Retained Root", "Possible leftover root", "moderate",
    "The model marked what may be a root left in the jaw.", "A retained root is part of a tooth root left behind, for example after a tooth broke or was removed.",
    ["Check whether it needs removal"], { code: "D7250", label: "Removal of residual root" }),
  root_piece: xray("root_piece", "Root Fragment", "Possible root fragment", "moderate",
    "The model marked what may be a small root fragment.", "A small piece of root remaining in the bone.", ["Check whether it needs removal"], { code: "D7250", label: "Removal of residual root" }),
  root_resorption: xray("root_resorption", "Root Resorption", "Possible root shortening", "moderate",
    "The model marked a root that may be shortening (resorbing).", "Root resorption is when the body gradually breaks down part of a tooth root.", ["Monitor with X-rays", "Discuss treatment options"]),
  missing_teeth: xray("missing_teeth", "Missing Teeth", "Possible missing tooth", "moderate",
    "The model marked a gap where a tooth may be missing.", "A missing tooth can be from extraction, injury or a tooth that never formed.", ["Discuss bridges, implants or dentures"], { code: "D6010", label: "Implant placement" }),
  bone_defect: xray("bone_defect", "Bone Defect", "Possible bone change", "moderate",
    "The model marked an area of possible bone change.", "A localised change in the jaw bone that a dentist should look at.", ["Assess with further imaging"]),
  supra_eruption: xray("supra_eruption", "Supra-eruption", "Over-erupted tooth", "moderate",
    "The model marked a tooth that may have drifted out of line, often due to a missing opposite tooth.", "Supra-eruption is when a tooth moves beyond the bite line.", ["Discuss options to restore the bite"]),
  malaligned: xray("malaligned", "Malaligned Tooth", "Possibly misaligned tooth", "moderate",
    "The model marked a tooth that may be out of alignment.", "A tooth positioned out of the normal arch line.", ["Discuss orthodontic options"]),
  attrition: xray("attrition", "Attrition", "Tooth wear", "moderate",
    "The model marked a tooth that may show wear from grinding or biting.", "Attrition is wear of tooth surfaces from tooth-to-tooth contact, often from grinding.", ["Check for grinding", "Suggest a night guard"], { code: "D9944", label: "Night guard" }),
  root_canal_treatment: xray("root_canal_treatment", "Root Canal Treatment", "Existing root canal", "calm",
    "The model recognised what appears to be an existing root canal filling.", "A root-canal-treated tooth has had its inner pulp cleaned and sealed.", ["Check the root canal remains healthy"]),
  implant: xray("implant", "Dental Implant", "Existing implant", "calm",
    "The model recognised what appears to be a dental implant.", "An implant is a titanium post placed in the jaw to replace a tooth root.", ["Check the bone around the implant"]),
  post_core: xray("post_core", "Post and Core", "Existing post", "calm",
    "The model recognised what appears to be a post supporting a crown.", "A post and core helps hold a crown on a root-treated tooth.", ["Check its fit"]),
  abutment: xray("abutment", "Abutment", "Existing abutment", "calm", "The model recognised what appears to be an implant or bridge abutment.", "An abutment connects an implant or bridge to the crown.", ["Check its fit"]),
  orthodontic_brackets: xray("orthodontic_brackets", "Orthodontic Brackets", "Braces", "calm", "The model recognised braces.", "Brackets are part of braces used to move teeth.", ["Continue orthodontic follow-ups"]),
  permanent_retainer: xray("permanent_retainer", "Permanent Retainer", "Fixed retainer", "calm", "The model recognised a fixed retainer wire.", "A thin wire bonded behind teeth to keep them in place after braces.", ["Check it remains bonded"]),
  wire: xray("wire", "Orthodontic Wire", "Wire", "calm", "The model recognised an orthodontic wire.", "Wire used with braces or splints.", ["Continue follow-ups"]),
  metal_band: xray("metal_band", "Metal Band", "Orthodontic band", "calm", "The model recognised a metal orthodontic band.", "A band placed around a molar as part of braces.", ["Continue follow-ups"]),
  tad: xray("tad", "Temporary Anchorage Device", "Orthodontic mini-screw", "calm", "The model recognised an orthodontic mini-screw.", "A small temporary screw used to help move teeth.", ["Continue follow-ups"]),
  gingival_former: xray("gingival_former", "Gingival Former", "Implant healing cap", "calm", "The model recognised an implant healing cap.", "A cap that shapes the gum while an implant heals.", ["Continue implant follow-ups"]),
  plating: xray("plating", "Bone Plate", "Surgical plate", "calm", "The model recognised what appears to be a surgical plate.", "A plate used to fix bone after surgery or injury.", ["Monitor at routine visits"]),
});
