// After a new deploy, an open tab can request a code chunk that no longer
// exists. Detect that and reload once (cache-busted) to pick up the fresh build.

const KEY = "chunk-reload-at";
const WINDOW_MS = 15_000;

export function isStaleChunkError(error: unknown): boolean {
  const msg = String((error as { message?: unknown })?.message ?? error ?? "");
  return (
    msg.includes("dynamically imported module") || // Chrome / Firefox
    msg.includes("Importing a module script failed") || // Safari
    msg.includes("Unable to preload CSS") ||
    msg.includes("Failed to load module script") ||
    // TanStack's lazyRouteComponent swallows a failed chunk import, then
    // reads `.component` off the missing module.
    /reading '(component|errorComponent|pendingComponent|notFoundComponent)'/.test(msg)
  );
}

/** Reloads with a cache-busting param. Returns false if we already tried recently. */
export function reloadForFreshBuild(): boolean {
  if (typeof window === "undefined") return false;
  const last = Number(sessionStorage.getItem(KEY) ?? 0);
  if (Date.now() - last < WINDOW_MS) return false;
  sessionStorage.setItem(KEY, String(Date.now()));
  const url = new URL(window.location.href);
  url.searchParams.set("v", String(Date.now()));
  window.location.replace(url.toString());
  return true;
}

export function installChunkReloadGuard() {
  if (typeof window === "undefined") return;
  window.addEventListener("vite:preloadError", (event) => {
    event.preventDefault();
    reloadForFreshBuild();
  });
  window.addEventListener("unhandledrejection", (event) => {
    if (isStaleChunkError(event.reason) && reloadForFreshBuild()) event.preventDefault();
  });
  // Strip the cache-busting param once the fresh build loaded.
  const url = new URL(window.location.href);
  if (url.searchParams.has("v")) {
    url.searchParams.delete("v");
    window.history.replaceState(window.history.state, "", url.toString());
  }
}
