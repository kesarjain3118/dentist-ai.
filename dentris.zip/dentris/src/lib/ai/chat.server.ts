import { createGroq } from "@ai-sdk/groq";
import { convertToModelMessages, streamText, type UIMessage } from "ai";
import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import { CONDITIONS } from "@/lib/conditions";
import { getLocation } from "@/lib/locations";
import type { AnalysisResult } from "@/lib/analysis/types";

const GROQ_MODEL = "openai/gpt-oss-120b";

function json(status: number, error: string) {
  return new Response(JSON.stringify({ error }), { status, headers: { "Content-Type": "application/json" } });
}

function userClient(token: string) {
  const url = process.env["SUPABASE_URL"]!;
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"]!;
  return createClient<Database>(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: {
      fetch: (input, init) => {
        const h = new Headers(init?.headers);
        h.set("apikey", key);
        h.set("Authorization", `Bearer ${token}`);
        return fetch(input, { ...init, headers: h });
      },
    },
  });
}

function systemPrompt(result: AnalysisResult, createdAt: string) {
  const findings = result.findings.map((f) => {
    const c = CONDITIONS[f.name];
    return `- ${c?.title ?? f.name} (${c?.plain ?? ""}) — model confidence ${Math.round(f.confidence * 100)}% — estimated location: ${getLocation(f.location).label}`;
  });
  return `You are Dentist AI, a calm, warm assistant that helps everyday people understand an AI dental image analysis.

STRICT RULES
- You did NOT see the image. You only know the structured output of a specialised dental vision model shown below. Never claim to see or re-analyse the image, and never add findings that are not listed.
- Never diagnose. Use "possible", "may", "could be consistent with". Never say "you have X".
- Model confidence is not medical certainty. A qualified dentist must confirm any condition.
- Be reassuring and non-alarming. Prefer "needs attention" or "consider professional evaluation" over scary wording.
- If the user describes severe pain, facial swelling, fever, trouble swallowing or breathing, or trauma, advise contacting a dentist or emergency services promptly.
- Give general, safe oral-care guidance only. Do not prescribe medication doses.
- Keep answers short (under ~180 words), use simple language and short bullet lists where helpful. International audience: no country-specific assumptions.

STRUCTURED MODEL OUTPUT (analysis from ${createdAt})
Image type: ${result.imageType === "xray" ? "Dental X-ray" : "Dental photo"}
Status: ${result.status}
Findings:
${findings.length ? findings.join("\n") : "- None above the confidence threshold"}
Pipeline summary: ${result.explanation}
${result.model.isMock ? "Note: this result came from a sample model used for demonstration; mention this if the user asks about accuracy." : ""}`;
}

const GENERAL_PROMPT = `You are Dentist AI, a calm, warm assistant that answers general dental and oral-health questions for everyday people.
- You have not seen any image. If the user wants an image reviewed, tell them to use "Add image" to run a scan.
- Never diagnose. Use "possible", "may", "could". A qualified dentist must confirm any condition.
- If the user describes severe pain, facial swelling, fever, trouble swallowing or breathing, or trauma, advise contacting a dentist or emergency services promptly.
- Do not prescribe medication doses. Keep answers short (under ~180 words), simple, with short bullet lists where helpful. International audience.`;

export async function handleChat(request: Request) {
  const auth = request.headers.get("authorization");
  const token = auth?.startsWith("Bearer ") ? auth.slice(7) : null;
  if (!token) return json(401, "Please sign in again.");

  let body: { messages?: UIMessage[]; analysisId?: string };
  try {
    body = await request.json();
  } catch {
    return json(400, "Invalid request.");
  }
  const { messages, analysisId } = body;
  if (!Array.isArray(messages) || !messages.length || (analysisId !== undefined && typeof analysisId !== "string")) return json(400, "Invalid request.");

  const supabase = userClient(token);
  const { data: userData, error: userErr } = await supabase.auth.getUser(token);
  if (userErr || !userData.user) return json(401, "Please sign in again.");

  let analysis: { id: string; result: unknown; created_at: string } | null = null;
  if (analysisId) {
    const { data } = await supabase.from("analyses").select("id,result,created_at").eq("id", analysisId).maybeSingle();
    if (!data) return json(404, "Report not found.");
    analysis = data;
  }

  const last = messages[messages.length - 1];
  const lastText = last?.parts?.map((p) => (p.type === "text" ? p.text : "")).join("") ?? "";
  if (analysisId && last?.role === "user" && lastText.trim()) {
    const { error } = await supabase.from("chat_messages").insert({ analysis_id: analysisId, role: "user", content: lastText.slice(0, 4000) });
    if (error) console.error("save user message failed", error);
  }

  const groqKey = process.env["GROQ_API_KEY"];
  if (!groqKey) return json(500, "AI is not configured.");

  const model = createGroq({ apiKey: groqKey })(GROQ_MODEL);

  const result = streamText({
    model,
    system: analysis
      ? systemPrompt(analysis.result as unknown as AnalysisResult, new Date(analysis.created_at).toDateString())
      : GENERAL_PROMPT,
    messages: await convertToModelMessages(messages.slice(-20)),
    abortSignal: request.signal,
  });

  return result.toUIMessageStreamResponse({
      originalMessages: messages,
      onFinish: async ({ responseMessage }) => {
        const text = responseMessage.parts.map((p) => (p.type === "text" ? p.text : "")).join("");
        if (!text.trim() || !analysisId) return;
        const { error } = await supabase.from("chat_messages").insert({ analysis_id: analysisId, role: "assistant", content: text });
        if (error) console.error("save assistant message failed", error);
      },
      onError: (err) => {
        console.error("chat stream error", err);
        const status = (err as { statusCode?: number })?.statusCode;
        if (status === 429) return "Dentist AI is busy right now. Please try again in a moment.";
        if (status === 402) return "AI credits have run out for this workspace.";
        return "Something went wrong while answering. Please try again.";
      },
  });
}
