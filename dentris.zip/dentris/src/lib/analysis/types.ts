/**
 * Shared contract between the dental vision model(s) and the UI.
 * Keep this stable: the UI renders ONLY from this shape, never from model internals.
 */

export type ImageType = "photo" | "xray";

/** Normalised bounding box: values are fractions (0–1) of image width/height. */
export interface BoundingBox {
  x: number;
  y: number;
  w: number;
  h: number;
}

/** Segmentation outline: normalised [x, y] points (0–1) in original image coordinates. */
export interface MaskPolygon {
  points: Array<[number, number]>;
}

export interface Finding {
  /** Stable per-detection id (unique within one result). */
  id?: string;
  /** Machine label from the model, e.g. "caries", "calculus", "impacted_tooth". */
  name: string;
  /** Model confidence 0–1. This is NOT medical certainty. */
  confidence: number;
  /** Machine location label, e.g. "upper_left_molar". */
  location: string;
  /** Optional region for annotation / heatmap. */
  bbox?: BoundingBox;
  /** Optional segmentation outline (X-ray detector only). */
  mask?: MaskPolygon;
}

export type AnalysisStatus =
  | "complete" // findings returned
  | "no_findings" // analysed, nothing notable
  | "low_confidence" // analysed, but nothing above the confidence floor
  | "unsupported" // wrong image type / not a dental image
  | "poor_quality"; // blurry, dark, cropped

export interface AnalysisResult {
  imageType: ImageType;
  status: AnalysisStatus;
  supported: boolean;
  findings: Finding[];
  /** Short plain-language summary from the model pipeline. */
  explanation: string;
  recommendations: string[];
  /** Identifies which model produced this, for traceability. */
  model: { id: string; version: string; isMock: boolean };
  /** Processing time in ms. */
  durationMs: number;
}

export class AnalysisError extends Error {
  constructor(
    public code: "upload_failed" | "network" | "model_unavailable" | "api_error" | "invalid_file",
    message: string,
  ) {
    super(message);
  }
}

/** Findings below this are hidden and the result is treated as uncertain. */
export const CONFIDENCE_FLOOR = 0.5;
