/**
 * Panoramic X-ray detector (YOLOv8x-seg, 31 classes, INT8 ONNX) run in the browser.
 * Browser-only: import dynamically from analyzeImage.
 */
import { fetchModel } from "./browser-model";
import type { AnalysisResult, Finding, MaskPolygon } from "./types";

const XRAY_MODEL_URL =
  (import.meta.env["VITE_XRAY_MODEL_ONNX_URL"] as string | undefined) ||
  "https://aivxdcvrjysrcdputmag.supabase.co/storage/v1/object/public/models/xray-yolov8x-seg-int8.onnx";
const ORT_VERSION = "1.30.0";
const SIZE = 640;

/** Model output order — must match the training data.yaml. */
export const XRAY_CLASSES = [
  "caries", "crown", "filling", "implant", "malaligned", "mandibular_canal", "missing_teeth",
  "periapical_lesion", "retained_root", "root_canal_treatment", "root_piece", "impacted_tooth",
  "maxillary_sinus", "bone_loss", "fracture_teeth", "permanent_teeth", "supra_eruption", "tad",
  "abutment", "attrition", "bone_defect", "gingival_former", "metal_band", "orthodontic_brackets",
  "permanent_retainer", "post_core", "plating", "wire", "cyst", "root_resorption", "primary_teeth",
];
/** Normal anatomy — detected by the model but not shown as findings. */
const ANATOMY = new Set(["mandibular_canal", "maxillary_sinus", "permanent_teeth", "primary_teeth"]);
/** Possible problems are listed before existing dental work. */
const CONCERNS = new Set([
  "caries", "periapical_lesion", "retained_root", "root_piece", "impacted_tooth", "bone_loss",
  "fracture_teeth", "cyst", "root_resorption", "bone_defect", "missing_teeth", "supra_eruption", "malaligned", "attrition",
]);
/**
 * Per-condition score thresholds (model scores, not calibrated probabilities).
 * subtle = minimum kept for cautious review; clear = higher-confidence display.
 * Initial engineering defaults — tune on dentist-labelled data before clinical use.
 */
export type ScoreThreshold = { subtle: number; clear: number };
const DEFAULT_THRESHOLD: ScoreThreshold = { subtle: 0.25, clear: 0.4 };
export const CLASS_THRESHOLDS: Record<string, ScoreThreshold> = {
  caries: { subtle: 0.3, clear: 0.45 },
  periapical_lesion: { subtle: 0.3, clear: 0.45 },
  cyst: { subtle: 0.3, clear: 0.45 },
  fracture_teeth: { subtle: 0.3, clear: 0.45 },
  impacted_tooth: { subtle: 0.25, clear: 0.4 },
  retained_root: { subtle: 0.25, clear: 0.4 },
  root_piece: { subtle: 0.25, clear: 0.4 },
  crown: { subtle: 0.25, clear: 0.35 },
  filling: { subtle: 0.25, clear: 0.35 },
  implant: { subtle: 0.25, clear: 0.35 },
  root_canal_treatment: { subtle: 0.25, clear: 0.35 },
  bone_loss: { subtle: 0.35, clear: 0.5 },
  bone_defect: { subtle: 0.35, clear: 0.5 },
};
export function thresholdFor(name: string): ScoreThreshold {
  return CLASS_THRESHOLDS[name] ?? DEFAULT_THRESHOLD;
}
/** Absolute floor applied before class thresholds. */
export const MIN_SCORE = 0.2;
/** Kept for compatibility (anatomy check); findings use thresholdFor(). */
export const SUBTLE_SCORE = 0.4;
export const NMS_IOU = 0.4;
export const ROOT_CONFLICT_IOU = 0.6;
const MAX_FINDINGS = 12;

type Ort = typeof import("onnxruntime-web");
let sessionPromise: Promise<{ ort: Ort; session: import("onnxruntime-web").InferenceSession }> | null = null;

export function preloadXrayModel() {
  return loadSession().then(() => undefined);
}

function loadSession() {
  if (!sessionPromise) {
    sessionPromise = (async () => {
      const ort = await import("onnxruntime-web");
      ort.env.wasm.wasmPaths = `https://cdn.jsdelivr.net/npm/onnxruntime-web@${ORT_VERSION}/dist/`;
      ort.env.wasm.numThreads = 1;
      const bytes = await fetchModel(XRAY_MODEL_URL, 67_000_000);
      const session = await ort.InferenceSession.create(bytes, { executionProviders: ["wasm"] });
      return { ort, session };
    })().catch((e) => {
      sessionPromise = null;
      throw e;
    });
  }
  return sessionPromise;
}

/** Letterbox to 640×640 (grey padding, centred), RGB in [0,1], CHW. */
async function preprocess(file: File) {
  const bitmap = await createImageBitmap(file);
  const W = bitmap.width;
  const H = bitmap.height;
  const scale = SIZE / Math.max(W, H);
  const w = Math.round(W * scale);
  const h = Math.round(H * scale);
  const padX = Math.floor((SIZE - w) / 2);
  const padY = Math.floor((SIZE - h) / 2);
  const canvas = document.createElement("canvas");
  canvas.width = SIZE;
  canvas.height = SIZE;
  const ctx = canvas.getContext("2d")!;
  ctx.fillStyle = "rgb(114,114,114)";
  ctx.fillRect(0, 0, SIZE, SIZE);
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(bitmap, padX, padY, w, h);
  bitmap.close();
  const { data } = ctx.getImageData(0, 0, SIZE, SIZE);
  const plane = SIZE * SIZE;
  const out = new Float32Array(3 * plane);
  for (let i = 0; i < plane; i++) {
    out[i] = (data[i * 4] ?? 0) / 255;
    out[plane + i] = (data[i * 4 + 1] ?? 0) / 255;
    out[2 * plane + i] = (data[i * 4 + 2] ?? 0) / 255;
  }
  return { tensor: out, scale, padX, padY, W, H };
}

export interface Box { cls: number; score: number; x1: number; y1: number; x2: number; y2: number; idx?: number }

function iou(a: Box, b: Box) {
  const ix = Math.max(0, Math.min(a.x2, b.x2) - Math.max(a.x1, b.x1));
  const iy = Math.max(0, Math.min(a.y2, b.y2) - Math.max(a.y1, b.y1));
  const inter = ix * iy;
  const ua = (a.x2 - a.x1) * (a.y2 - a.y1) + (b.x2 - b.x1) * (b.y2 - b.y1) - inter;
  return ua > 0 ? inter / ua : 0;
}

/** Decode YOLOv8 output [1, 4+classes+32, N] and apply per-class NMS. */
export function decode(data: ArrayLike<number>, n: number, minScore = MIN_SCORE): Box[] {
  const nc = XRAY_CLASSES.length;
  const boxes: Box[] = [];
  for (let i = 0; i < n; i++) {
    let best = 0;
    let cls = -1;
    for (let c = 0; c < nc; c++) {
      const s = data[(4 + c) * n + i] ?? 0;
      if (s > best) { best = s; cls = c; }
    }
    if (cls < 0) continue;
    if (best < Math.max(minScore, thresholdFor(XRAY_CLASSES[cls]!).subtle)) continue;
    const cx = data[i] ?? 0, cy = data[n + i] ?? 0, w = data[2 * n + i] ?? 0, h = data[3 * n + i] ?? 0;
    if (!(w > 0) || !(h > 0)) continue;
    boxes.push({ idx: i, cls, score: best, x1: cx - w / 2, y1: cy - h / 2, x2: cx + w / 2, y2: cy + h / 2 });
  }
  boxes.sort((a, b) => b.score - a.score);
  const kept: Box[] = [];
  for (const box of boxes) {
    const name = XRAY_CLASSES[box.cls];
    const duplicate = kept.some((prior) => {
      const overlap = iou(prior, box);
      if (overlap <= 0) return false;
      if (prior.cls === box.cls) return overlap >= NMS_IOU;
      const priorName = XRAY_CLASSES[prior.cls];
      const rootPair =
        (name === "root_piece" && priorName === "retained_root") ||
        (name === "retained_root" && priorName === "root_piece");
      return rootPair && overlap >= ROOT_CONFLICT_IOU;
    });
    if (!duplicate) kept.push(box);
  }
  return kept;
}

function clamp01(v: number) {
  return Math.max(0, Math.min(1, v));
}

/** Panoramic view: image left = patient's right, top half = upper jaw. */
export function panoramicLocation(cx: number, cy: number): string {
  const arch = cy < 0.5 ? "upper" : "lower";
  const side = cx < 0.5 ? "right" : "left";
  const d = Math.abs(cx - 0.5);
  if (d < 0.1) return `${arch}_front`;
  if (d < 0.2) return `${arch}_${side}_premolar`;
  if (d < 0.33) return `${arch}_${side}_molar`;
  return `${arch}_${side}_wisdom`;
}

const LABELS: Record<string, string> = {
  caries: "possible decay", periapical_lesion: "a possible infection at a root tip", impacted_tooth: "a possibly impacted tooth",
  bone_loss: "possible bone loss", cyst: "a possible cyst", fracture_teeth: "a possibly fractured tooth",
  missing_teeth: "possible missing teeth", retained_root: "a possible retained root", root_piece: "a possible root fragment",
};

export async function detectXray(file: File): Promise<AnalysisResult> {
  const started = performance.now();
  const { ort, session } = await loadSession();
  const p = await preprocess(file);
  const input = new ort.Tensor("float32", p.tensor, [1, 3, SIZE, SIZE]);
  const out = await session.run({ [session.inputNames[0] ?? "images"]: input });
  const o = out[session.outputNames[0] ?? "output0"]!;
  const n = o.dims[2] ?? 8400;
  const data = o.data as Float32Array;
  const all = decode(data, n);
  const protoT = session.outputNames[1] ? out[session.outputNames[1]] : undefined;
  const proto = protoT && protoT.dims.length === 4 && protoT.dims[1] === 32 ? (protoT.data as Float32Array) : null;
  const protoSize = protoT?.dims[2] ?? MASK_SIZE;
  const nc = XRAY_CLASSES.length;
  const anatomySeen = all.some((b) => ANATOMY.has(XRAY_CLASSES[b.cls]!) && b.score >= SUBTLE_SCORE);
  const boxes = all.filter((b) => !ANATOMY.has(XRAY_CLASSES[b.cls]!));

  const findings: Finding[] = boxes
    .flatMap((b) => {
      const bbox = mapBoxToImage(b, p);
      if (!bbox) return [];
      const name = XRAY_CLASSES[b.cls]!;
      const f: Finding = { id: `${name}-${b.idx ?? 0}`, name, confidence: Math.round(b.score * 1000) / 1000, location: panoramicLocation(bbox.x + bbox.w / 2, bbox.y + bbox.h / 2), bbox };
      if (proto && b.idx !== undefined) {
        const coefs = new Float32Array(32);
        for (let c = 0; c < 32; c++) coefs[c] = data[(4 + nc + c) * n + b.idx] ?? 0;
        const mask = maskPolygon(proto, coefs, b, p, protoSize);
        if (mask) f.mask = mask;
      }
      return [f];
    })
    .sort((a, b) => Number(CONCERNS.has(b.name)) - Number(CONCERNS.has(a.name)) || b.confidence - a.confidence)
    .slice(0, MAX_FINDINGS);

  const base = {
    imageType: "xray" as const,
    supported: true,
    model: { id: "dentist-ai-xray-yolov8", version: "1.3-browser", isMock: false },
    durationMs: Math.round(performance.now() - started),
  };
  const teethNote = anatomySeen ? " The model did recognise the teeth on this X-ray." : "";
  return { ...base, ...xrayResult(findings, teethNote) };
}

/** Empty findings → no_findings (never claims disease is ruled out); otherwise a cautious summary. */
export function xrayResult(findings: Finding[], teethNote = "") {
  if (!findings.length) {
    return {
      status: "no_findings" as const,
      findings: [],
      explanation: `No clear signs of decay, infection, bone loss or other listed problems passed the model's checks on this X-ray.${teethNote} This does not rule out a problem — an X-ray can't show everything.`,
      recommendations: ["Consult a dentist if you have pain, swelling or other symptoms", "Bring this X-ray to your next dental visit"],
    };
  }
  return xraySummary(findings, teethNote);
}

/** Convert letterboxed model coords back to the original image (0–1), clipped; null if invalid. */
export function mapBoxToImage(box: Box, p: { padX: number; padY: number; scale: number; W: number; H: number }) {
  const x1 = clamp01((box.x1 - p.padX) / p.scale / p.W);
  const y1 = clamp01((box.y1 - p.padY) / p.scale / p.H);
  const x2 = clamp01((box.x2 - p.padX) / p.scale / p.W);
  const y2 = clamp01((box.y2 - p.padY) / p.scale / p.H);
  if (!(x2 > x1) || !(y2 > y1)) return null;
  return { x: x1, y: y1, w: x2 - x1, h: y2 - y1 };
}

/** Patient-facing summary; findings below SUBTLE_SCORE are described as subtle, never as confirmed. */
export function xraySummary(findings: Finding[], teethNote = "") {
  const clear = findings.filter((f) => f.confidence >= thresholdFor(f.name).clear);
  const subtle = findings.length - clear.length;
  const concerns = clear.filter((f) => CONCERNS.has(f.name));
  const work = clear.length - concerns.length;
  const named = [...new Set(concerns.map((f) => LABELS[f.name] ?? f.name.replace(/_/g, " ")))].slice(0, 3);
  const subtleNote = subtle
    ? ` ${subtle} subtle, low-confidence area${subtle > 1 ? "s were" : " was"} also marked — these are faint signals, not confirmed findings.`
    : "";
  let explanation: string;
  if (!clear.length) {
    const names = [...new Set(findings.map((f) => LABELS[f.name] ?? f.name.replace(/_/g, " ")))].slice(0, 3);
    explanation = `The model only noticed subtle, low-confidence signals (${names.join(", ")}). These are faint and may be nothing, but a dentist can check them.${teethNote}`;
  } else if (concerns.length) {
    explanation = `The model marked ${concerns.length} area${concerns.length > 1 ? "s" : ""} worth a closer look, including ${named.join(", ")}${work ? `, plus ${work} existing dental work item${work > 1 ? "s" : ""}` : ""}. Each is boxed on the X-ray.${subtleNote}`;
  } else {
    explanation = `The model mainly recognised existing dental work (${work} item${work > 1 ? "s" : ""}), such as fillings or crowns. Each is boxed on the X-ray.${subtleNote}`;
  }
  return {
    status: "complete" as const,
    findings,
    explanation,
    recommendations: concerns.length || subtle
      ? ["Consider asking a dentist to review the marked areas", "Bring this report to your next dental visit"]
      : ["Keep up regular check-ups so your dentist can monitor existing work"],
  };
}

/** Prototype mask resolution (output1 is [1, 32, MASK_SIZE, MASK_SIZE]). */
export const MASK_SIZE = 160;
const MASK_DIM = 32;
const MAX_POLY_POINTS = 64;

/** Moore-neighbour trace of the outer boundary of the first blob in a binary grid. */
export function traceContour(grid: Uint8Array, w: number, h: number): Array<[number, number]> {
  let start = -1;
  for (let i = 0; i < grid.length; i++) if (grid[i]) { start = i; break; }
  if (start < 0) return [];
  const at = (x: number, y: number) => x >= 0 && y >= 0 && x < w && y < h && grid[y * w + x] === 1;
  const dirs: Array<[number, number]> = [[1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0], [-1, -1], [0, -1], [1, -1]];
  const sx = start % w, sy = Math.floor(start / w);
  const pts: Array<[number, number]> = [[sx, sy]];
  let x = sx, y = sy, dir = 7;
  for (let step = 0; step < w * h * 4; step++) {
    let moved = false;
    for (let k = 0; k < 8; k++) {
      const d = (dir + 6 + k) % 8;
      const [dx, dy] = dirs[d]!;
      if (at(x + dx, y + dy)) { x += dx; y += dy; dir = d; moved = true; break; }
    }
    if (!moved || (x === sx && y === sy)) break;
    pts.push([x, y]);
  }
  return pts;
}

/**
 * Build a normalised polygon (original-image 0–1 coords) for one detection from
 * YOLOv8-seg prototypes. Returns null when the mask is empty or degenerate.
 */
export function maskPolygon(
  proto: ArrayLike<number>,
  coefs: ArrayLike<number>,
  box: Box,
  p: { padX: number; padY: number; scale: number; W: number; H: number },
  size = MASK_SIZE,
): MaskPolygon | null {
  const r = size / SIZE;
  const bx1 = Math.max(0, Math.floor(box.x1 * r)), by1 = Math.max(0, Math.floor(box.y1 * r));
  const bx2 = Math.min(size, Math.ceil(box.x2 * r)), by2 = Math.min(size, Math.ceil(box.y2 * r));
  const w = bx2 - bx1, h = by2 - by1;
  if (w < 2 || h < 2) return null;
  const grid = new Uint8Array(w * h);
  const plane = size * size;
  let on = 0;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const idx = (by1 + y) * size + (bx1 + x);
      let v = 0;
      for (let c = 0; c < MASK_DIM; c++) v += (coefs[c] ?? 0) * (proto[c * plane + idx] ?? 0);
      if (v > 0) { grid[y * w + x] = 1; on++; } // sigmoid(v) > 0.5 ⇔ v > 0
    }
  }
  if (on < 4) return null;
  const raw = traceContour(grid, w, h);
  if (raw.length < 3) return null;
  const stride = Math.max(1, Math.ceil(raw.length / MAX_POLY_POINTS));
  const points: Array<[number, number]> = [];
  for (let i = 0; i < raw.length; i += stride) {
    const [gx, gy] = raw[i]!;
    const mx = (bx1 + gx + 0.5) / r, my = (by1 + gy + 0.5) / r; // back to 640 letterbox space
    points.push([
      Math.round(clamp01((mx - p.padX) / p.scale / p.W) * 10000) / 10000,
      Math.round(clamp01((my - p.padY) / p.scale / p.H) * 10000) / 10000,
    ]);
  }
  return points.length >= 3 ? { points } : null;
}
