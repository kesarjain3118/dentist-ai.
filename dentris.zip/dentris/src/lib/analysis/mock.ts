import type { AnalysisResult, ImageType } from "./types";

/**
 * Realistic SAMPLE responses used until a real model endpoint is configured.
 * Numbers here are illustrative only — they are not model metrics.
 * The scenario is chosen deterministically from the file so results are repeatable.
 */
function hash(input: string) {
  let h = 0;
  for (let i = 0; i < input.length; i++) h = (h * 31 + input.charCodeAt(i)) | 0;
  return Math.abs(h);
}

export async function mockAnalyze(file: File, imageType: ImageType): Promise<AnalysisResult> {
  const started = Date.now();
  await new Promise((r) => setTimeout(r, 900));
  const seed = hash(`${file.name}:${file.size}`);
  const scenario = seed % 10; // 0-6 findings, 7 none, 8 low confidence, 9 findings (alt)
  const model = { id: imageType === "xray" ? "dental-xray-mock" : "dental-photo-mock", version: "0.0-sample", isMock: true };
  const base = { imageType, supported: true, model, durationMs: 0 };

  if (scenario === 7) {
    return {
      ...base,
      status: "no_findings",
      findings: [],
      explanation: "No notable areas were found in this image. That is a good sign, but an image cannot show everything.",
      recommendations: ["Keep up regular brushing and cleaning between teeth.", "Continue routine dental check-ups."],
      durationMs: Date.now() - started,
    };
  }
  if (scenario === 8) {
    return {
      ...base,
      status: "low_confidence",
      findings: [],
      explanation: "We couldn't confidently analyze this image. Lighting, angle or focus may have affected the result.",
      recommendations: ["Try a sharper, well-lit image taken straight on.", "A dentist can examine areas a photo cannot show."],
      durationMs: Date.now() - started,
    };
  }

  const findings =
    imageType === "xray"
      ? [
          { name: "impacted_tooth", confidence: 0.86, location: "lower_right_wisdom", bbox: { x: 0.74, y: 0.52, w: 0.14, h: 0.26 } },
          { name: "caries", confidence: 0.73, location: "upper_left_molar", bbox: { x: 0.22, y: 0.3, w: 0.1, h: 0.16 } },
          ...(scenario % 2 === 0
            ? [{ name: "bone_loss", confidence: 0.61, location: "lower_front", bbox: { x: 0.44, y: 0.6, w: 0.14, h: 0.14 } }]
            : []),
        ]
      : [
          { name: "caries", confidence: 0.92, location: "upper_left_molar", bbox: { x: 0.24, y: 0.22, w: 0.2, h: 0.36 } },
          { name: "calculus", confidence: 0.78, location: "lower_left_molar", bbox: { x: 0.58, y: 0.42, w: 0.15, h: 0.34 } },
          ...(scenario !== 9
            ? [{ name: "gingivitis", confidence: 0.71, location: "lower_front", bbox: { x: 0.42, y: 0.68, w: 0.12, h: 0.2 } }]
            : []),
        ];

  return {
    ...base,
    status: "complete",
    findings,
    explanation:
      "The image contains visual features that may be consistent with the possible findings listed. A dental professional should confirm them.",
    recommendations: [
      "Book a dental check-up to confirm these possible findings.",
      "Brush twice a day with fluoride toothpaste and clean between your teeth daily.",
      "Limit sugary snacks and drinks between meals.",
    ],
    durationMs: Date.now() - started,
  };
}
