/**
 * Runs the Dentist AI SigLIP classifier (INT8 ONNX) directly in the browser.
 * Browser-only: import this module dynamically from analyzeImage, never at SSR time.
 */
import type { AnalysisResult, ImageType } from "./types";

const MODEL_URL =
  (import.meta.env["VITE_DENTAL_MODEL_ONNX_URL"] as string | undefined) ||
  "https://huggingface.co/hashmath2005/dentist-ai-weights/resolve/main/dental-siglip-int8.onnx";
const ORT_VERSION = "1.30.0";
export const CLASSES = ["calculus", "caries", "gingivitis", "mouth_ulcer", "tooth_discoloration", "hypodontia"];

/** Photo models tried in order: ResNet50 (nsr51324, testing) first, current SigLIP as backup. */
export type PhotoModelSpec = { id: string; version: string; url: string; size: number; classes: string[]; mean: number[]; std: number[] };
export const PHOTO_MODELS: PhotoModelSpec[] = [
  {
    id: "dentist-ai-resnet50",
    version: "1.0-browser",
    url: "https://aivxdcvrjysrcdputmag.supabase.co/storage/v1/object/public/models/dental_photo_resnet50.onnx",
    size: 94_000_000,
    // Verified order from the checkpoint's class_names.
    classes: ["calculus", "caries", "gingivitis", "hypodontia", "tooth_discoloration", "mouth_ulcer"],
    mean: [0.485, 0.456, 0.406],
    std: [0.229, 0.224, 0.225],
  },
  { id: "dentist-ai-siglip", version: "2.1-browser", url: MODEL_URL, size: 89_000_000, classes: CLASSES, mean: [0.5, 0.5, 0.5], std: [0.5, 0.5, 0.5] },
];
/**
 * The photo classifier has no "healthy" class, so softmax always names a condition.
 * Answers from POSSIBLE_CONFIDENCE are shown (labelled moderate below CLEAR_CONFIDENCE);
 * anything weaker is reported as no clear concern.
 */
export const CLEAR_CONFIDENCE = 0.8;
export const POSSIBLE_CONFIDENCE = 0.5;
export type PhotoTier = "clear" | "possible" | "none";
export function photoTier(confidence: number): PhotoTier {
  if (confidence >= CLEAR_CONFIDENCE) return "clear";
  if (confidence >= POSSIBLE_CONFIDENCE) return "possible";
  return "none";
}

const EXPLANATIONS: Record<string, string> = {
  calculus: "The model noticed possible calculus (tartar) — hardened plaque build-up near the gums. Stains, natural tooth colour or reflections can look similar, so a dentist should confirm.",
  caries: "The model noticed a possible area of tooth decay (a cavity) in this image.",
  gingivitis: "The model noticed possible signs of gum inflammation, such as redness or swelling.",
  mouth_ulcer: "The model noticed what may be a mouth ulcer (a small sore in the mouth).",
  tooth_discoloration: "The model noticed possible staining or colour changes on the teeth.",
  hypodontia: "The model noticed what may be one or more missing teeth.",
};
const RECOMMENDATIONS: Record<string, string[]> = {
  calculus: ["Consider a professional cleaning to remove tartar", "Brush twice daily and floss once a day"],
  caries: ["Consider a dental visit soon to have this area checked", "Brush twice daily with fluoride toothpaste", "Reduce sugary snacks and drinks between meals"],
  gingivitis: ["Brush gently along the gumline twice a day", "Floss daily", "Consider a dental check-up if gums bleed often"],
  mouth_ulcer: ["Avoid spicy or acidic foods while it heals", "See a dentist or doctor if it lasts more than 2 weeks"],
  tooth_discoloration: ["Limit coffee, tea and tobacco", "Ask a dentist about safe whitening or cleaning options"],
  hypodontia: ["Consider a dental visit to confirm with an X-ray", "A dentist can discuss options to replace missing teeth"],
};

type Ort = typeof import("onnxruntime-web");
let sessionPromise: Promise<{ ort: Ort; session: import("onnxruntime-web").InferenceSession; spec: PhotoModelSpec }> | null = null;
const progressListeners = new Set<(p: number) => void>();
let lastProgress = 0;

/** Subscribe to model download progress (0–1). Returns an unsubscribe fn. */
export function onModelProgress(fn: (p: number) => void) {
  progressListeners.add(fn);
  fn(lastProgress);
  return () => progressListeners.delete(fn);
}
function emit(p: number) {
  lastProgress = p;
  progressListeners.forEach((fn) => fn(p));
}

/** Download once, keep in the browser cache so later visits load instantly. */
export async function fetchModel(url: string = MODEL_URL, fallbackSize = 89_000_000): Promise<Uint8Array> {
  const cache = typeof caches !== "undefined" ? await caches.open("dentist-ai-model-v1").catch(() => null) : null;
  const hit = await cache?.match(url);
  if (hit) {
    emit(1);
    return new Uint8Array(await hit.arrayBuffer());
  }
  const res = await fetch(url);
  if (!res.ok || !res.body) throw new Error(`model download ${res.status}`);
  const total = Number(res.headers.get("content-length")) || fallbackSize;
  const reader = res.body.getReader();
  const chunks: Uint8Array[] = [];
  let got = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    chunks.push(value);
    got += value.length;
    emit(Math.min(0.99, got / total));
  }
  const buf = new Uint8Array(got);
  let off = 0;
  for (const c of chunks) { buf.set(c, off); off += c.length; }
  cache?.put(url, new Response(buf.slice())).catch(() => {});
  emit(1);
  return buf;
}

/** Start loading the model early (e.g. when the Analyze page opens). */
export function preloadModel() {
  return loadSession().then(() => undefined);
}

function loadSession() {
  if (!sessionPromise) {
    sessionPromise = (async () => {
      const ort = await import("onnxruntime-web");
      ort.env.wasm.wasmPaths = `https://cdn.jsdelivr.net/npm/onnxruntime-web@${ORT_VERSION}/dist/`;
      ort.env.wasm.numThreads = 1;
      let lastErr: unknown;
      for (const spec of PHOTO_MODELS) {
        try {
          const bytes = await fetchModel(spec.url, spec.size);
          const session = await ort.InferenceSession.create(bytes, { executionProviders: ["wasm"] });
          return { ort, session, spec };
        } catch (e) {
          lastErr = e;
          console.warn(`[photo-model] ${spec.id} failed, trying backup`, e);
        }
      }
      throw lastErr;
    })().catch((e) => {
      sessionPromise = null;
      emit(0);
      throw e;
    });
  }
  return sessionPromise;
}

/** SigLIP preprocessing: resize to 224×224, scale to [-1, 1] (mean 0.5, std 0.5), CHW. */
async function preprocess(file: File, mean: number[], std: number[]): Promise<Float32Array> {
  const bitmap = await createImageBitmap(file);
  // Shrink in halving steps: a single jump from a large phone photo to 224px
  // aliases badly and shifts the model's answer away from what it was trained on.
  let src: CanvasImageSource = bitmap;
  let w = bitmap.width;
  let h = bitmap.height;
  while (w / 2 >= 224 && h / 2 >= 224) {
    w = Math.round(w / 2);
    h = Math.round(h / 2);
    const step = document.createElement("canvas");
    step.width = w;
    step.height = h;
    const sctx = step.getContext("2d")!;
    sctx.imageSmoothingQuality = "high";
    sctx.drawImage(src, 0, 0, w, h);
    src = step;
  }
  const canvas = document.createElement("canvas");
  canvas.width = 224;
  canvas.height = 224;
  const ctx = canvas.getContext("2d")!;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(src, 0, 0, 224, 224);
  bitmap.close();
  const { data } = ctx.getImageData(0, 0, 224, 224);
  const out = new Float32Array(3 * 224 * 224);
  const plane = 224 * 224;
  for (let i = 0; i < plane; i++) {
    for (let c = 0; c < 3; c++) out[c * plane + i] = ((data[i * 4 + c] ?? 0) / 255 - mean[c]!) / std[c]!;
  }
  return out;
}

/**
 * PROVISIONAL (not validated on dentist-labelled data). Scores are softmax outputs of a
 * single-label model — they compete and sum to 1, and are not calibrated probabilities.
 * Secondary classes at or above this are listed as additional possible findings. */
export const SECONDARY_CONFIDENCE = 0.3;

/**
 * Single-label softmax classifier: only list extra classes when the top class already passes
 * POSSIBLE_CONFIDENCE, and only those with real support (≥ SECONDARY_CONFIDENCE). Never invents locations.
 */
export function photoFindings(probs: number[], classes: readonly string[], secondary = SECONDARY_CONFIDENCE) {
  const ranked = probs.map((p, i) => ({ name: classes[i] ?? "unknown", confidence: p })).sort((a, b) => b.confidence - a.confidence);
  const top = ranked[0];
  if (!top || photoTier(top.confidence) === "none") return [];
  return ranked
    .filter((r, i) => i === 0 || r.confidence >= secondary)
    .map((r) => ({ name: r.name, confidence: Math.round(r.confidence * 1000) / 1000, location: "whole_image" }));
}

/**
 * PROVISIONAL: when the top class is only moderate and the runner-up is within this margin,
 * the model is split between two conditions, so neither is treated as the main answer.
 */
export const CLOSE_CALL_MARGIN = 0.15;
export function isCloseCall(probs: number[], margin = CLOSE_CALL_MARGIN) {
  const [a = 0, b = 0] = [...probs].sort((x, y) => y - x);
  return a < CLEAR_CONFIDENCE && a - b < margin;
}
const LABEL_TEXT: Record<string, string> = {
  calculus: "tartar", caries: "decay", gingivitis: "gum inflammation", mouth_ulcer: "a mouth ulcer",
  tooth_discoloration: "staining", hypodontia: "missing teeth",
};

export function softmax(logits: ArrayLike<number>): number[] {
  const arr = Array.from(logits);
  const max = Math.max(...arr);
  const exps = arr.map((v) => Math.exp(v - max));
  const sum = exps.reduce((a, b) => a + b, 0);
  return exps.map((v) => v / sum);
}

export async function classifyInBrowser(file: File, imageType: ImageType): Promise<AnalysisResult> {
  const started = performance.now();
  const { ort, session, spec } = await loadSession();
  const CLASSES = spec.classes;
  const input = new ort.Tensor("float32", await preprocess(file, spec.mean, spec.std), [1, 3, 224, 224]);
  const inName = session.inputNames[0] ?? "pixel_values";
  const outName = session.outputNames[0] ?? "logits";
  const output = await session.run({ [inName]: input });
  const probs = softmax(output[outName]!.data as Float32Array);
  const idx = probs.indexOf(Math.max(...probs));
  const key = CLASSES[idx] ?? "unknown";
  const confidence = probs[idx] ?? 0;
  const base = {
    imageType,
    supported: true,
    model: { id: spec.id, version: spec.version, isMock: false },
    durationMs: Math.round(performance.now() - started),
  };
  const tier = photoTier(confidence);
  if (tier === "none") {
    return {
      ...base,
      status: "no_findings",
      findings: [],
      explanation:
        "No clear concerns detected in this photo. The model did not find a strong sign of decay, tartar, gum inflammation or other listed conditions. This is not a full check-up — a dentist can examine properly.",
      recommendations: ["Keep brushing twice a day and cleaning between your teeth", "Keep up routine dental check-ups"],
    };
  }
  // Whole-image classifier: no box and no tooth location are known, so none are invented.
  const found = photoFindings(probs, CLASSES);
  if (isCloseCall(probs) && found.length > 1) {
    const [a, b] = found;
    return {
      ...base,
      status: "complete",
      findings: found,
      explanation: `The model was split between possible ${LABEL_TEXT[a!.name] ?? a!.name} and possible ${LABEL_TEXT[b!.name] ?? b!.name}, so neither is a clear sign. This is not a diagnosis — a dentist can tell them apart.`,
      recommendations: ["Mention this result at your next dental check-up", "Keep brushing twice a day and cleaning between your teeth"],
    };
  }
  return {
    ...base,
    status: "complete",
    findings: photoFindings(probs, CLASSES),
    explanation:
      (EXPLANATIONS[key] ?? "The model noticed a possible finding in this image.") +
      (photoFindings(probs, CLASSES).length > 1
        ? " The model also saw weaker signs of another listed condition, shown below as a possible finding."
        : "") +
      (tier === "possible"
        ? " Confidence is moderate, so this is a lean rather than a clear sign — a dentist can confirm."
        : ""),
    recommendations:
      tier === "clear"
        ? RECOMMENDATIONS[key] ?? ["Consider discussing this result with a dentist."]
        : ["Ask a dentist to check this at your next visit", ...(RECOMMENDATIONS[key] ?? []).slice(1)],
  };
}
