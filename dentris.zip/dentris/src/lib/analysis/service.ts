import { mockAnalyze } from "./mock";
import { AnalysisError, CONFIDENCE_FLOOR, type AnalysisResult, type ImageType } from "./types";

/**
 * Single entry point for dental image inference.
 *
 * Defaults to the user's ConvNeXt-Tiny server on Render. Override per image
 * type with VITE_DENTAL_PHOTO_MODEL_URL / VITE_DENTAL_XRAY_MODEL_URL.
 * Each endpoint receives multipart form-data { image, imageType } and must
 * return JSON matching `AnalysisResult` (see ./types.ts). If the server can't
 * be reached, a clearly labelled sample result is used so the app keeps working.
 */
const DEFAULT_MODEL_URL = "https://dentist-ai-server.onrender.com/predict";
const ENDPOINTS: Record<ImageType, string> = {
  photo: (import.meta.env['VITE_DENTAL_PHOTO_MODEL_URL'] as string | undefined) || DEFAULT_MODEL_URL,
  xray: (import.meta.env['VITE_DENTAL_XRAY_MODEL_URL'] as string | undefined) || DEFAULT_MODEL_URL,
};
/** Free Render servers sleep and take ~1 minute to wake up. */
const TIMEOUT_MS = 90_000;

export const ACCEPTED_TYPES = ["image/jpeg", "image/png", "image/webp"];
export const MAX_BYTES = 15 * 1024 * 1024;

export function validateFile(file: File) {
  if (!ACCEPTED_TYPES.includes(file.type)) {
    throw new AnalysisError("invalid_file", "Please upload a JPG, PNG or WebP image.");
  }
  if (file.size > MAX_BYTES) {
    throw new AnalysisError("invalid_file", "This image is larger than 15 MB. Please choose a smaller file.");
  }
}

function normalise(result: AnalysisResult): AnalysisResult {
  const visible = (result.findings ?? [])
    .filter((f) => f.confidence >= CONFIDENCE_FLOOR)
    .sort((a, b) => b.confidence - a.confidence);
  if (result.status === "complete" && visible.length === 0) {
    return { ...result, status: "low_confidence", findings: [] };
  }
  return { ...result, findings: visible };
}

export async function analyzeImage(file: File, imageType: ImageType): Promise<AnalysisResult> {
  validateFile(file);
  // 1) Run the user's model directly in the browser (no server needed).
  try {
    if (imageType === "xray") {
      const { detectXray } = await import("./xray-model");
      return normalise(await detectXray(file));
    }
    const { classifyInBrowser } = await import("./browser-model");
    return normalise(await classifyInBrowser(file, imageType));
  } catch (e) {
    console.warn("In-browser model failed, trying model server:", e);
  }
  // 2) Optional remote model server.
  const body = new FormData();
  body.append("image", file);
  body.append("imageType", imageType);
  try {
    const res = await fetch(ENDPOINTS[imageType], { method: "POST", body, signal: AbortSignal.timeout(TIMEOUT_MS) });
    if (!res.ok) throw new Error(`status ${res.status}`);
    const json = (await res.json()) as AnalysisResult;
    if (!json || !Array.isArray(json.findings) || !json.model) throw new Error("bad shape");
    return normalise({ ...json, imageType });
  } catch (e) {
    // 3) Clearly labelled sample so the app keeps working.
    console.warn("Real model unavailable, using labelled sample result:", e);
    return normalise(await mockAnalyze(file, imageType));
  }
}
