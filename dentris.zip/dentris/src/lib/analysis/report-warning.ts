import type { AnalysisResult } from "./types";

/** Confidence is uncertainty, not evidence of poor lighting or image quality. */
export function reportWarning(result: AnalysisResult) {
  const uncertainStatus = ["low_confidence", "poor_quality", "unsupported"].includes(result.status);
  const confidence = Math.max(0, ...result.findings.map((finding) => finding.confidence));
  if (!uncertainStatus && (!result.findings.length || confidence >= 0.65)) return null;

  const xray = result.imageType === "xray";
  const title = result.status === "unsupported"
    ? "This image isn't supported"
    : result.status === "poor_quality"
      ? "Image quality was too low"
      : "The AI result is uncertain";
  const body = result.status === "unsupported"
    ? "Choose the matching scan type: mouth photo or dental X-ray."
    : result.status === "poor_quality"
      ? xray ? "Try the original, uncropped X-ray file from your clinic." : "Try a sharper, close-up photo with the area in focus."
      : "The model did not reach a reliable confidence level. This does not confirm a condition, rule out a problem, or mean the lighting is bad. A dentist can review the image and examine you.";
  return { title, body, guidance: xray ? "xray" as const : "photo" as const };
}