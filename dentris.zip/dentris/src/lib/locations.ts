/** Human labels + approximate dental-arch coordinates (viewBox 0 0 200 240) for model location codes. */
export interface LocationInfo {
  label: string;
  arch: "upper" | "lower";
  /** x position across the arch, 0 = patient's right, 1 = patient's left */
  t: number;
  /** FDI tooth numbers this region covers (indicative, dentist confirms). */
  teeth: string;
}

const MAP: Record<string, LocationInfo> = {
  upper_right_wisdom: { label: "Upper right wisdom tooth", arch: "upper", t: 0.02, teeth: "18" },
  upper_right_molar: { label: "Upper right molar", arch: "upper", t: 0.12, teeth: "16–17" },
  upper_right_premolar: { label: "Upper right premolar", arch: "upper", t: 0.27, teeth: "14–15" },
  upper_front: { label: "Upper front teeth", arch: "upper", t: 0.5, teeth: "11–21" },
  upper_left_premolar: { label: "Upper left premolar", arch: "upper", t: 0.73, teeth: "24–25" },
  upper_left_molar: { label: "Upper left molar", arch: "upper", t: 0.88, teeth: "26–27" },
  upper_left_wisdom: { label: "Upper left wisdom tooth", arch: "upper", t: 0.98, teeth: "28" },
  lower_right_wisdom: { label: "Lower right wisdom tooth", arch: "lower", t: 0.02, teeth: "48" },
  lower_right_molar: { label: "Lower right molar", arch: "lower", t: 0.12, teeth: "46–47" },
  lower_right_premolar: { label: "Lower right premolar", arch: "lower", t: 0.27, teeth: "44–45" },
  lower_front: { label: "Lower front teeth / gumline", arch: "lower", t: 0.5, teeth: "31–41" },
  lower_left_premolar: { label: "Lower left premolar", arch: "lower", t: 0.73, teeth: "34–35" },
  lower_left_molar: { label: "Lower left molar", arch: "lower", t: 0.88, teeth: "36–37" },
  lower_left_wisdom: { label: "Lower left wisdom tooth", arch: "lower", t: 0.98, teeth: "38" },
};

export function getLocation(code: string): LocationInfo {
  return MAP[code] ?? { label: code.replace(/_/g, " "), arch: "upper", t: 0.5, teeth: "—" };
}
