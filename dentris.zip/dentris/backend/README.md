# Dentist AI model server

FastAPI server that runs the ConvNeXt dental classifier and answers
`POST /predict` in the JSON format the Dentist AI website expects.

## Run locally

```bash
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```

The server looks for `best_model.pth` next to this file (or in a `model/`
folder). If it is missing, it downloads the weights automatically from the
URL in the `MODEL_URL` environment variable (defaults to the hosted copy).

## Connect the website

The website cannot run this model itself — it calls this server over HTTP.

1. Make the server reachable publicly, either:
   - quick test: `cloudflared tunnel --url http://localhost:8000`
   - permanent: deploy this folder to a host (e.g. Render) with
     build `pip install -r requirements.txt` and start
     `uvicorn main:app --host 0.0.0.0 --port $PORT`
2. Set the public URL in the website environment:
   - `VITE_DENTAL_PHOTO_MODEL_URL=https://your-server/predict`
   - `VITE_DENTAL_XRAY_MODEL_URL=https://your-server/predict`

Until a URL is set (or if the server is unreachable), the website falls back
to clearly labelled sample results.
